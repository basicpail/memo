webMI.addOnload(function () {
	webMI.gfx.setText("txt", "Hello 👋");
	var on = false;
  
	webMI.addEvent("btn", "click", function () {
		on = !on;
		webMI.gfx.setFill("rect", on ? "#9AE6B4" : "#FCA5A5"); // 초록↔핑크
		});
});
