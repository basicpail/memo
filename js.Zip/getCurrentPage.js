// 페이지 이름 계산
const pageName =
  document.querySelector('meta[property="og:title"]')?.content?.trim()
  || document.title?.trim()
  || location.pathname.split('/').filter(Boolean).pop()
  || 'index';

// id별 엘리먼트(중복 id도 배열로 보관)
const idMap = {};
document.querySelectorAll('[id]').forEach(el => {
  const id = el.id;
  const item = {
    tag: el.tagName.toLowerCase(),
    selector: `#${(window.CSS?.escape ? CSS.escape(id) : id)}`,
    element: el  // 콘솔에서 바로 클릭/확인 가능
  };
  (idMap[id] ??= []).push(item);
});

console.log({ pageName, idMap });

// 보기 편하게 표 형태
console.table(
  Object.entries(idMap).map(([id, arr]) => ({
    id,
    count: arr.length,
    tags: arr.map(x => x.tag).join(',')
  }))
);
