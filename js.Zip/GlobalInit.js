// Menu Scripts -> GlobalInit
webMI.addOnload(function () {
  var root = webMI.rootWindow || window;
  if (root.APP && root.APP.__ready) return;

  var APP = root.APP = (root.APP || {});
  APP.__ready = false;

  // 1) 이벤트 버스 (전역 트리거 래핑)
  APP.bus = {
    on:  (topic, cb) => webMI.trigger.connect(topic, e => cb && cb(e.value, e)),
    emit: (topic, payload) => webMI.trigger.fire(topic, payload)
  };

  // 2) 전역 상태 & 액션(도메인 로직만, DOM 만지지 않음)
  APP.state = { demoOn: false, theme: localStorage.getItem("Color_Mode") || "Day" };

  APP.actions = {
    toggleDemo() {
      APP.state.demoOn = !APP.state.demoOn;
      APP.bus.emit("demo:on", APP.state.demoOn); // 화면들에 emit
    },
    setTheme(mode) {
      APP.state.theme = mode;
      localStorage.setItem("Color_Mode", mode);
      APP.bus.emit("theme:changed", mode);
    }
  };

  // 3) 외부 모듈(HTTP) 로드: 필요 시
  function loadChain(urls, done) {
    var i = 0;
    (function next() {
      if (i >= urls.length) return done && done();
      var s = root.document.createElement("script");
      s.type = "text/javascript";
      s.src  = urls[i++] + "?v=20250902";
      s.onload = next;
      root.document.head.appendChild(s);
    })();
  }

  loadChain([
    "/js/app-core.js",   // 선택: io/util 같은 공용 모듈
    "/js/app-colors.js"  // 선택: ColorManager 등
  ], function () {
    APP.__ready = true;
    APP.bus.emit("APP:ready", true); // 모든 화면에 "준비 완료" 알림
  });
});
