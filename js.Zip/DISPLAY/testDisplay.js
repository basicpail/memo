webMI.addOnload(function () {
  var APP = (webMI.rootWindow || window).APP;
  function init() {
    webMI.gfx.setText("txt", "Hello 👋");
    webMI.gfx.setFill("txt", "#FFFFFF");
    //webMI.addEvent("btn", "click", APP.actions.toggleDemo);
    webMI.addEvent("btn", "click", function(e) {
		APP.actions.toggleDemo();    
    });
    
    APP.bus.on("demo:on", on => webMI.gfx.setFill("rect", on ? "#9AE6B4" : "#FCA5A5"));
    
    APP.bus.on("theme:changed", theme => webMI.trigger.fire("Color_Mode_Change", theme));
    // 초기 상태 반영
    webMI.gfx.setFill("rect", APP.state.demoOn ? "#9AE6B4" : "#FCA5A5");
    
  }
  (APP && APP.__ready) ? init() : webMI.trigger.connect("APP:ready", init);
});



///////////////////////////*  주/야간 모드 읽어오기 *///////////////////////////
var event_add = webMI.callExtension("SYSTEM.LIBRARY.PROJECT.QUICKDYNAMICS.AddEvent");		///Atvise 서버에서 실행됨

var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

var color = webMI.query["color"];

var language_mode;

var btn_ko_lamp = document.getElementById("btn_ko_lamp");
var btn_en_lamp = document.getElementById("btn_en_lamp");

var btn_night_lamp = document.getElementById("btn_night_lamp");
var btn_day_lamp = document.getElementById("btn_day_lamp");

var btn_auto_button_label = document.getElementById("btn_auto_button_label");
var btn_manual_button_label = document.getElementById("btn_manual_button_label");


webMI.trigger.connect("Color_Mode_Change", function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

webMI.trigger.connect("Event_Add",function (e) {
	var desc = e.value;

	event_add(desc);
});


function Color_Day_Night(color_mode)
{
	if (color_mode == "Day")
	{
		btn_day_lamp.setAttribute("fill", color.BtnLamp_On.Day);
		btn_night_lamp.setAttribute("fill", color.BtnLamp_Off.Day);
	}
	else if (color_mode == "Night")
	{
		btn_day_lamp.setAttribute("fill", color.BtnLamp_Off.Night);
		btn_night_lamp.setAttribute("fill", color.BtnLamp_On.Night);
	}
	
	webMI.gfx.setFill("back_display", color.Main_Background[color_mode]);
	webMI.gfx.setFill("bento_1", color.Bento[color_mode]);
	webMI.gfx.setFill("bento_2", color.Bento[color_mode]);
	webMI.gfx.setFill("bento_3", color.Bento[color_mode]);
	
	webMI.gfx.setFill("lbl_display", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_theme", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_brightness", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_brightness2", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_language_time", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_language", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_time", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_year", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_month", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_day", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_hour", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_min", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_sec", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_sw_vesion", color.Font_Title[color_mode]);
	
	
	webMI.gfx.setFill("time_Year", color.Font_Default[color_mode]);
	webMI.gfx.setFill("time_Month", color.Font_Default[color_mode]);
	webMI.gfx.setFill("time_Date", color.Font_Default[color_mode]);
	webMI.gfx.setFill("time_Hour", color.Font_Default[color_mode]);
	webMI.gfx.setFill("time_Minute", color.Font_Default[color_mode]);
	webMI.gfx.setFill("time_Second", color.Font_Default[color_mode]);

	webMI.gfx.setStroke("line_1", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_2", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_3", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_4", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_5", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_6", color.Under_Line[color_mode]);

	language_mode = localStorage.getItem("Language_Mode");
	if (language_mode == "ko")
	{
		btn_en_lamp.setAttribute("fill", color.BtnLamp_Off[color_mode]);
		btn_ko_lamp.setAttribute("fill", color.BtnLamp_On[color_mode]);
	}
	else if (language_mode == "en")
	{
		btn_en_lamp.setAttribute("fill", color.BtnLamp_On[color_mode]);
		btn_ko_lamp.setAttribute("fill", color.BtnLamp_Off[color_mode]);
	}
	
	
	//webMI.trigger.fire(`Event_Add`, `Thema Change : ${color_mode}`);
}
