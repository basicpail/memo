webMI.addOnload(function () {
  var APP = (webMI.rootWindow || window).APP;
  function init() {
	APP.bus.on("Title_Change", tapName => console.log(`APP.bus.on Title_Change: ${tapName}`));

	console.log(`Default DISPLAY Script Init!`);
  }
  (APP && APP.__ready) ? init() : webMI.trigger.connect("APP:ready", init);
});
