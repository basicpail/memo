/* app-map.js — row/axis/열 매핑 + 주소 맵 생성기 */
(function (global) {
  var root = global || window;
  var APP = (root.APP = root.APP || {});

  var ROW_25 = [
    "V1",
    "V2",
    "V3",
    "V4",
    "V5",
    "V6",
    "V7",
    "V8",
    "V9",
    "V10",
    "A1",
    "A2",
    "A3",
    "A4",
    "A5",
    "A6",
    "A7",
    "A8",
    "A9",
    "A10",
    "L1",
    "L2",
    "L3",
    "L4",
    "L12",
  ]; // 필요 시 정확히 교정
  var AXIS = ["V", "A", "L"];

  function rows(n) {
    return n === 25 ? ROW_25.slice() : ROW_25.slice(0, n || ROW_25.length);
  }
  function axes() {
    return AXIS.slice();
  }

  // 템플릿 빌더: "/AGENT.OBJECTS....${page}.${tap}.${row}.${axis}.${col}"
  function buildFromTemplate(tpl, ctx) {
    return tpl.replace(/\$\{(\w+)\}/g, function (_, k) {
      return ctx[k] != null ? String(ctx[k]) : "";
    });
  }

  // 행×열 맵: (rows × cols) → { cellId : address }
  function mapGrid(opt) {
    var r = opt.rows || rows(25);
    var c = opt.cols || [];
    var idFn = opt.id || ((ctx) => ctx.row + "_" + ctx.col);
    var addrTpl = opt.addrTpl; // ex) "AGENT.OBJECTS....${page}.${tap}.${row}.${col}"
    var ctxBase = opt.ctx || {}; // {page,tap,axis,...}

    var map = {};
    r.forEach(function (row) {
      c.forEach(function (col) {
        var ctx = Object.assign({ row: row, col: col }, ctxBase);
        var id = idFn(ctx);
        var addr =
          typeof addrTpl === "function"
            ? addrTpl(ctx)
            : buildFromTemplate(addrTpl, ctx);
        map[id] = addr;
      });
    });
    return map;
  }

  // 행×축×열 맵: axis가 있는 변형
  function mapAxisGrid(opt) {
    var r = opt.rows || rows(25);
    var a = opt.axes || axes();
    var c = opt.cols || [];
    var idFn = opt.id || ((ctx) => ctx.axis + "_" + ctx.row + "_" + ctx.col);
    var addrTpl = opt.addrTpl;
    var ctxBase = opt.ctx || {};
    var map = {};
    r.forEach(function (row) {
      a.forEach(function (axis) {
        c.forEach(function (col) {
          var ctx = Object.assign({ row: row, axis: axis, col: col }, ctxBase);
          var id = idFn(ctx);
          var addr =
            typeof addrTpl === "function"
              ? addrTpl(ctx)
              : buildFromTemplate(addrTpl, ctx);
          map[id] = addr;
        });
      });
    });
    return map;
  }

  APP.map = APP.map || {
    rows: rows,
    axes: axes,
    buildFromTemplate: buildFromTemplate,
    grid: mapGrid, // 행×열
    axisGrid: mapAxisGrid, // 행×축×열
  };
})(webMI.rootWindow || window);
