/* app-nav.js — 사이드 네비 페이지 이동(주소 맵) */
(function (global) {
  var root = global || window;
  var APP = (root.APP = root.APP || {});

  var DISP = {
    Outline: "AGENT.DISPLAYS.MAIN_DISPLAY",
    DGS: "AGENT.DISPLAYS.00.Main.Degaussing",
    CPS: "AGENT.DISPLAYS.00.Main.Data_PSU",
    MAG: "AGENT.DISPLAYS.00.Main.Data_MagneticField",
    Probe: "AGENT.DISPLAYS.00.Main.Data_Probe",
    Function: "AGENT.DISPLAYS.00.Main.Setting_Function",
    System: "AGENT.DISPLAYS.00.Main.Setting_System",
    Test: "AGENT.DISPLAYS.00.Main.Setting_Test",
    IGRF: "AGENT.DISPLAYS.00.Main.Setting_IGRF",
    Chart: function (mode) {
      return (
        "AGENT.DISPLAYS.00.Main.Chart_" +
        (mode || (APP.state && APP.state.theme) || "Day")
      );
    },
    MSG: "AGENT.DISPLAYS.00.Main.Message_LiveHistory",
  };

  APP.nav = APP.nav || {
    goto: function (tap) {
      var addr =
        tap === "Chart" ? DISP.Chart(APP.state && APP.state.theme) : DISP[tap];
      if (!addr) return;
      APP.actions.setNowTap(tap);
      APP.actions.setTitle(tap);
      webMI.display.openDisplay(addr);
    },
    DISP: DISP,
  };
})(webMI.rootWindow || window);
