/* app-popup.js — 팝업/텍스트/적용팝업 + 차단막 연결 */
(function (global) {
  var root = global || window;
  var APP = (root.APP = root.APP || {});

  // 프로젝트에서 쓰던 트리거 래핑
  //  - Popup_Open              (기본 팝업 열기)
  //  - Apply_popup_Open        (적용/확인 팝업)
  //  - Popup_Text              (팝업 내용 바꾸기)
  //  - Prevention_req {open/close, parameter}
  function fire(name, value) {
    try {
      webMI.trigger.fire(name, value);
    } catch (_) {}
  }

  APP.popup = APP.popup || {
    open: function (tag) {
      fire("Popup_Open", tag || true);
      APP.overlay && APP.overlay.open(tag);
    },
    applyOpen: function (meta) {
      fire("Apply_popup_Open", meta || true);
      APP.overlay && APP.overlay.open("apply");
    },
    setText: function (title, body) {
      fire("Popup_Text", { title: title || "", text: body || "" });
    },
    close: function () {
      APP.overlay && APP.overlay.close();
    },
  };
})(webMI.rootWindow || window);
