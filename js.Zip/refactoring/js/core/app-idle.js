/* app-idle.js — 프레임 입력 시 유휴 카운터 리셋 */
(function (global) {
  var root = global || window;
  var APP = (root.APP = root.APP || {});

  APP.idle = APP.idle || {
    attach: function (frameId, opt) {
      try {
        var f = root.document.getElementById(frameId);
        if (!f) return;
        function bind() {
          try {
            var w = f.contentWindow,
              b = w && w.document && w.document.body;
            if (!b) return setTimeout(bind, 100);
            function reset() {
              if (opt && opt.onReset) opt.onReset();
            }
            ["click", "keydown", "touchstart"].forEach(function (ev) {
              b.addEventListener(ev, reset, true);
            });
          } catch (_) {}
        }
        bind();
      } catch (_) {}
    },
  };
})(webMI.rootWindow || window);
