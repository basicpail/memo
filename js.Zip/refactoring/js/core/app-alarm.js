/* app-alarm.js — Alarm_Live_List 주기 집계 → alarm:update 방송 */
(function (global) {
  var root = global || window;
  var APP = (root.APP = root.APP || {});

  APP.alarm =
    APP.alarm ||
    (function () {
      var timer = null,
        cycle = 800;

      function start(opt) {
        if (timer) stop();
        cycle = (opt && opt.cycleMs) || cycle;
        loop();
      }
      function stop() {
        if (timer) {
          clearTimeout(timer);
          timer = null;
        }
      }

      function loop() {
        try {
          webMI.data.call("Alarm_Live_List", {}, function (list) {
            var warn = 0,
              alm = 0,
              fault = 0,
              nonAck = 0;
            (list || []).forEach(function (a) {
              var g =
                a.Groups && a.Groups[0]
                  ? String(a.Groups[0]).split(".").pop().trim()
                  : "";
              if (g === "Warning") warn++;
              else if (g === "Alarm") alm++;
              else if (g === "Fault") fault++;
              if (a.state === 1) nonAck++;
            });
            var total = warn + alm + fault;
            localStorage.setItem("warning_num", warn);
            localStorage.setItem("fault_num", fault);
            localStorage.setItem("total_alarm_num", total);
            localStorage.setItem("non_ack_num", nonAck);
            (APP.bus || { emit: () => {} }).emit(
              APP.EVT ? APP.EVT.ALARM_UPDATE : "alarm:update",
              { warn, alm, fault, nonAck, total }
            );
          });
        } catch (_) {}
        timer = setTimeout(loop, cycle);
      }

      return { start: start, stop: stop };
    })();
})(webMI.rootWindow || window);
