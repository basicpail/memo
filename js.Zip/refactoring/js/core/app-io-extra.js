/* app-io-extra.js — APP.io 확장: readMany/writeMany/subMany + Temp */
(function (global) {
  var root = global || window;
  var APP = (root.APP = root.APP || {});
  var io = (APP.io = APP.io || {});

  // 병렬 read (순서 보장)
  io.readMany = function (addresses) {
    addresses = [].concat(addresses || []);
    return Promise.all(
      addresses.map(function (addr) {
        return new Promise(function (res) {
          webMI.data.read(addr, function (r) {
            res({ addr: addr, value: r && r.value, error: r && r.error });
          });
        });
      })
    );
  };

  // 병렬 write
  io.writeMany = function (pairs) {
    // pairs: [{addr, value}]
    pairs = [].concat(pairs || []);
    return Promise.all(
      pairs.map(function (p) {
        return new Promise(function (res) {
          webMI.data.write(p.addr, p.value, function (r) {
            res({ addr: p.addr, ok: !(r && r.error), error: r && r.error });
          });
        });
      })
    );
  };

  // 여러 주소 구독 → 단일 해제 함수
  io.subMany = function (addresses, cb) {
    var ids = [];
    [].concat(addresses || []).forEach(function (addr) {
      var id = webMI.data.subscribe(addr, function (r) {
        cb && cb({ addr: addr, value: r && r.value, raw: r });
      });
      ids.push(id);
    });
    return function unsubscribeAll() {
      try {
        ids.forEach(function (id) {
          webMI.data.unsubscribe(id);
        });
      } catch (_) {}
    };
  };

  // _Temp 헬퍼
  io.temp = {
    addr: function (addr) {
      return String(addr) + "_Temp";
    },
    write: function (addr, v) {
      return io.write(io.temp.addr(addr), v);
    },
    writeMany: function (pairs) {
      return io.writeMany(
        [].concat(pairs || []).map(function (p) {
          return { addr: io.temp.addr(p.addr), value: p.value };
        })
      );
    },
  };
})(webMI.rootWindow || window);
