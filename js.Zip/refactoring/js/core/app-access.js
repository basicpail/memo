/* app-access.js — 권한 확인, 차단막/팝업, 이벤트 기록 */
(function (global) {
  var root = global || window;
  var APP = (root.APP = root.APP || {});

  APP.access = APP.access || {
    check: function (level) {
      return new Promise(function (res) {
        webMI.trigger.fire("Prevention_Check", {
          level: level,
          callback: function (ok) {
            res(!!ok);
          },
        });
      });
    },
  };

  APP.overlay = APP.overlay || {
    open: function (tag) {
      webMI.trigger.fire("Prevention_req", {
        req: "open",
        parameter: tag || "",
      });
    },
    close: function () {
      webMI.trigger.fire("Prevention_req", { req: "close" });
    },
  };

  APP.event = APP.event || {
    add: function (text) {
      try {
        webMI.callExtension(
          "SYSTEM.LIBRARY.PROJECT.QUICKDYNAMICS.AddEvent",
          text
        );
      } catch (_) {}
    },
    allAck: function () {
      try {
        webMI.rootWindow.webMI.callExtension(
          "SYSTEM.LIBRARY.ATVISE.QUICKDYNAMICS.Alarmmanagement",
          { id: "" }
        );
        webMI.data.call("Alarm_Live_List", {}, function (list) {
          (list || []).forEach(function (a) {
            webMI.alarm.accept(a.address);
          });
        });
      } catch (_) {}
    },
  };
})(webMI.rootWindow || window);
