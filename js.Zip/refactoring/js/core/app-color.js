/* app-color.js — Day/Night 팔레트 + 바인딩 헬퍼 */
(function (global) {
  "use strict";
  var root = global || window;
  var APP = (root.APP = root.APP || {});
  var EVT = APP.EVT || { THEME_CHANGED: "theme:changed" };

  // 팔레트(너가 준 키만 사용)
  var P = {
    BtnLamp_Off: { Day: "#c3c3c3", Night: "#3b3b3b" },
    BtnLamp_On: { Day: "#3290ed", Night: "#0675fa" },
    Btn_Background: { Day: "#d2d2d2", Night: "#2d2d2d" },
    Btn_Background_Down: { Day: "#919191", Night: "#9e9e9e" },
    Main_Background: { Day: "#e0e0e0", Night: "#0a0a0a" },
    DataCell_Background: { Day: "#ff0000", Night: "#383838" },
    Font_Default: { Day: "#464646", Night: "#c8c8c8" },
    Font_Selected_Data: { Day: "#3290ed", Night: "#0675fa" },
    Table_Border: { Day: "#bbbbbb", Night: "#535353" },
    Table_Header_Background: { Day: "#00ff00", Night: "#0a0a0a" },
    Table_Cell_Background_Control: { Day: "#f5f5f5", Night: "#0a0a0a" },
    Table_Cell_Background_Monitoring: { Day: "#d9d9d9", Night: "#373737" },
    Selected: { Day: "#3290ed", Night: "#0675fa" },
    Btn_Title: { Day: "#0000ff", Night: "#0a0a0a" },
    Btn_Title_Down: { Day: "#f0f0f0", Night: "#3a3a3a" },
    Font_Table_Data: { Day: "#000000", Night: "#ffffff" },
    Table_Title: { Day: "#e6e6e6", Night: "#191919" },
    Font_Selected_Title: { Day: "#000000", Night: "#ffffff" },
    Font_Disable: { Day: "#afafaf", Night: "#424242" },
    Tab_Selected_Title_Background: { Day: "#f0f0f0", Night: "#3a3a3a" },
    Scroll_Backgroud: { Day: "", Night: "#0a0a0a" },
    Scroll_Bar: { Day: "", Night: "#535353" },
    Table_Cell_Background_Red: { Day: "#560001", Night: "#560001" },
    Bento: { Day: "#e6e6e6", Night: "#191919" },
    Top_Bento: { Day: "#d2d2d2", Night: "#2d2d2d" },
    TextBox_Stroke: { Day: "#bbbbbb", Night: "#535353" },
    Under_Line: { Day: "#b1b1b1", Night: "#4e4e4e" },
    Selected_Magnetic_Table_Stroke: { Day: "#3290ed", Night: "#0a6fdb" },
    Selected_Magnetic_Table_Title_Fill: { Day: "#f5f5f5", Night: "#0a0a0a" },
    Selected_Magnetic_Table_Data_Fill: { Day: "#d9d9d9", Night: "#373737" },
    Magnetic_Table_Normal_Line: { Day: "#bbbbbb", Night: "#535353" },
    Normal_Magnetic_Table_Title_Fill: { Day: "#00ff00", Night: "#161616" },
    Normal_Magnetic_Table_Data_Fill: { Day: "#00ff00", Night: "#373737" },
    Normal_Magnetic_Table_Stroke: { Day: "#00ff00", Night: "#b4b4b4" },
    Font_Title: { Day: "#5f5f5f", Night: "#b4b4b4" },
    Font_Combobox_Select: { Day: "", Night: "#ffffff" },
    Font_Combobox_Default: { Day: "", Night: "#acacac" },
    Line_Com_Normal: { Day: "#008480", Night: "#00847d" },
    Line_Com_Fault: { Day: "#ed0000", Night: "#ed0000" },
    Popup_Stroke: { Day: "#505050", Night: "#7f7f7f" },
    Popup_Font_Title: { Day: "#f0f0f0", Night: "#0a0a0a" },
    Popup_Rect: { Day: "#505050", Night: "#b7b7b7" },
    Line_Com_Normal_Popup: { Day: "#505050", Night: "#acacac" },
    Btn_Background_DataFreq_Apply: { Day: "#91cdff", Night: "#013c7c" },
    Btn_Background_DataFreq_Selected: { Day: "#aaaaaa", Night: "#777777" },
    Green_Active: { Day: "#008e0d", Night: "#008e0d" },
    White: { Day: "#ffffff", Night: "#ffffff" },
    Purple: { Day: "#ff00ff", Night: "#ff00ff" },
    Red: { Day: "#ed0000", Night: "#ed0000" },
    Popup_Border: { Day: "#505050", Night: "#7f7f7f" },
    Yellow: { Day: "#ffff00", Night: "#ffff00" },
    Alarm: { Day: "#ed0000", Night: "#ed0000" },
    MSG_Table_Border: { Day: "#535353", Night: "#535353" },
    Icon_Default: { Day: "#414141", Night: "#dcdcdc" },
    Black: { Day: "#000000", Night: "#000000" },
  };

  function getFrom(key, mode) {
    var o = P[key];
    if (!o) return null;
    var v = o[mode];
    if (v === "" || v == null) v = o[mode === "Day" ? "Night" : "Day"] || null;
    return v;
  }

  function ColorManager() {
    this.modeKey = "Color_Mode";
    this.mode = localStorage.getItem(this.modeKey) || "Day";
    this.palette = P;
    this._maps = [];
    this._wired = false;
  }

  ColorManager.prototype.init = function (opt) {
    if (opt && opt.defaultMode) this.mode = opt.defaultMode;
    if (!this._wired) {
      (APP.bus || { on: function () {} }).on(EVT.THEME_CHANGED, (m) => {
        this._applyMode(m, { persist: true });
      });
      this._wired = true;
    }
    this._applyAll();
  };

  ColorManager.prototype.get = function (key, mode) {
    return getFrom(key, mode || this.mode);
  };
  ColorManager.prototype.keys = function () {
    return Object.keys(this.palette);
  };

  ColorManager.prototype.setMode = function (mode) {
    if (APP.actions && APP.actions.setTheme) return APP.actions.setTheme(mode);
    this._applyMode(mode, { persist: true });
    (APP.bus || { emit: () => {} }).emit(EVT.THEME_CHANGED, mode);
  };

  ColorManager.prototype.bind = function (map) {
    this._maps.push(map);
    this.applyMap(map);
    var self = this;
    return function unbind() {
      self._maps = self._maps.filter((m) => m !== map);
    };
  };

  ColorManager.prototype.applyMap = function (map, mode) {
    mode = mode || this.mode;
    Object.keys(map || {}).forEach((id) => {
      var spec = map[id];
      if (typeof spec === "string") {
        var c = getFrom(spec, mode);
        if (c)
          try {
            webMI.gfx.setFill(id, c);
          } catch (_) {}
      } else if (spec && typeof spec === "object") {
        if (spec.fill) {
          var f = getFrom(spec.fill, mode);
          if (f)
            try {
              webMI.gfx.setFill(id, f);
            } catch (_) {}
        }
        if (spec.text) {
          var t = getFrom(spec.text, mode);
          if (t)
            try {
              webMI.gfx.setFill(id, t);
            } catch (_) {}
        }
        if (spec.stroke && webMI.gfx.setStroke) {
          var s = getFrom(spec.stroke, mode);
          if (s)
            try {
              webMI.gfx.setStroke(id, s);
            } catch (_) {}
        }
        if (spec.opacity != null) {
          var o = Number(spec.opacity);
          if (!isNaN(o))
            try {
              webMI.gfx.setFillOpacity(id, o);
            } catch (_) {}
        }
      }
    });
  };

  ColorManager.prototype._applyAll = function () {
    var mode = this.mode;
    var self = this;
    this._maps.forEach(function (m) {
      self.applyMap(m, mode);
    });
  };

  ColorManager.prototype._applyMode = function (mode, opt) {
    this.mode = mode || this.mode;
    if (!opt || opt.persist !== false)
      localStorage.setItem(this.modeKey, this.mode);
    this._applyAll();
  };

  APP.Color = APP.Color || new ColorManager();
})(webMI.rootWindow || window);
