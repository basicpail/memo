/* app-ui.js — 버튼 활성/비활성 공통 처리 + 트리거 핸들 */
(function (global) {
  var root = global || window;
  var APP = (root.APP = root.APP || {});

  // 안전 유틸
  function setOpacity(id, v) {
    try {
      webMI.gfx.setFillOpacity(id, v);
    } catch (_) {}
  }
  function setPointerEvents(id, on) {
    try {
      var el = document.getElementById(id);
      if (el) el.style.pointerEvents = on ? "auto" : "none";
    } catch (_) {}
  }
  function setFill(id, c) {
    try {
      webMI.gfx.setFill(id, c);
    } catch (_) {}
  }

  // 비활성/활성 표준 스타일
  function applyDisabledVisual(id) {
    var mode = (APP.state && APP.state.theme) || "Day";
    var gray =
      APP.Color && APP.Color.get
        ? APP.Color.get("Font_Disable", mode)
        : "#9e9e9e";
    setOpacity(id, 0.5);
    setPointerEvents(id, false);
    // 배경/라벨 규칙이 분리된 경우: id 규칙에 맞춰 보조 처리
    if (id.endsWith("_background")) setFill(id, gray);
  }
  function clearDisabledVisual(id) {
    setOpacity(id, 1);
    setPointerEvents(id, true);
  }

  APP.ui = APP.ui || {
    inactive: function (ids) {
      [].concat(ids || []).forEach(applyDisabledVisual);
    },
    active: function (ids) {
      [].concat(ids || []).forEach(clearDisabledVisual);
    },
    toggle: function (id, disabled) {
      disabled ? applyDisabledVisual(id) : clearDisabledVisual(id);
    },
  };

  // 공통 토픽 수신: "btn_inactive", "btn_active"
  // payload: string | string[]
  (APP.bus || { on: function () {} }).on("btn_inactive", function (ids) {
    APP.ui.inactive(ids);
  });
  (APP.bus || { on: function () {} }).on("btn_active", function (ids) {
    APP.ui.active(ids);
  });
})(webMI.rootWindow || window);
