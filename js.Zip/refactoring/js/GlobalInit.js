/* GlobalInit.js — 전역 런타임 부팅 */
webMI.addOnload(function () {
  var root = webMI.rootWindow || window;

  // 중복 부팅 방지
  if (root.APP && root.APP.__booted) return;

  // 전역 네임스페이스
  var APP = (root.APP = root.APP || {});
  APP.__booted = true;
  APP.__ready = false;
  APP.version = "2025-09-02";

  // ── Config ─────────────────────────────────────────────────────
  APP.config = APP.config || {};
  APP.config.mainFrameId = APP.config.mainFrameId || "mainframe";
  APP.config.cacheBust = "v=" + APP.version;

  // ── Events / Bus / Constants ───────────────────────────────────
  APP.EVT = {
    APP_READY: "APP:ready",
    THEME_CHANGED: "theme:changed",
    DEMO_ON: "demo:on",
    ALARM_UPDATE: "alarm:update",
    TITLE_CHANGE: "Title_Change",
  };

  APP.bus = APP.bus || {
    on: function (topic, cb) {
      return webMI.trigger.connect(topic, function (e) {
        cb && cb(e && e.value, e);
      });
    },
    emit: function (topic, payload) {
      webMI.trigger.fire(topic, payload);
    },
    off: function (id) {
      if (webMI.trigger.disconnect)
        try {
          webMI.trigger.disconnect(id);
        } catch (_) {}
    },
    ns: function (ns) {
      var b = this;
      return {
        on: (ev, cb) => b.on(ns + ":" + ev, cb),
        emit: (ev, p) => b.emit(ns + ":" + ev, p),
      };
    },
  };

  // ── Global State & Actions (DOM 비의존) ─────────────────────────
  APP.state = APP.state || {
    theme: localStorage.getItem("Color_Mode") || "Day",
    user: {
      name: localStorage.getItem("UserName") || "-",
      level: localStorage.getItem("UserLevel") || "Level1",
    },
  };

  APP.actions = APP.actions || {
    setTheme: function (mode) {
      APP.state.theme = mode;
      localStorage.setItem("Color_Mode", mode);
      APP.bus.emit(APP.EVT.THEME_CHANGED, mode);
    },
    setTitle: function (name) {
      APP.bus.emit(APP.EVT.TITLE_CHANGE, name);
    },
    setNowTap: function (tap) {
      localStorage.setItem("Now_Tap", tap);
    },
  };

  // ── I/O helpers (Promise & unsubscribe) ────────────────────────
  APP.io = APP.io || {
    read: function (addr) {
      return new Promise(function (res, rej) {
        webMI.data.read(addr, function (r) {
          r && r.error ? rej(r.error) : res(r && r.value);
        });
      });
    },
    write: function (addr, val) {
      return new Promise(function (res, rej) {
        webMI.data.write(addr, val, function (r) {
          r && r.error ? rej(r.error) : res();
        });
      });
    },
    sub: function (addr, cb) {
      var id = webMI.data.subscribe(addr, function (r) {
        cb && cb(r && r.value, r);
      });
      return function () {
        try {
          webMI.data.unsubscribe(id);
        } catch (_) {}
      };
    },
  };

  // ── DOM helpers (디스플레이용) ─────────────────────────────────
  APP.dom = APP.dom || {
    frame: function () {
      var f = root.document.getElementById(APP.config.mainFrameId);
      return f && f.contentWindow
        ? { win: f.contentWindow, doc: f.contentWindow.document }
        : null;
    },
    waitForIds: function (ids, cb, tries, gap) {
      tries = tries == null ? 40 : tries;
      gap = gap == null ? 50 : gap;
      (function poll() {
        var miss = ids.filter(function (id) {
          return !document.getElementById(id);
        });
        if (miss.length === 0) return cb();
        if (tries-- <= 0) return cb(); // 있는 것만 바인딩
        setTimeout(poll, gap);
      })();
    },
  };

  // ── 모듈 로더(순차) ────────────────────────────────────────────
  APP.loadModules = function (urls, done) {
    urls = (urls || []).filter(Boolean);
    if (!urls.length) {
      done && done();
      return;
    }

    var i = 0;
    (function next() {
      if (i >= urls.length) {
        done && done();
        return;
      }
      var url = urls[i++];
      if (root.document.querySelector('script[data-app-mod="' + url + '"]'))
        return next();
      var s = root.document.createElement("script");
      s.type = "text/javascript";
      s.src = url + (url.indexOf("?") > -1 ? "&" : "?") + APP.config.cacheBust;
      s.setAttribute("data-app-mod", url);
      s.onload = next;
      s.onerror = function (e) {
        console.error("[GlobalInit] fail:", url, e);
        next();
      };
      root.document.head.appendChild(s);
    })();
  };

  // ── 공용 모듈 목록 (갱신됨) ─────────────────────────────────────
  var baseModules = [
    "/js/core/app-core.js",
    "/js/core/app-const.js",
    "/js/core/app-color.js",
    "/js/core/app-access.js",
    "/js/core/app-popup.js",
    "/js/core/app-ui.js",
    "/js/core/app-idle.js",
    "/js/core/app-map.js",
    "/js/core/app-io-extra.js",
    "/js/core/app-table.js",
    "/js/core/app-format.js",
    "/js/core/app-addr.js",
    "/js/core/app-alarm.js",
    "/js/core/app-nav.js",
  ];

  // ── 모듈 로드 & 초기화 ─────────────────────────────────────────
  APP.loadModules(baseModules, function () {
    try {
      if (APP.Color && APP.Color.init)
        APP.Color.init({ defaultMode: APP.state.theme });
      if (APP.idle && APP.idle.attach)
        APP.idle.attach(APP.config.mainFrameId, {
          onReset: function () {
            localStorage.setItem("NoTouchCount", 0);
          },
        });
      if (APP.alarm && APP.alarm.start) APP.alarm.start({ cycleMs: 800 });
    } catch (e) {
      console.error("[GlobalInit] init error:", e);
    }

    APP.__ready = true;
    APP.bus.emit(APP.EVT.APP_READY, true);
  });
});
