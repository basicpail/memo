// Default Display — GLUE (DOM 전용)
webMI.addOnload(function () {
  var root = webMI.rootWindow || window;

  function sideColorSet(APP, nowTap) {
    var mode = (APP.state && APP.state.theme) || "Day";
    var C = APP.Color;
    var list = [
      "Outline",
      "DGS",
      "CPS",
      "MAG",
      "Probe",
      "Function",
      "System",
      "Test",
      "IGRF",
      "Chart",
      "MSG",
    ];
    list.forEach(function (tap) {
      var bgId = "btn_" + tap + "_background";
      var lbId = "btn_" + tap + "_label";
      if (tap === nowTap) {
        try {
          webMI.gfx.setFill(bgId, C.get("Selected", mode));
        } catch (_) {}
        try {
          webMI.gfx.setFill(lbId, C.get("White", mode));
        } catch (_) {}
      } else {
        try {
          webMI.gfx.setFill(bgId, "none");
        } catch (_) {}
        try {
          webMI.gfx.setFill(lbId, C.get("Font_Table_Data", mode));
        } catch (_) {}
      }
    });
  }

  function bind(APP) {
    // 1) 기본 테마 바인딩
    APP.Color.bind({
      back_display: { fill: "Main_Background" },
      side: { fill: "Top_Bento" },
    });

    // 2) 사이드 버튼 → 페이지 이동
    var tapMap = {
      btn_Outline: "Outline",
      btn_DGS: "DGS",
      btn_CPS: "CPS",
      btn_MAG: "MAG",
      btn_Probe: "Probe",
      btn_Function: "Function",
      btn_System: "System",
      btn_Test: "Test",
      btn_IGRF: "IGRF",
      btn_Chart: "Chart",
      btn_MSG: "MSG",
    };
    Object.keys(tapMap).forEach(function (id) {
      try {
        webMI.addEvent(id, "click", function () {
          var tap = tapMap[id];
          APP.nav.goto(tap);
          APP.actions.setNowTap(tap);
          sideColorSet(APP, tap);
          localStorage.setItem("Chart_Display", tap === "Chart");
        });
      } catch (_) {}
    });

    // 3) 사이드 트리 열기/닫기 (y 좌표 재배치)
    var SP = 71.296;
    function setY(id, val) {
      try {
        document.getElementById(id).setAttribute("y", String(val));
      } catch (_) {}
    }

    function openData(open) {
      try {
        webMI.gfx.setText("btn_Data_text_arrow", open ? "∨" : ">");
      } catch (_) {}
      localStorage.setItem("data_open", !!open);
      try {
        webMI.gfx.setVisible("btn_CPS", open);
      } catch (_) {}
      try {
        webMI.gfx.setVisible("btn_MAG", open);
      } catch (_) {}
      try {
        webMI.gfx.setVisible("btn_Probe", open);
      } catch (_) {}
      var yData = parseFloat(
        (document.getElementById("btn_Data") || {}).getAttribute?.("y") || 0
      );
      var y = yData + (open ? SP : 0);
      setY("btn_CPS", y + SP * 0);
      setY("btn_MAG", y + SP * 1);
      setY("btn_Probe", y + SP * 2);
      setY("btn_Setting", yData + (open ? SP * 3 : SP));
    }

    function openSetting(open) {
      try {
        webMI.gfx.setText("btn_Setting_text_arrow", open ? "∨" : ">");
      } catch (_) {}
      localStorage.setItem("setting_open", !!open);
      ["btn_Function", "btn_System", "btn_Test", "btn_IGRF"].forEach(function (
        id
      ) {
        try {
          webMI.gfx.setVisible(id, open);
        } catch (_) {}
      });
      var ySet = parseFloat(
        (document.getElementById("btn_Setting") || {}).getAttribute?.("y") || 0
      );
      setY("btn_Function", ySet + (open ? SP : 0));
      setY("btn_System", ySet + (open ? SP * 2 : 0));
      setY("btn_Test", ySet + (open ? SP * 3 : 0));
      setY("btn_IGRF", ySet + (open ? SP * 4 : 0));
      var base = parseFloat(
        (document.getElementById("btn_IGRF") || {}).getAttribute?.("y") || ySet
      );
      setY("btn_Chart", base + SP);
      setY("btn_MSG", base + SP * 2);
    }

    try {
      webMI.addEvent("btn_Data", "click", function () {
        var t = webMI.gfx.getText("btn_Data_text_arrow");
        openData(t === ">");
      });
    } catch (_) {}
    try {
      webMI.addEvent("btn_Setting", "click", function () {
        var t = webMI.gfx.getText("btn_Setting_text_arrow");
        openSetting(t === ">");
      });
    } catch (_) {}

    // 4) 알람 집계 → MSG 버튼 시그널
    var blink = false;
    APP.bus.on(APP.EVT.ALARM_UPDATE, function (a) {
      var mode = (APP.state && APP.state.theme) || "Day";
      var C = APP.Color;
      var nowTap = localStorage.getItem("Now_Tap") || "Outline";
      var noAlarmBg = nowTap === "MSG" ? C.get("Selected", mode) : "none";

      if (a.total > 0) {
        blink = !blink;
        var apply = blink ? C.get("Red", mode) : noAlarmBg;
        try {
          webMI.gfx.setFill(
            "btn_MSG_background",
            a.nonAck > 0 ? apply : C.get("Red", mode)
          );
        } catch (_) {}
      } else {
        try {
          webMI.gfx.setFill("btn_MSG_background", noAlarmBg);
        } catch (_) {}
      }
      var noneBg = false;
      try {
        noneBg = webMI.gfx.getFill("btn_MSG_background") === "none";
      } catch (_) {}
      try {
        webMI.gfx.setFill(
          "btn_MSG_label",
          noneBg ? C.get("Font_Table_Data", mode) : C.get("White", mode)
        );
      } catch (_) {}
    });

    // 5) 확장 버튼(팝업 영역 토글)
    try {
      var expanded = false;
      webMI.addEvent("btn_expansion_click", "click", function () {
        try {
          var ctl = document.getElementById("btn_expansion");
          if (!expanded) {
            if (ctl) ctl.href.baseVal = "../../Icon/reduction1.png";
            webMI.gfx.setVisible("Top_Popup", true);
            APP.overlay.open("함 정보");
          } else {
            if (ctl) ctl.href.baseVal = "../../Icon/Extension1.png";
            webMI.gfx.setVisible("Top_Popup", false);
            APP.overlay.close();
          }
          expanded = !expanded;
        } catch (_) {}
      });
    } catch (_) {}

    // 6) 초기 상태 복구 & 테마 반응
    var now = localStorage.getItem("Now_Tap") || "Outline";
    sideColorSet(APP, now);
    if (localStorage.getItem("data_open") === "true") openData(true);
    if (localStorage.getItem("setting_open") === "true") openSetting(true);
    APP.bus.on(APP.EVT.THEME_CHANGED, function () {
      sideColorSet(APP, localStorage.getItem("Now_Tap") || "Outline");
    });

    // 7) 시작 시 기본 배경/사이드 보정(안전)
    try {
      webMI.gfx.setFill(
        "back_display",
        APP.Color.get("Main_Background", APP.state.theme)
      );
      webMI.gfx.setFill("side", APP.Color.get("Top_Bento", APP.state.theme));
    } catch (_) {}
  }

  // 전역 준비 + DOM 준비를 기다렸다가 바인딩
  function startWhenReady() {
    var ids = [
      "back_display",
      "side",
      "btn_Data",
      "btn_Setting",
      "btn_Outline",
      "btn_DGS",
      "btn_CPS",
      "btn_MAG",
      "btn_Probe",
      "btn_Function",
      "btn_System",
      "btn_Test",
      "btn_IGRF",
      "btn_Chart",
      "btn_MSG",
      "btn_expansion_click",
    ];
    root.APP && root.APP.dom && root.APP.dom.waitForIds
      ? root.APP.dom.waitForIds(ids, function () {
          bind(root.APP);
        })
      : bind(root.APP);
  }

  if (root.APP && root.APP.__ready) startWhenReady();
  else webMI.trigger.connect("APP:ready", startWhenReady);
});
