// Degaussing — GLUE (DOM 전용, 전역은 APP.* 사용)
webMI.addOnload(function () {
  var root = webMI.rootWindow || window;

  // ───────────────────────────────────────────────────────────────
  // 주소/라벨 ID 규칙을 프로젝트에 맞게 교체
  // ───────────────────────────────────────────────────────────────
  var ADDR = {
    // TODO: 실제 OPC 주소로 교체
    DGM_MODE: "AGENT.OBJECTS.02.Degaussing.Degaussing_Mode._DGM",
    DATA_SOURCE: "AGENT.OBJECTS.Control._DATA_Source",
    PSU_SUM: "AGENT.OBJECTS.02.Degaussing.PSU_Sum", // (있다면) 합계
    CMD: "AGENT.OBJECTS.02.Degaussing.Cmd", // (있다면) start/stop 명령
  };

  // DGM_MODE 값 → UI 의미 매핑 (예시)
  var MODE_LABEL = {
    0: "IDLE",
    1: "RUN",
    2: "HOLD",
    3: "STOPPING",
  };

  function bind(APP) {
    // 1) 테마
    APP.Color.bind({
      background_display: { fill: "Main_Background" },
      label_title: { text: "Font_Title" },
    });

    // 2) 모드/소스/합계 표시
    var unsub = APP.io.subMany(
      [ADDR.DGM_MODE, ADDR.DATA_SOURCE, ADDR.PSU_SUM],
      function ({ addr, value }) {
        try {
          if (addr === ADDR.DGM_MODE) {
            var txt = MODE_LABEL.hasOwnProperty(value)
              ? MODE_LABEL[value]
              : String(value);
            webMI.gfx.setText("lbl_dgm_mode", txt);
            // 모드에 따른 버튼 상태
            var running = String(txt).toUpperCase() === "RUN" || value === 1;
            APP.ui.toggle("btn_start", running); // 실행 중이면 start 비활성
            APP.ui.toggle("btn_stop", !running); // 실행 중 아니면 stop 비활성
          }
          if (addr === ADDR.DATA_SOURCE) {
            webMI.gfx.setText("lbl_source", String(value));
          }
          if (addr === ADDR.PSU_SUM) {
            webMI.gfx.setText("lbl_psu_sum", String(value));
          }
        } catch (_) {}
      }
    );

    // 3) Start / Stop 버튼
    function issueCmd(kind) {
      APP.access.check(3).then(function (ok) {
        if (!ok) return;
        var msg =
          kind === "start"
            ? "탈자를 시작하시겠습니까?"
            : "탈자를 정지하시겠습니까?";
        APP.popup.setText("Degaussing", msg);
        APP.popup.applyOpen({ type: "dgm_" + kind });

        // TODO: 실제 명령 방법에 맞게 교체
        //  - 단일 CMD 주소 사용(예: 1=start, 0=stop)
        //  - 혹은 별도 start/stop 주소가 있으면 그 주소 쓰기
        var val = kind === "start" ? 1 : 0;
        if (ADDR.CMD) {
          APP.io.write(ADDR.CMD, val).then(function () {
            APP.event &&
              APP.event.add &&
              APP.event.add("[DGM] command " + kind);
          });
        } else {
          // 예: 별도 주소라면 아래처럼
          // APP.io.write("AGENT.OBJECTS.02.Degaussing.Start", 1);
          // APP.io.write("AGENT.OBJECTS.02.Degaussing.Stop",  1);
        }
      });
    }
    try {
      webMI.addEvent("btn_start", "click", function () {
        issueCmd("start");
      });
    } catch (_) {}
    try {
      webMI.addEvent("btn_stop", "click", function () {
        issueCmd("stop");
      });
    } catch (_) {}

    // 4) 팝업 확장 버튼(있다면)
    try {
      var expanded = false;
      webMI.addEvent("btn_expansion_click", "click", function () {
        try {
          var ctl = document.getElementById("btn_expansion");
          if (!expanded) {
            if (ctl) ctl.href.baseVal = "../../Icon/reduction1.png";
            webMI.gfx.setVisible("Top_Popup", true);
            APP.overlay.open("탈자 정보");
          } else {
            if (ctl) ctl.href.baseVal = "../../Icon/Extension1.png";
            webMI.gfx.setVisible("Top_Popup", false);
            APP.overlay.close();
          }
          expanded = !expanded;
        } catch (_) {}
      });
    } catch (_) {}
  }

  function start() {
    var ids = [
      "background_display",
      "label_title",
      "lbl_dgm_mode",
      "lbl_source",
      "lbl_psu_sum",
      "btn_start",
      "btn_stop",
      "btn_expansion_click", // 있다면
    ];
    root.APP && root.APP.dom && root.APP.dom.waitForIds
      ? root.APP.dom.waitForIds(ids, function () {
          bind(root.APP);
        })
      : bind(root.APP);
  }

  root.APP && root.APP.__ready
    ? start()
    : webMI.trigger.connect("APP:ready", start);
});
