// Data_PSU — GLUE (DOM 전용, 전역은 APP.* 사용)
webMI.addOnload(function () {
  var root = webMI.rootWindow || window;

  // ───────────────────────────────────────────────────────────────
  // 설정: ID 규칙과 OPC 주소 규칙만 프로젝트에 맞게 바꾸면 됨
  // ───────────────────────────────────────────────────────────────
  var CFG = {
    // TODO: 프로젝트 OPC 노드 규칙으로 교체 (예시는 구조만 보여줌)
    base: "AGENT.OBJECTS.00.PSU.01",
    cols: {
      Coeff: ["Permanent", "Induced", "Eddy"],
      Current: ["Permanent", "induced", "Eddy", "Use", "Reserve", "Sum"],
      Status: ["Active", "Active2", "WA_AL_FA", "FA"], // 실제 키에 맞게 교체
    },
    rows: (function () {
      // TODO: 실제 행 이름 세트로 교체
      // 예: V1~V10, A1~A10, L1~L12 -> 필요 목록만 반환
      var r = [];
      for (var i = 1; i <= 10; i++) {
        r.push("V" + i);
      }
      for (var i = 1; i <= 10; i++) {
        r.push("A" + i);
      }
      for (var i = 1; i <= 12; i++) {
        r.push("L" + i);
      }
      return r;
    })(),
    // 화면 ID 규칙(프로젝트에 맞게만 바꾸면 됨)
    idOf: {
      Coeff: function (row, col) {
        return "psu_coeff_" + row + "_" + col;
      },
      Current: function (row, col) {
        return "psu_cur_" + row + "_" + col;
      },
      Status: function (row, col) {
        return "psu_status_" + row + "_" + col;
      },
    },
    // 주소 템플릿(프로젝트 규칙으로 반드시 교체)
    addrTpl: {
      Coeff: "${base}.Coeff.${row}.${col}",
      Current: "${base}.Current.${row}.${col}",
      Status: "${base}.Status.${row}.${col}",
    },
  };

  // 템플릿 치환 (APP.map.buildFromTemplate과 동일 역할, 의존 줄이려 여기 포함)
  function tpl(t, ctx) {
    return t.replace(/\$\{(\w+)\}/g, function (_, k) {
      return ctx[k] != null ? String(ctx[k]) : "";
    });
  }

  // 탭 버튼 → 탭명 매핑
  var TAB_BY_BUTTON = {
    btn_current_coefficient: "Coeff",
    btn_current: "Current",
    btn_status: "Status",
  };

  // ───────────────────────────────────────────────────────────────
  function bind(APP) {
    // 1) 기본 테마 바인딩 (배경/타이틀 등)
    APP.Color.bind({
      background_display: { fill: "Main_Background" },
      title_label: { text: "Font_Title" },
      table_border: { stroke: "Table_Border" },
    });

    // 2) 탭 전환 바인딩
    Object.keys(TAB_BY_BUTTON).forEach(function (btnId) {
      try {
        webMI.addEvent(btnId, "click", function () {
          switchTab(TAB_BY_BUTTON[btnId]);
        });
      } catch (_) {}
    });

    // 3) 탭 → (ID ↔ 주소) 맵 생성
    function makeMap(tab) {
      var rows = CFG.rows;
      var cols = CFG.cols[tab];
      var idFn = CFG.idOf[tab];
      var tplStr = CFG.addrTpl[tab];

      var map = {}; // id -> addr
      rows.forEach(function (row) {
        cols.forEach(function (col) {
          var id = idFn(row, col);
          var addr = tpl(tplStr, { base: CFG.base, row: row, col: col });
          map[id] = addr;
        });
      });
      return map;
    }

    // 4) 표 채우기/구독
    var unsub = null,
      currentTab = null,
      currentMap = null;

    function applyInitialValues(resList) {
      resList.forEach(function (r) {
        var id = findIdByAddr(r.addr);
        if (!id) return;
        try {
          if (currentTab === "Status") {
            // 상태 표현은 프로젝트 규칙에 맞게 (여기선 문자열 그대로 표시)
            webMI.gfx.setText(id, r.value == null ? "" : String(r.value));
          } else {
            // 숫자 포맷이 필요하면 APP.fmt.num 사용
            webMI.gfx.setText(id, r.value == null ? "" : String(r.value));
          }
        } catch (_) {}
      });
    }

    function liveUpdate(msg) {
      var id = findIdByAddr(msg.addr);
      if (!id) return;
      try {
        webMI.gfx.setText(id, msg.value == null ? "" : String(msg.value));
      } catch (_) {}
    }

    function findIdByAddr(addr) {
      if (!currentMap) return null;
      // currentMap: id -> addr
      // 역참조: 빠른 탐색을 위해 초기화 시 역맵을 만들어도 됨
      for (var id in currentMap) if (currentMap[id] === addr) return id;
      return null;
    }

    function switchTab(tab) {
      // 기존 구독 해제
      if (unsub)
        try {
          unsub();
        } catch (_) {}
      currentTab = tab;
      currentMap = makeMap(tab);

      // 탭 선택 비주얼(선택/비선택)
      try {
        Object.keys(TAB_BY_BUTTON).forEach(function (btnId) {
          var selected = TAB_BY_BUTTON[btnId] === tab;
          var bgId = btnId + "_bg"; // 프로젝트에 맞게 버튼 배경 id가 있으면 사용
          var lbId = btnId + "_label";
          if (bgId) {
            if (selected)
              webMI.gfx.setFill(
                bgId,
                APP.Color.get("Selected", APP.state.theme)
              );
            else webMI.gfx.setFill(bgId, "none");
          }
          if (lbId) {
            webMI.gfx.setFill(
              lbId,
              selected
                ? APP.Color.get("White", APP.state.theme)
                : APP.Color.get("Font_Table_Data", APP.state.theme)
            );
          }
        });
      } catch (_) {}

      var addrs = Object.values(currentMap);

      // 초기 읽기
      APP.io.readMany(addrs).then(applyInitialValues);

      // 구독
      unsub = APP.io.subMany(addrs, liveUpdate);
    }

    // 5) 적용(쓰기) 버튼 — _Temp 에 반영 후, 상위 프로세스가 커밋
    try {
      webMI.addEvent("btn_apply", "click", function () {
        APP.access.check(3).then(function (ok) {
          if (!ok) return;

          // (예시) 편집값 수집: data-addr 속성이 있으면 그걸로, 없으면 현재 탭 맵을 기준으로 수집
          var pairs = [];
          // 5-1. data-addr 스캔
          try {
            var nodes = document.querySelectorAll(
              "[data-addr][data-edit='true']"
            );
            nodes.forEach(function (el) {
              var a = el.getAttribute("data-addr");
              var v = el.textContent || el.getAttribute("data-value");
              if (a && v != null) pairs.push({ addr: a, value: Number(v) });
            });
          } catch (_) {}

          // 5-2. 현재 탭 맵 기반으로 ID 규칙에서 값 읽기(필요 시)
          if (!pairs.length && currentMap) {
            Object.keys(currentMap).forEach(function (id) {
              try {
                // 예: 셀 텍스트를 숫자로 해석
                var val = webMI.gfx.getText(id);
                if (val != null && val !== "") {
                  pairs.push({ addr: currentMap[id], value: Number(val) });
                }
              } catch (_) {}
            });
          }

          if (!pairs.length) return;

          APP.popup.setText("적용", "변경값을 적용하시겠습니까?");
          APP.popup.applyOpen({
            type: "apply_psu",
            tab: currentTab,
            count: pairs.length,
          });

          // _Temp 로 쓰기
          APP.io.temp.writeMany(pairs).then(function () {
            APP.event &&
              APP.event.add &&
              APP.event.add("[PSU] Temp write: " + pairs.length + " item(s)");
          });
        });
      });
    } catch (_) {}

    // 최초 탭
    switchTab("Coeff");
  }

  function start() {
    var ids = [
      "background_display",
      "title_label",
      "btn_current_coefficient",
      "btn_current",
      "btn_status",
      "btn_apply",
      // 표 셀 ID는 전부 기다릴 필요 없음(없는 ID는 try/catch 로 스킵)
    ];
    root.APP && root.APP.dom && root.APP.dom.waitForIds
      ? root.APP.dom.waitForIds(ids, function () {
          bind(root.APP);
        })
      : bind(root.APP);
  }

  root.APP && root.APP.__ready
    ? start()
    : webMI.trigger.connect("APP:ready", start);
});
