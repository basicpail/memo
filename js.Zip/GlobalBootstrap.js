// GlobalBootstrap (Menu Script)
webMI.addOnload(function () {
  var root = webMI.rootWindow || window;
  if (root.APP && root.APP.__ready) return;  // 이미 로드됨

  // 전역 네임스페이스
  root.APP = root.APP || {};
  root.APP.__ready = false;

  function loadChain(urls, done) {
    var i = 0;
    (function next() {
      if (i >= urls.length) return done && done();
      var s = root.document.createElement("script");
      s.type = "text/javascript";                 // ok
      s.src  = urls[i++] + "?v=20250902";         // 캐시 방지용 버전 태그
      s.onload = next;
      root.document.head.appendChild(s);
    })();
  }

  loadChain([
    "/js/app-core.js",    // 전역 네임스페이스/버스/io 등
    "/js/app-colors.js"   // ColorManager 등
    // 필요시 "/js/psu-common.js" 등 공용 모듈 추가
  ], function () {
    root.APP.__ready = true;
    webMI.trigger.fire("APP:ready", true);        // 모든 Display에 알림
  });
});
