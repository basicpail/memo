// /js/app-colors.js
// 프로젝트 전역 팔레트 & ColorManager
(function (global) {
  "use strict";
  var root = global || window;
  var APP  = root.APP = (root.APP || {});

  // 이벤트 이름(있으면 사용, 없으면 기본값)
  var EVT = (APP.EVT || {});
  var THEME_CHANGED = EVT.THEME_CHANGED || "theme:changed";

  // 버스 폴백
  var Bus = APP.bus || {
    on:   function (t, cb) { return webMI.trigger.connect(t, function (e){ cb && cb(e && e.value, e); }); },
    emit: function (t, v)  { webMI.trigger.fire(t, v); }
  };

  // ───────────────────────────────────────────────────────────────
  // 팔레트: 네가 준 리스트만 사용 (Day/Night 둘 다, 비어있으면 상대 모드/기본값으로 폴백)
  // ───────────────────────────────────────────────────────────────
  var PALETTE = {
    BtnLamp_Off: {"Day":"#c3c3c3","Night":"#3b3b3b"},
    BtnLamp_On: {"Day":"#3290ed","Night":"#0675fa"},
    Btn_Background: {"Day":"#d2d2d2","Night":"#2d2d2d"},
    Btn_Background_Down: {"Day":"#919191","Night":"#9e9e9e"},
    Main_Background: {"Day":"#e0e0e0","Night":"#0a0a0a"},
    DataCell_Background: {"Day":"#ff0000","Night":"#383838"},
    Font_Default: {"Day":"#464646","Night":"#c8c8c8"},
    Font_Selected_Data: {"Day":"#3290ed","Night":"#0675fa"},
    Table_Border: {"Day":"#bbbbbb","Night":"#535353"},
    Table_Header_Background: {"Day":"#00ff00","Night":"#0a0a0a"},
    Table_Cell_Background_Control: {"Day":"#f5f5f5","Night":"#0a0a0a"},
    Table_Cell_Background_Monitoring: {"Day":"#d9d9d9","Night":"#373737"},
    Selected: {"Day":"#3290ed","Night":"#0675fa"},
    Btn_Title: {"Day":"#0000ff","Night":"#0a0a0a"},
    Btn_Title_Down: {"Day":"#f0f0f0","Night":"#3a3a3a"},
    Font_Table_Data: {"Day":"#000000","Night":"#ffffff"},
    Table_Title: {"Day":"#e6e6e6","Night":"#191919"},
    Font_Selected_Title: {"Day":"#000000","Night":"#ffffff"},
    Font_Disable: {"Day":"#afafaf","Night":"#424242"},
    Tab_Selected_Title_Background: {"Day":"#f0f0f0","Night":"#3a3a3a"},
    Scroll_Backgroud: {"Day":"", "Night":"#0a0a0a"},
    Scroll_Bar: {"Day":"", "Night":"#535353"},
    Table_Cell_Background_Red: {"Day":"#560001","Night":"#560001"},
    Bento: {"Day":"#e6e6e6","Night":"#191919"},
    Top_Bento: {"Day":"#d2d2d2","Night":"#2d2d2d"},
    TextBox_Stroke: {"Day":"#bbbbbb","Night":"#535353"},
    Under_Line: {"Day":"#b1b1b1","Night":"#4e4e4e"},
    Selected_Magnetic_Table_Stroke: {"Day":"#3290ed","Night":"#0a6fdb"},
    Selected_Magnetic_Table_Title_Fill: {"Day":"#f5f5f5","Night":"#0a0a0a"},
    Selected_Magnetic_Table_Data_Fill: {"Day":"#d9d9d9","Night":"#373737"},
    Magnetic_Table_Normal_Line: {"Day":"#bbbbbb","Night":"#535353"},
    Normal_Magnetic_Table_Title_Fill: {"Day":"#00ff00","Night":"#161616"},
    Normal_Magnetic_Table_Data_Fill: {"Day":"#00ff00","Night":"#373737"},
    Normal_Magnetic_Table_Stroke: {"Day":"#00ff00","Night":"#b4b4b4"},
    Font_Title: {"Day":"#5f5f5f","Night":"#b4b4b4"},
    Font_Combobox_Select: {"Day":"", "Night":"#ffffff"},
    Font_Combobox_Default: {"Day":"", "Night":"#acacac"},
    Line_Com_Normal: {"Day":"#008480","Night":"#00847d"},
    Line_Com_Fault: {"Day":"#ed0000","Night":"#ed0000"},
    Popup_Stroke: {"Day":"#505050","Night":"#7f7f7f"},
    Popup_Font_Title: {"Day":"#f0f0f0","Night":"#0a0a0a"},
    Popup_Rect: {"Day":"#505050","Night":"#b7b7b7"},
    Line_Com_Normal_Popup: {"Day":"#505050","Night":"#acacac"},
    Btn_Background_DataFreq_Apply: {"Day":"#91cdff","Night":"#013c7c"},
    Btn_Background_DataFreq_Selected: {"Day":"#aaaaaa","Night":"#777777"},
    Green_Active: {"Day":"#008e0d","Night":"#008e0d"},
    White: {"Day":"#ffffff","Night":"#ffffff"},
    Purple: {"Day":"#ff00ff","Night":"#ff00ff"},
    Red: {"Day":"#ed0000","Night":"#ed0000"},
    Popup_Border: {"Day":"#505050","Night":"#7f7f7f"},
    Yellow: {"Day":"#ffff00","Night":"#ffff00"},
    Alarm: {"Day":"#ed0000","Night":"#ed0000"},
    MSG_Table_Border: {"Day":"#535353","Night":"#535353"},
    Icon_Default: {"Day":"#414141","Night":"#dcdcdc"},
    Black: {"Day":"#000000","Night":"#000000"}
  };

  // ───────────────────────────────────────────────────────────────
  // ColorManager
  // ───────────────────────────────────────────────────────────────
  function ColorManager() {
    this.modeKey = "Color_Mode";
    this.mode    = localStorage.getItem(this.modeKey) || "Day";
    this.palette = PALETTE;     // 주어진 키만 사용
    this._bound  = [];          // 자동 재적용용 매핑들
    this._wired  = false;
  }

  ColorManager.prototype.init = function (opts) {
    if (opts && opts.defaultMode) this.mode = opts.defaultMode;
    // 테마 변경 이벤트 수신(전역 버스가 있으면)
    if (!this._wired) {
      Bus.on(THEME_CHANGED, (m)=> { this._applyMode(m, {persist:true, broadcast:false}); });
      this._wired = true;
    }
    this._applyAll();
  };

  // 외부에서 호출: 모드를 바꾸고 싶으면 전역 액션을 쓰는 것을 권장
  ColorManager.prototype.setMode = function (mode, opt) {
    // APP.actions.setTheme이 있으면 그것을 사용(이벤트/상태 일원화)
    if (APP.actions && typeof APP.actions.setTheme === "function") {
      APP.actions.setTheme(mode);
    } else {
      this._applyMode(mode, opt);
      Bus.emit(THEME_CHANGED, mode);
    }
  };

  ColorManager.prototype._applyMode = function (mode, {persist=true}={}) {
    this.mode = mode || this.mode;
    if (persist) localStorage.setItem(this.modeKey, this.mode);
    this._applyAll();
  };

  // 안전한 get: 비어 있으면 상대 모드 → 마지막으로 null
  ColorManager.prototype.get = function (key, mode) {
    mode = mode || this.mode;
    var item = this.palette[key];
    if (!item) return null;
    var val = item[mode];
    if (val === "" || val == null) {
      var other = (mode === "Day" ? "Night" : "Day");
      val = item[other] || null;
    }
    return val;
  };

  // 매핑: { elementId: "PaletteKey" } 또는 { elementId: { fill:"Key", stroke:"Key2", text:"Key3", opacity:0.6 } }
  ColorManager.prototype.applyMap = function (map, mode) {
    var self = this;
    Object.keys(map || {}).forEach(function (id) {
      var spec = map[id];
      if (typeof spec === "string") {
        var col = self.get(spec, mode);
        if (col) try { webMI.gfx.setFill(id, col); } catch(_) {}
        return;
      }
      if (!spec || typeof spec !== "object") return;
      if (spec.fill)  { var c = self.get(spec.fill, mode);  if (c) try { webMI.gfx.setFill(id, c); } catch(_) {} }
      if (spec.text)  { var t = self.get(spec.text, mode);  if (t) try { webMI.gfx.setFill(id, t); } catch(_) {} }
      if (spec.stroke && webMI.gfx.setStroke) {
        var s = self.get(spec.stroke, mode); if (s) try { webMI.gfx.setStroke(id, s); } catch(_) {}
      }
      if (spec.opacity != null) {
        var v = Number(spec.opacity); if (!isNaN(v)) try { webMI.gfx.setFillOpacity(id, v); } catch(_) {}
      }
    });
  };

  ColorManager.prototype.bind = function (map) {
    this._bound.push(map);
    this.applyMap(map);
    var self = this;
    return function unbind() {
      self._bound = self._bound.filter(function (m) { return m !== map; });
    };
  };

  ColorManager.prototype._applyAll = function () {
    var mode = this.mode, self = this;
    this._bound.forEach(function (m) { self.applyMap(m, mode); });
  };

  // 전역 노출
  APP.Color = APP.Color || new ColorManager();

  // 선택: 자동 초기화(글로벌 준비 후 따로 init 호출해도 됨)
  // webMI.addOnload(function(){ APP.Color.init({ defaultMode: (APP.state && APP.state.theme) || "Day" }); });
})(webMI.rootWindow || window);
