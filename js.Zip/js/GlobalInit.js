// GlobalInit.js  (Menu Scripts 에 등록)
// 전역 런타임을 루트 창에 1회만 로드하고, 모든 디스플레이에서 공유합니다.
webMI.addOnload(function () {
  var root = webMI.rootWindow || window;

  // 이미 부팅돼 있으면 재실행 방지
  if (root.APP && root.APP.__booted) return;

  // 전역 네임스페이스
  var APP = root.APP = (root.APP || {});
  APP.__booted = true;     // 부팅됨(중복 로드 가드)
  APP.__ready  = false;    // 모듈 로드 완료 여부
  APP.version  = "2025-09-02";

  // ------------------------------------------------------------------
  // 색상 관리
  // ------------------------------------------------------------------
  // APP.color = webMI.query["color"];
  // APP.colorList = webMI.query["color_list"];

  // ------------------------------------------------------------------
  // 1) 이벤트 버스 (전역 트리거 래핑) + 이벤트 이름 상수
  // ------------------------------------------------------------------
  APP.EVT = {
    APP_READY:     "APP:ready",
    THEME_CHANGED: "theme:changed",
    DEMO_ON:       "demo:on"
  };

  APP.bus = APP.bus || {
    on:  function (topic, cb) { return webMI.trigger.connect(topic, function (e) { cb && cb(e && e.value, e); }); },
    emit:function (topic, payload) { webMI.trigger.fire(topic, payload); },
    off: function (id) { if (webMI.trigger.disconnect) try { webMI.trigger.disconnect(id); } catch (_) {} },
    ns:  function (ns) { var b=this; return { on:function(ev,cb){return b.on(ns+":"+ev,cb);}, emit:function(ev,p){b.emit(ns+":"+ev,p);} }; }
  };

  // ------------------------------------------------------------------
  // 2) 전역 상태 & 액션(도메인 로직만 — DOM은 만지지 않음)
  // ------------------------------------------------------------------
  APP.state = APP.state || {
    demoOn: false,
    theme : localStorage.getItem("Color_Mode") || "Day"
  };

  APP.actions = APP.actions || {
    toggleDemo: function () {
      APP.state.demoOn = !APP.state.demoOn;
      APP.bus.emit(APP.EVT.DEMO_ON, APP.state.demoOn);
    },
    setTheme: function (mode) {
      APP.state.theme = mode;
      localStorage.setItem("Color_Mode", mode);
      APP.bus.emit(APP.EVT.THEME_CHANGED, mode);
    }
  };

  // ------------------------------------------------------------------
  // 3) 가벼운 OPC UA I/O 래퍼 (Promise/해제 함수)
  // ------------------------------------------------------------------
  APP.io = APP.io || {
    read: function (addr) {
      return new Promise(function (res, rej) {
        webMI.data.read(addr, function (r) { (r && r.error) ? rej(r.error) : res(r && r.value); });
      });
    },
    write: function (addr, val) {
      return new Promise(function (res, rej) {
        webMI.data.write(addr, val, function (r) { (r && r.error) ? rej(r.error) : res(); });
      });
    },
    sub: function (addr, cb) {
      var id = webMI.data.subscribe(addr, function (r) { cb && cb(r && r.value, r); });
      // 호출자가 해제할 수 있게 함수 반환
      return function () { try { webMI.data.unsubscribe(id); } catch (_) {} };
    }
  };

  // ------------------------------------------------------------------
  // 4) 외부 모듈 로더(순차) + 캐시 버스터 + 중복 방지
  // ------------------------------------------------------------------
  APP.config = APP.config || {};
  APP.config.cacheBust = APP.config.cacheBust || ("v=" + APP.version);

  APP.loadModules = function (urls, done) {
    urls = (urls || []).filter(Boolean);
    if (!urls.length) { done && done(); return; }
    var i = 0;
    (function next () {
      if (i >= urls.length) { done && done(); return; }
      var url = urls[i++];
      // 이미 로드된 모듈은 생략
      if (root.document.querySelector('script[data-app-mod="' + url + '"]')) return next();
      var s = root.document.createElement("script");
      s.type = "text/javascript";
      s.src  = url + (url.indexOf("?") > -1 ? "&" : "?") + APP.config.cacheBust;
      s.setAttribute("data-app-mod", url);
      s.onload  = next;
      s.onerror = function (e) { console.error("[GlobalInit] Failed to load", url, e); next(); };
      root.document.head.appendChild(s);
    })();
  };

  // ------------------------------------------------------------------
  // 5) 준비 대기 헬퍼 — 화면(GLUE)에서 안전하게 사용
  // ------------------------------------------------------------------
  APP.whenReady = function (fn) {
    if (APP.__ready) { try { fn(APP); } catch (e) { console.error(e); } }
    else APP.bus.on(APP.EVT.APP_READY, function () { try { fn(APP); } catch (e) { console.error(e); } });
  };

  // ------------------------------------------------------------------
  // 6) 부팅: 공용 모듈 로드 → 준비 완료 브로드캐스트
  // ------------------------------------------------------------------
  var baseModules = [
    "/js/AppColor.js",
    // "/js/defaultPage.js",
  ];


  APP.loadModules(baseModules, function () {
    // 전역 상태의 theme을 기본 모드로 반영
    if (APP.Color && typeof APP.Color.init === "function") {
      APP.Color.init({ defaultMode: APP.state.theme });
    }
    APP.__ready = true;
    APP.bus.emit(APP.EVT.APP_READY || "APP:ready", true);
  });
});
