// default-page.js — Default(Object Display) 전용 OOP 리팩터링
// - 원본 Default.js 기능을 클래스들로 분리/정돈
// - 전역(GlobalInit)의 APP.bus / APP.state가 있으면 활용, 없으면 직접 webMI.trigger 사용
(function (global) {
  "use strict";
  var root = global || window;
  var APP  = root.APP = (root.APP || {});     // 전역 네임스페이스(있으면 재사용)
  var Bus  = APP.bus || {
    on:  (t, cb) => webMI.trigger.connect(t, e => cb && cb(e && e.value, e)),
    emit:(t, v)  => webMI.trigger.fire(t, v)
  };

  // ---------- 상수/설정 ----------
  const CFG = {
    logoutSeconds: 60 * 10,
    alarmCycleMs: 800,
    colorModeKey: "Color_Mode",
    sideButtons: ["btn_Outline","btn_DGS","btn_CPS","btn_MAG","btn_Probe","btn_Function","btn_System","btn_Test","btn_IGRF","btn_Chart","btn_MSG"],
    displays: {
      Outline: "AGENT.DISPLAYS.MAIN_DISPLAY",
      DGS:     "AGENT.DISPLAYS.00.Main.Degaussing",
      CPS:     "AGENT.DISPLAYS.00.Main.Data_PSU",
      MAG:     "AGENT.DISPLAYS.00.Main.Data_MagneticField",
      Probe:   "AGENT.DISPLAYS.00.Main.Data_Probe",
      Function:"AGENT.DISPLAYS.00.Main.Setting_Function",
      System:  "AGENT.DISPLAYS.00.Main.Setting_System",
      Test:    "AGENT.DISPLAYS.00.Main.Setting_Test",
      IGRF:    "AGENT.DISPLAYS.00.Main.Setting_IGRF",
      Chart:   (mode) => "AGENT.DISPLAYS.00.Main.Chart_" + mode,
      MSG:     "AGENT.DISPLAYS.00.Main.Message_LiveHistory",
      SSG:     "AGENT.DISPLAYS.SSG_DISPLAYS.testDisplay",
    }
  };

  // ---------- 유틸 ----------
  const U = {
    lsGet(k, d=null){ const v = localStorage.getItem(k); return v==null?d:v; },
    lsSet(k, v){ localStorage.setItem(k, v); },
    num(n, d=0){ n = Number(n); return isNaN(n)?d:n; },
    trySetText(id, v){ try{ webMI.gfx.setText(id, v); }catch(_){} },
    trySetFill(id, v){ try{ webMI.gfx.setFill(id, v); }catch(_){} },
    addEvt(id, ev, fn){ try{ webMI.addEvent(id, ev, fn); }catch(_){} },
    q(id){ return document.getElementById(id); }
  };

  // ---------- Theme / 색상 ----------
  class Theme {
    constructor(){ 
      // this.color      = webMI.query["color"];
      //나중에 전역 색상 관리 로직 만들어서 연결해줄 예정
      this.color = {};
      this.colorList = [];
      this.colorMode  = U.lsGet(CFG.colorModeKey) || "Night";
      this._sideColorSet = this._sideColorSet.bind(this);
    }
    init() {
      const root  = webMI.rootWindow || window;
      const APP   = root.APP || {};
      const Color = APP.Color;

      // AppColor가 아직 준비 전이면 GlobalInit의 whenReady를 기다렸다가 다시 시도
      if (!Color) {
        if (typeof APP.whenReady === "function") {
          return APP.whenReady(() => this.init());
        }
        // 폴백: 잠시 후 재시도
        return setTimeout(() => this.init(), 100);
      }

      // 여기서 전역 팔레트/키를 연결
      this.color     = Color.palette;           // ex) this.color.Main_Background.Night
      this.colorList = (Color.keys && Color.keys()) || Object.keys(Color.palette || {});
      this.colorMode = (APP.state && APP.state.theme) || this.colorMode;

      this.applyDayNight(this.colorMode);
      Bus.on("Color_Mode_Change", (mode)=>{
        this.colorMode = mode; this.applyDayNight(mode); this._sideColorSet();
      });
    }
    
    applyDayNight(mode){
      webMI.gfx.setFill("back_display", this.color.Main_Background[mode]);
      webMI.gfx.setFill("side", this.color.Top_Bento[mode]);
    }
    sideColorSet(nowTap){
      this._nowTap = nowTap || U.lsGet("Now_Tap");
      this._sideColorSet();
      U.lsSet("Chart_Display", false);
    }
    _sideColorSet(){
      const mode  = this.colorMode;
      const color = this.color;
      const now   = this._nowTap || U.lsGet("Now_Tap");
      CFG.sideButtons.forEach(btn=>{
        const tap = btn.replace("btn_","");
        const bg  = `${btn}_background`;
        const lb  = `${btn}_label`;
        if (tap !== now){
          U.trySetFill(bg, "none");
          U.trySetFill(lb, color.Font_Table_Data[mode]);
        } else {
          U.trySetFill(bg, color.Selected[mode]);
          U.trySetFill(lb, color.White[mode]);
        }
      });
    }
  }

  // ---------- 로그인/권한/자동 로그아웃 ----------
  class Auth {
    constructor(){
      this.logoutSeconds = CFG.logoutSeconds;
      this._tick = this._tick.bind(this);
      // 데모 계정(원본 유지)
      this.users = [
        {id:"Level2",   pw:"Level2",   level:"Level2"},
        {id:"Level3",   pw:"Level3",   level:"Level3"},
        {id:"Engineer", pw:"kte93924", level:"Level4"},
      ];
    }
    init(){
      // Login_Check 트리거 핸들
      webMI.trigger.connect("Login_Check",(e)=>{
        const { id, pw, callback } = e.value || {};
        let ok=false, level="Level1";
        for (const u of this.users){
          if (u.id.toLowerCase() === String(id||"").toLowerCase()){
            if (u.pw === pw){ ok=true; level=u.level; }
            break;
          }
        }
        if (typeof callback==="function") callback(ok, level);
      });
      // 자동 로그아웃 타이머 시작
      setTimeout(this._tick, 1000);
    }
    _tick(){
      let count = U.num(U.lsGet("NoTouchCount"), 0);
      if (count >= this.logoutSeconds){
        if (U.lsGet("UserName") !== "-"){
          const prev = U.lsGet("UserLevel");
          const level = "Level1";
          U.lsSet("UserName","-");
          U.lsSet("UserLevel", level);
          webMI.trigger.fire("Login_Change", level);
          webMI.data.write("AGENT.OBJECTS.Control._level", 1);
          webMI.trigger.fire("Event_Add", "Auto Logout : " + prev);
        }
      } else {
        U.lsSet("NoTouchCount", count + 1);
      }
      setTimeout(this._tick, 1000);
    }
  }

  // ---------- 이벤트 기록/ACK ----------
  class EventsAndAck {
    init(){
      // 메시지에 Event History 기록
      const addEvent = webMI.callExtension("SYSTEM.LIBRARY.PROJECT.QUICKDYNAMICS.AddEvent");
      webMI.trigger.connect("Event_Add",(e)=> addEvent(e && e.value));

      // All Ack
      webMI.rootWindow.webMI.callExtension("SYSTEM.LIBRARY.ATVISE.QUICKDYNAMICS.Alarmmanagement",{"id":""});
      webMI.trigger.connect("All_Ack", ()=>{
        webMI.data.call("Alarm_Live_List",{}, (list)=>{
          (list||[]).forEach(a => webMI.alarm.accept(a.address));
        });
      });
    }
  }

  // ---------- 팝업/차단막 ----------
  class Overlay {
    init(){
      Bus.on("Prevention_Open",(val)=>{
        const shadow = U.q("shadow");
        if (!shadow) return;
        shadow.setAttribute("x","0"); shadow.setAttribute("y","0");
        webMI.gfx.setVisible("btn_expansion_click", val==="함 정보");
      });
      Bus.on("Prevention_Close",()=>{
        const shadow = U.q("shadow");
        if (!shadow) return;
        shadow.setAttribute("x","3000"); shadow.setAttribute("y","0");
        webMI.gfx.setVisible("btn_expansion_click", true);
      });

      // 권한 확인 → callback(access)
      Bus.on("Prevention_Check", ({level, callback})=>{
        const now = Number((U.lsGet("UserLevel")||"").slice(-1));
        let access = !isNaN(now) && now >= Number(level);
        // 원본은 access=true 강제 — 유지
        access = true;
        if (typeof callback==="function") callback(access);
      });

      // 상단 확장 버튼
      let expansion = false;
      U.addEvt("btn_expansion_click","click",()=>{
        const ctl = U.q("btn_expansion");
        if (!ctl) return;
        if (!expansion){
          ctl.href.baseVal='../../Icon/reduction1.png';
          webMI.gfx.setVisible("Top_Popup", true);
          Bus.emit("Prevention_req", {req:"open", parameter:"함 정보"});
          expansion = true;
        } else {
          expansion = false;
          ctl.href.baseVal='../../Icon/Extension1.png';
          webMI.gfx.setVisible("Top_Popup", false);
          Bus.emit("Prevention_req", {req:"close"});
        }
      });
    }
  }

  // ---------- 알람 카운트 ----------
  class AlarmCounter {
    constructor(theme){
      this.theme = theme;
      this.cycle = CFG.alarmCycleMs;
      this._blink = false;
      this._loop = this._loop.bind(this);
    }
    init(){ setTimeout(this._loop, this.cycle); }
    _loop(){
      webMI.data.call("Alarm_Live_List",{}, (list)=>{
        let nonAck=0, warn=0, alm=0, fault=0;
        (list||[]).forEach(a=>{
          if (a.Groups && a.Groups.length>0){
            const g = String(a.Groups[0]||"").split('.').pop().trim();
            if (g==="Warning") warn++;
            else if (g==="Alarm") alm++;
            else if (g==="Fault") fault++;
            if (a.state===1) nonAck++;
          }
        });
        const total = warn+alm+fault;
        U.lsSet("warning_num", warn);
        U.lsSet("fault_num", fault);
        U.lsSet("total_alarm_num", total);
        U.lsSet("non_ack_num", nonAck);

        // 버튼 배경/라벨 색
        const mode = this.theme.colorMode;
        const color= this.theme.color;
        const nowIsMsg = (U.lsGet("Now_Tap")==="MSG");
        const noAlarmBg = nowIsMsg ? color.Selected[mode] : "none";

        if (total>0){
          this._blink = !this._blink;
          const apply = this._blink ? color.Red[mode] : noAlarmBg;
          if (nonAck>0) U.trySetFill("btn_MSG_background", apply);
          else if (webMI.gfx.getFill("btn_MSG_background")!==color.Red[mode]) {
            U.trySetFill("btn_MSG_background", color.Red[mode]);
          }
        } else {
          this._blink=false;
          if (webMI.gfx.getFill("btn_MSG_background")===color.Red[mode]){
            U.trySetFill("btn_MSG_background", noAlarmBg);
          }
        }
        const noneBg = (webMI.gfx.getFill("btn_MSG_background")==="none");
        U.trySetFill("btn_MSG_label", noneBg ? color.Font_Table_Data[mode] : color.White[mode]);

        Bus.emit("Alarm_Label_Update");
      });
      setTimeout(this._loop, this.cycle);
    }
  }

  // ---------- 사이드 트리 열기/닫기 ----------
  class SideTree {
    constructor(theme){
      this.theme = theme;
      this.spacing = 71.296;
      this.dataOpen = false;
      this.settingOpen = false;
      
    }
    init(){
      // 캐싱
      this.btn_Data    = U.q("btn_Data");
      this.btn_Setting = U.q("btn_Setting");
      this.btn_CPS     = U.q("btn_CPS");
      this.btn_MAG     = U.q("btn_MAG");
      this.btn_Probe   = U.q("btn_Probe");
      this.btn_Function= U.q("btn_Function");
      this.btn_System  = U.q("btn_System");
      this.btn_Test    = U.q("btn_Test");
      this.btn_IGRF    = U.q("btn_IGRF");
      this.btn_Chart   = U.q("btn_Chart");
      this.btn_MSG     = U.q("btn_MSG");

      this.dataOpen    = (U.lsGet("data_open")==="true");
      this.settingOpen = (U.lsGet("setting_open")==="true");

      U.addEvt("btn_Data","click",()=>{
        const t = webMI.gfx.getText("btn_Data_text_arrow");
        this.toggleData(t===">");
      });

      U.addEvt("btn_Setting","click",()=>{
        const t = webMI.gfx.getText("btn_Setting_text_arrow");
        this.toggleSetting(t===">");
      });

      // 초기 복구(언어 변경 재로드 케이스)
      if (this.dataOpen) this.toggleData(true, true);
      if (this.settingOpen) this.toggleSetting(true, true);
    }
    toggleData(open, silent){
      const yData = parseFloat(this.btn_Data.getAttribute('y'));
      if (open){ // open
        webMI.gfx.setText("btn_Data_text_arrow","∨");
        this.dataOpen = true; U.lsSet("data_open", true);
        this.btn_CPS.setAttribute('y', yData + this.spacing);
        this.btn_MAG.setAttribute('y', yData + this.spacing*2);
        this.btn_Probe.setAttribute('y', yData + this.spacing*3);
        const yProbe = parseFloat(this.btn_Probe.getAttribute('y'));
        this.btn_Setting.setAttribute('y', yProbe + this.spacing);

        if (this.settingOpen){
          const ySet = parseFloat(this.btn_Setting.getAttribute('y'));
          this.btn_Function.setAttribute('y', ySet + this.spacing);
          this.btn_System.setAttribute('y',   ySet + this.spacing*2);
          this.btn_Test.setAttribute('y',     ySet + this.spacing*3);
          this.btn_IGRF.setAttribute('y',     ySet + this.spacing*4);
          const yIGRF = parseFloat(this.btn_IGRF.getAttribute('y'));
          this.btn_Chart.setAttribute('y', yIGRF + this.spacing);
          this.btn_MSG.setAttribute('y',   yIGRF + this.spacing*2);
        } else {
          const ySet = parseFloat(this.btn_Setting.getAttribute('y'));
          this.btn_Chart.setAttribute('y', ySet + this.spacing);
          this.btn_MSG.setAttribute('y',   ySet + this.spacing*2);
        }
        if (!silent){
          webMI.gfx.setVisible("btn_CPS", true);
          webMI.gfx.setVisible("btn_MAG", true);
          webMI.gfx.setVisible("btn_Probe", true);
        }
      } else { // close
        webMI.gfx.setText("btn_Data_text_arrow",">");
        if (!silent) webMI.gfx.setVisible("Data", false);
        this.dataOpen=false; U.lsSet("data_open", false);
        const ySet = parseFloat(this.btn_Setting.getAttribute('y'));
        this.btn_Setting.setAttribute('y', yData + this.spacing);

        if (this.settingOpen){
          const ySet2 = parseFloat(this.btn_Setting.getAttribute('y'));
          this.btn_Function.setAttribute('y', ySet2 + this.spacing);
          this.btn_System.setAttribute('y',   ySet2 + this.spacing*2);
          this.btn_Test.setAttribute('y',     ySet2 + this.spacing*3);
          this.btn_IGRF.setAttribute('y',     ySet2 + this.spacing*4);
          const yIGRF = parseFloat(this.btn_IGRF.getAttribute('y'));
          this.btn_Chart.setAttribute('y', yIGRF + this.spacing);
          this.btn_MSG.setAttribute('y',   yIGRF + this.spacing*2);
        } else {
          const ySet2 = parseFloat(this.btn_Setting.getAttribute('y'));
          this.btn_Chart.setAttribute('y', ySet2 + this.spacing);
          this.btn_MSG.setAttribute('y',   ySet2 + this.spacing*2);
        }
        if (!silent){
          webMI.gfx.setVisible("btn_CPS", false);
          webMI.gfx.setVisible("btn_MAG", false);
          webMI.gfx.setVisible("btn_Probe", false);
        }
      }
    }
    toggleSetting(open, silent){
      if (open){
        webMI.gfx.setText("btn_Setting_text_arrow","∨");
        this.settingOpen=true; U.lsSet("setting_open", true);

        if (this.dataOpen){
          const ySet = parseFloat(this.btn_Setting.getAttribute('y'));
          this.btn_Function.setAttribute('y', ySet + this.spacing);
          this.btn_System.setAttribute('y',   ySet + this.spacing*2);
          this.btn_Test.setAttribute('y',     ySet + this.spacing*3);
          this.btn_IGRF.setAttribute('y',     ySet + this.spacing*4);
          const yIGRF = parseFloat(this.btn_IGRF.getAttribute('y'));
          this.btn_Chart.setAttribute('y', yIGRF + this.spacing);
          this.btn_MSG.setAttribute('y',   yIGRF + this.spacing*2);
        } else {
          ["btn_CPS","btn_MAG","btn_Probe"].forEach(id=> webMI.gfx.setVisible(id,false));
          const ySet = parseFloat(this.btn_Setting.getAttribute('y'));
          this.btn_Function.setAttribute('y', ySet + this.spacing);
          this.btn_System.setAttribute('y',   ySet + this.spacing*2);
          this.btn_Test.setAttribute('y',     ySet + this.spacing*3);
          this.btn_IGRF.setAttribute('y',     ySet + this.spacing*4);
          const yIGRF = parseFloat(this.btn_IGRF.getAttribute('y'));
          this.btn_Chart.setAttribute('y', yIGRF + this.spacing);
          this.btn_MSG.setAttribute('y',   yIGRF + this.spacing*2);
        }
        if (!silent){
          ["btn_Function","btn_System","btn_Test","btn_IGRF"].forEach(id=> webMI.gfx.setVisible(id,true));
        }
      } else {
        webMI.gfx.setText("btn_Setting_text_arrow",">");
        this.settingOpen=false; U.lsSet("setting_open", false);
        const ySet = parseFloat(this.btn_Setting.getAttribute('y'));
        this.btn_Chart.setAttribute('y', ySet + this.spacing);
        this.btn_MSG.setAttribute('y',   ySet + this.spacing*2);
        if (!silent){
          ["btn_Function","btn_System","btn_Test","btn_IGRF"].forEach(id=> webMI.gfx.setVisible(id,false));
        }
      }
    }
  }

  // ---------- 네비게이션 ----------
  class Navigation {
    constructor(theme){
      this.theme = theme;
      this.current = "MAIN_Display";
    }
    init(){
      // 사이드 탭 버튼
      this._bindTap("btn_Outline","Outline", CFG.displays.Outline);
      this._bindTap("btn_DGS","DGS", CFG.displays.DGS);
      this._bindTap("btn_CPS","CPS", CFG.displays.CPS);
      this._bindTap("btn_MAG","MAG", CFG.displays.MAG);
      this._bindTap("btn_Probe","Probe", CFG.displays.Probe);
      this._bindTap("btn_Function","Function", CFG.displays.Function);
      this._bindTap("btn_System","System", CFG.displays.System);
      this._bindTap("btn_Test","Test", CFG.displays.Test);
      this._bindTap("btn_IGRF","IGRF", CFG.displays.IGRF);
      // Chart는 모드 의존
      U.addEvt("btn_Chart","click", ()=>{
        this._goto("Chart", CFG.displays.Chart(this.theme.colorMode));
      });
      this._bindTap("btn_MSG","MSG", CFG.displays.MSG);

      // 기타
      U.addEvt("GoTo_SSG_DISPLAY","click", ()=> {
        webMI.display.openDisplay(CFG.displays.SSG);
        this.theme.sideColorSet(U.lsGet("Now_Tap"));
      });
    }
    _bindTap(btnId, tapName, displayAddr){
      U.addEvt(btnId, "click", ()=> this._goto(tapName, displayAddr));
    }
    _goto(tapName, displayAddr){
      this.current = tapName;
      Bus.emit("Title_Change", tapName);
      U.lsSet("Now_Tap", tapName);
      webMI.display.openDisplay(displayAddr);
      this.theme.sideColorSet(tapName);
    }
  }

  // ---------- Default 페이지 오케스트레이션 ----------
  class DefaultPage {
    constructor(){
      this.theme = new Theme();
      this.auth  = new Auth();
      this.ack   = new EventsAndAck();
      this.ovl   = new Overlay();
      this.tree  = new SideTree(this.theme);
      this.nav   = new Navigation(this.theme);
      this._onLoad = this._onLoad.bind(this);
    }
    init(){
      // DOM이 필요한 것들은 SVG onload 이후에, 로드 후(원본 onload 로직 이식)
      webMI.addOnload(() => {
        this.theme.init();
        this.auth.init();
        this.ack.init();
        ////
        this.ovl.init();
        this.tree.init();   // 버튼 y 이동, 가시성 조정 등 DOM 접근
        this.nav.init();    // 버튼 클릭 바인딩
        this._onLoad();     // 원래 onload 처리
        this.alarm = new AlarmCounter(this.theme);
        this.alarm.init();
      });
      
      // 밝기/언어 관련 트리거
      Bus.on("Brightness_Value_Change", ()=>{
        const v = U.num(U.lsGet("Brightness"), 100);
        webMI.rootWindow.setBrightness(v);
      });
    }
    _onLoad(){
      // 초기 Color_Mode 기본값
      if (U.lsGet(CFG.colorModeKey) == null) U.lsSet(CFG.colorModeKey, "Night");

      // 터치 초기화: 다른 화면 body 클릭 시 카운터 0
      try {
        var iframeBody = webMI.rootWindow.document.querySelector("#mainframe").contentWindow.document.body;
        iframeBody.addEventListener("click", ()=> U.lsSet("NoTouchCount", 0));
      } catch(_){}

      // 로딩/언어 전환 복구
      if (U.lsGet("Language_Change")==="true"){
        setTimeout(()=>{
          webMI.rootWindow.loading_State((state)=>{
            U.lsSet("Now_Tap","System");
            this.theme.sideColorSet("System");
            Bus.emit("Title_Change","System");
            if (U.lsGet("data_open")==="true")   this.tree.toggleData(true, true);
            if (U.lsGet("setting_open")==="true")this.tree.toggleSetting(true, true);
            U.lsSet("Language_Change", false);
            webMI.rootWindow.stopLoading();
          });
        }, 500);
      } else {
        // 최초 실행(F5 포함)
        webMI.data.login("root","", ()=>{
          U.lsSet("Brightness", 100);
          Bus.emit("Brightness_Value_Change");
          setTimeout(()=> webMI.rootWindow.stopLoading(), 1000);
        });

        webMI.rootWindow.loading_State((s)=>{
          if (!s) webMI.rootWindow.startLoading(0,0,1920,1080);
        });

        setTimeout(()=>{
          U.lsSet("Now_Tap", "Outline");
          U.lsSet("UserName","-");
          U.lsSet("UserLevel","Level1");
          U.lsSet("NoTouchCount", 0);
          U.lsSet("Language_Mode","ko");
          U.lsSet("Language_Change", false);
          U.lsSet("data_open", false);
          U.lsSet("setting_open", false);
          // 초기 버튼 색(Outline 선택)
          const mode = this.theme.colorMode, color = this.theme.color;
          U.trySetFill('btn_Outline_background', color.Selected[mode]);
          U.trySetFill('btn_Outline_label',      color.White[mode]);
        }, 250);
      }
    }
  }

  // --------- 부팅 ----------
  webMI.addOnload(function(){
    // Default 디스플레이에서만 생성
    (root.__DefaultPageInstance || (root.__DefaultPageInstance = new DefaultPage())).init();
  });

})(webMI.rootWindow || window);
