var color = webMI.query["color"];

//////////초기화 인자들/////////
var sign_active = true;
var dot_num = 1;
var digit_num = 5;
var preValues = {};
var checkValues = {};

var top_popup_open = false;

/////////////////////////////////////////
var now_data_string = "";
var selected_cell = "";

var lbl_id = ["lbl_data_V", "lbl_data_A", "lbl_data_L"];
var data_addr = {V : "", A : "", L : ""};
var apply_bit_addr = "";
//////////////////////////////////////////////////////

///////////////////////////*  주/야간 색상 변경 *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	webMI.gfx.setFill("title_display1", color.Popup_Border[color_mode]);
	webMI.gfx.setFill("title_display2", color.Popup_Border[color_mode]);
	webMI.gfx.setStroke("title_display1",color.Popup_Border[color_mode]);
	webMI.gfx.setStroke("title_display2",color.Popup_Border[color_mode]);
	
	webMI.gfx.setStroke("back_display", color.Popup_Border[color_mode]);
	webMI.gfx.setFill("back_display", color.Main_Background[color_mode]);
	
	webMI.gfx.setFill("lbl_title", color.Main_Background[color_mode]);
	
	webMI.gfx.setFill("lbl_data_V", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl_data_A", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl_data_L", color.Font_Default[color_mode]);
	
	webMI.gfx.setFill("lbl_V_data_unit", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl_A_data_unit", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl_L_data_unit", color.Font_Default[color_mode]);
	
	webMI.gfx.setFill("text_V_data", color.Font_Default[color_mode]);
	webMI.gfx.setFill("text_A_data", color.Font_Default[color_mode]);
	webMI.gfx.setFill("text_L_data", color.Font_Default[color_mode]);	
	
	webMI.gfx.setStroke("line_1", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_2", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_3", color.Under_Line[color_mode]);	
	
	webMI.gfx.setFill("back_pad", color.Bento[color_mode]);
}

//////////////////팝업창 오픈전 초기 데이터 수집////////////////////////
webMI.trigger.connect("MF_Data_Popup_Init", function(e)
{
	selected_cell = e.value.axis;
	preValues["V"] = e.value.data.V;
	preValues["A"] = e.value.data.A;
	preValues["L"] = e.value.data.L;
	
	webMI.data.write(data_addr["V"] + "_Temp",preValues["V"]);
	webMI.data.write(data_addr["A"] + "_Temp",preValues["A"]);
	webMI.data.write(data_addr["L"] + "_Temp",preValues["L"]);
	
	webMI.gfx.setText("lbl_data_V", preValues["V"]);
	webMI.gfx.setText("lbl_data_A", preValues["A"] );
	webMI.gfx.setText("lbl_data_L", preValues["L"]);
		
	checkValues = {};
	
	Cell_Select_Text(selected_cell);
	Shadow_visible(selected_cell);
	Apply_Btn_Active();
});

/////////////////셀 선택 시 글자변경////////////////////////////
function Cell_Select_Text(axis)
{
	lbl_id.forEach(lblName => 
	{
		var index = lblName.slice(-1);
		
		if (axis == "")
		{
			if (checkValues[index] != undefined)
			{
				webMI.gfx.setText(lblName, checkValues[index]);
				webMI.gfx.setFill(lblName, color.Green_Active[color_mode]);
			}
			else
			{
				webMI.gfx.setText(lblName, preValues[index]);
				webMI.gfx.setFill(lblName, color.Font_Default[color_mode]);
			}
			
			now_data_string =  "";
		}
		else
		{
			if(axis == index)
			{
				var temp_text = Digit_Count_to_Temp(digit_num,dot_num);
				webMI.gfx.setText(lblName, temp_text);
				webMI.gfx.setFill(lblName, color.Font_Selected_Data[color_mode]);
				
				now_data_string =  temp_text;
			}
			else
			{
				if (checkValues[index] != undefined)
				{
					webMI.gfx.setText(lblName, checkValues[index]);
					webMI.gfx.setFill(lblName, color.Green_Active[color_mode]);
				}
				else
				{
					webMI.gfx.setText(lblName, preValues[index]);
					webMI.gfx.setFill(lblName, color.Font_Default[color_mode]);
				}
			}
		}
	});
}

///////////////////////////*  닫기 버튼 클릭 이벤트  *///////////////////////////
webMI.addEvent("btn_close", "click", function(e)
{
	if (top_popup_open)
	{
		return;
	}

	webMI.trigger.fire("MF_Data_Popup_Close");
});

//////////////////////// 적용 버튼 클릭////////////////////////
webMI.addEvent("btn_apply", "click", function(e) {

	if (Object.keys(checkValues).length == 0 || top_popup_open)
	{
		return;
	}

	webMI.trigger.fire("Prevention_Check", {level : 2, callback : function(access)	
	{
		if (access == false)
		{
			webMI.trigger.fire("Info_Popup_Open", { title : "T{권한}", info : "T{해당 기능에 대한 권한이 없습니다.}" });
		}
		else
		{
			webMI.trigger.fire("Apply_Popup_Open");
		}
		
		if (checkValues[selected_cell] != undefined)
		{
			now_data_string = String(checkValues[selected_cell]);
			
			webMI.gfx.setText("lbl_data_" + selected_cell, now_data_string);
			webMI.gfx.setFill("lbl_data_" + selected_cell, color.Green_Active[color_mode]);
		}
		else
		{
			now_data_string = String(preValues[selected_cell]);
			
			webMI.gfx.setText("lbl_data_" + selected_cell, now_data_string);
			webMI.gfx.setFill("lbl_data_" + selected_cell, color.Font_Default[color_mode]);
		}		
		
		selected_cell = "";
		now_data_string = "";				
					
		Shadow_visible(selected_cell);
		
		top_popup_open = true;
		Click_active();
	}});
});

//////////////////적용 확인//////////////////////	
webMI.trigger.connect("Apply", function(e)
{
	webMI.data.write(apply_bit_addr,1);
	webMI.trigger.fire("MF_Data_Popup_Done", checkValues);
	webMI.trigger.fire("MF_Data_Popup_Close");
	top_popup_open = false;
	Click_active();
});

///////////////////////////*  적용 확인 팝업 - 취소 버튼 클릭 이벤트  *///////////////////////////

webMI.trigger.connect("Apply_Popup_Cancel", function(e)
{
	top_popup_open = false;
	Click_active();
});

////////////// Info 팝업창 닫기///////////////////////////
webMI.trigger.connect("Info_Popup_Close", function(e)
{
	top_popup_open = false;
	Click_active();
});

///////////// 데이터 클릭 이벤트////////////////
Data_Click(["btn_data_V","btn_data_A","btn_data_L"]);
function Data_Click(buttonIds)
{
	buttonIds.forEach(buttonId =>
	{
		webMI.addEvent(buttonId, "click", function(e)
		{
			if (top_popup_open)
			{
				return;
			}			
		
			var now_cell = buttonId.slice(-1);
			
			selected_cell = (selected_cell == now_cell) ? "" : now_cell;
			
			Cell_Select_Text(selected_cell);
			
			Apply_Btn_Active();
			Shadow_visible(selected_cell);
		});
	});
}

/////////// 적용 버튼 활성화/ 비활성화////////
function Apply_Btn_Active()
{
	if (Object.keys(checkValues).length > 0)
	{
		webMI.trigger.fire("btn_active", "perm_apply");
	}
	else
	{
		webMI.trigger.fire("btn_inactive", "perm_apply");
	}
}

///////////////////////////*  글자수 리턴 함수  *///////////////////////////
function Digit_Count_to_Temp(digitNum, dotNum)
{
	let temp_text = "";
	
	for (let i = 0; i <digitNum; i++)
	{
		temp_text = temp_text + "_ ";
	}
	
	if (dotNum != 0)
	{
		temp_text = temp_text + ". ";
	}		
		
	for (let i = 0; i <dotNum; i++)
	{
		temp_text = temp_text + "_ ";
	}				
	
	return temp_text;
}

///////////////////////////*  숫자 버튼 클릭 이벤트 *///////////////////////////
function FooterNumber_Click(buttonIds)
{
	buttonIds.forEach(buttonId =>
	{
		webMI.addEvent(buttonId, "click", function(e)
		{
			if (selected_cell == "")
			{
				return;			
			}
			
			let number = Number(buttonId.slice(-1));
			let minus = false;
			
			if (now_data_string.includes("_"))
			{
				now_data_string = "";
			}	
			
			if (now_data_string.charAt(0) == "-")
			{
				now_data_string = now_data_string.replace("-","");
				minus= true;
			}				
			
			let dot_none = !now_data_string.includes(".");
			let str_len = now_data_string.length;
			
			if (dot_none)
			{
				if (str_len < digit_num)
				{
					now_data_string = now_data_string + String(number);
				}
			}
			else
			{
				let temp_txt = now_data_string.split(".");
				temp_txt = temp_txt[temp_txt.length - 1];
				
				if (temp_txt.length < dot_num)
				{
					now_data_string = now_data_string + String(number);
				}		
			}
			
			now_data_string = minus ? "-" + now_data_string : now_data_string;
			
			webMI.gfx.setText("lbl_data_" + selected_cell, now_data_string);
		});
	});
}

FooterNumber_Click(["btn_1","btn_2","btn_3","btn_4","btn_5","btn_6","btn_7","btn_8","btn_9","btn_0"]);

/////////////////////// + 버튼 클릭 ///////////////////////
webMI.addEvent("btn_plus", "click", function(e) {

	if (!sign_active || selected_cell == "")
	{
		return;
	}
	
	if (now_data_string.includes("_"))
	{
		return;
	}		
	
	if (now_data_string.charAt(0) == "-")
	{
		now_data_string = now_data_string.replace("-","");
	}
	
	webMI.gfx.setText("lbl_data_" + selected_cell, now_data_string);
});

/////////////////////// - 버튼 클릭 ///////////////////////
webMI.addEvent("btn_minus", "click", function(e) {

	if (!sign_active || selected_cell == "")
	{
		return;
	}
	
	if (now_data_string.includes("_"))
	{
		now_data_string = "-";
	}	
		
	if (now_data_string.charAt(0) != "-")
	{
		now_data_string = "-" + now_data_string;
	}
	
	webMI.gfx.setText("lbl_data_" + selected_cell, now_data_string);
});

///////////////////////// . 버튼 클릭 ///////////////////////
webMI.addEvent("btn_dot", "click", function(e) {

	if (selected_cell == "")
	{
		return;
	}

	if (now_data_string.includes("_"))
	{
		now_data_string = "0.";
	}
	
	if (!now_data_string.includes("."))
	{
		now_data_string = now_data_string + ".";
	}	

	webMI.gfx.setText("lbl_data_" + selected_cell, now_data_string);
});

////////////////////// 지우기 버튼 클릭 //////////////////////////
webMI.addEvent("btn_backspace", "click", function(e) {

	if (now_data_string.includes("_") || selected_cell == "")
	{
		return;
	}
	
	if (now_data_string.length > 0)
	{
		now_data_string = now_data_string.slice(0, -1);
	}

	if (now_data_string.length == 0)
	{
		now_data_string = Digit_Count_to_Temp(digit_num, dot_num);
	}
	
	webMI.gfx.setText("lbl_data_" + selected_cell, now_data_string);
});

//////////////////////// 초기화 버튼 클릭	///////////////////////////
webMI.addEvent("btn_reset", "click", function(e) {
	if (selected_cell == "")
	{
		return;
	}
		
	webMI.gfx.setText("lbl_data_" + selected_cell, preValues[selected_cell]);
	webMI.gfx.setFill("lbl_data_" + selected_cell, color.Font_Default[color_mode]);
	
	if (checkValues[selected_cell] != undefined)
	{
		delete checkValues[selected_cell];
	}	

	webMI.data.write(data_addr[selected_cell] + "_Temp", preValues[selected_cell]);
	
	selected_cell = "";
	now_data_string = "";				
				
	Shadow_visible(selected_cell);
	Apply_Btn_Active();
});

////////////////// Shadow_visible///////////////////
function Shadow_visible(select_cell)
{
	var visible = select_cell != ""  ? false :true;
	
	webMI.gfx.setVisible("shadow", visible);
}

/////////////////// 확인 버튼 클릭///////////////////////
webMI.addEvent("btn_check", "click", function(e) {
	if (now_data_string == "-" || now_data_string.includes("_"))
	{
		if (checkValues[selected_cell] != undefined)
		{
			now_data_string = String(checkValues[selected_cell]);
			
			webMI.gfx.setText("lbl_data_" + selected_cell, now_data_string);
			webMI.gfx.setFill("lbl_data_" + selected_cell, color.Green_Active[color_mode]);
		}
		else
		{
			now_data_string = String(preValues[selected_cell]);
			
			webMI.gfx.setText("lbl_data_" + selected_cell, now_data_string);
			webMI.gfx.setFill("lbl_data_" + selected_cell, color.Font_Default[color_mode]);
		}
		
		selected_cell = "";	
		now_data_string = "";
		Shadow_visible(selected_cell);
		Apply_Btn_Active();		
		
		return;
	}
	
	if (now_data_string.slice(-1) == ".")
	{
		now_data_string = now_data_string.slice(0, -1);
	}

	checkValues[selected_cell] = 	Number(now_data_string);
	webMI.gfx.setText("lbl_data_" + selected_cell, now_data_string);
	webMI.gfx.setFill("lbl_data_" + selected_cell, color.Green_Active[color_mode]);
	webMI.data.write(data_addr[selected_cell] + "_Temp", checkValues[selected_cell]);
	selected_cell = "";
	now_data_string = "";
	Shadow_visible(selected_cell);
	Apply_Btn_Active();
});

////////////////////모든 클릭 활성화 비활성화/////////////////////////////////
function Click_active()
{
	if (top_popup_open)
	{
		webMI.trigger.fire("btn_inactive", "perm_close");
		webMI.trigger.fire("btn_inactive", "perm_apply");
	}
	else
	{
		Apply_Btn_Active();		
		webMI.trigger.fire("btn_active", "perm_close");		
	}
}