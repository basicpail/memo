var color = webMI.query["color"];

/////////////////색상 변수/////////////////////
var color_Font_Title;
var color_Popup_Border;
var color_Main_Background;
var color_Font_Default;
var color_TextBox_Stroke;

var text_list = 
{ 
	1 : "T{추출}", 2 : "T{추출중 오류가 발생했습니다.}", 3 : "T{추출을 완료하였습니다.}",
	11 : "T{스크린샷}", 12 : "T{스크린샷을 저장하였습니다.}"
};

///////////////////////////*  주/야간 색상 변경 *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	if (color_mode == "Night")
	{
		color_Font_Title = color.Font_Title.Night;
		color_Popup_Border = color.Popup_Border.Night;
		color_Main_Background = color.Main_Background.Night;
		color_Font_Default = color.Font_Default.Night;
		color_TextBox_Stroke  = color.TextBox_Stroke.Night;
	}
	else if (color_mode == "Day")
	{
		color_Font_Title = color.Font_Title.Day;
		color_Popup_Border = color.Popup_Border.Day;
		color_Main_Background = color.Main_Background.Day;
		color_Font_Default = color.Font_Default.Day;
		color_TextBox_Stroke  = color.TextBox_Stroke.Day;
	}
	
	webMI.gfx.setFill("title_display1", color_Popup_Border);
	webMI.gfx.setFill("title_display2", color_Popup_Border);
	webMI.gfx.setStroke("title_display1", color_Popup_Border);
	webMI.gfx.setStroke("title_display2", color_Popup_Border);
	webMI.gfx.setStroke("back_display", color_Popup_Border);
	webMI.gfx.setFill("back_display", color_Main_Background);

	webMI.gfx.setFill("lbl_title", color_Main_Background);

	webMI.gfx.setFill("text", color_Font_Default);
}

/////////////버튼 클릭 이벤트///////////////////////
webMI.addEvent("btn_Check", "click", function(e) {
	webMI.trigger.fire("Info_Popup_Close");
});

webMI.trigger.connect("Info_Init", function(e)
{
	var title_text;
	
	if (!isNaN(Number(e.value.title)))
	{
		title_text = text_list[e.value.title];
	}
	else
	{
		title_text = e.value.title;
	}
	
	if (!isNaN(Number(e.value.info)))
	{
		info_text = text_list[e.value.info];
	}
	else
	{
		info_text = e.value.info;
	}
	
	webMI.gfx.setText("lbl_title",title_text);
	webMI.gfx.setText("text",info_text);
});