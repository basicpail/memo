var color = webMI.query["color"];
var prevention_level = 0;

/////////////////색상 변수/////////////////////
var color_Font_Title;
var color_Popup_Border;
var color_Main_Background;

///////////////////////////*  주/야간 색상 변경 *///////////////////////////

var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	if (color_mode == "Night")
	{
		color_Font_Title = color.Font_Title.Night;
		color_Popup_Border = color.Popup_Border.Night;
		color_Main_Background = color.Main_Background.Night;
	}
	else if (color_mode == "Day")
	{
		color_Font_Title = color.Font_Title.Day;
		color_Popup_Border = color.Popup_Border.Day;
		color_Main_Background = color.Main_Background.Day;
	}
	
	webMI.gfx.setFill("lbl_content_line1", color_Font_Title);
	webMI.gfx.setFill("lbl_content_line2", color_Font_Title);
	webMI.gfx.setFill("lbl_content", color_Font_Title);
	
	webMI.gfx.setFill("title_display1", color_Popup_Border);
	webMI.gfx.setFill("title_display2", color_Popup_Border);
	webMI.gfx.setStroke("title_display1", color_Popup_Border);
	webMI.gfx.setStroke("title_display2", color_Popup_Border);
	
	webMI.gfx.setStroke("back_display", color_Popup_Border);

	webMI.gfx.setFill("back_display", color_Main_Background);
	
	webMI.gfx.setFill("lbl_title", color_Main_Background);
}

/////////////////권한 레벨 설정/////////////////
webMI.trigger.connect("Apply_Popup_prevention_level_Set",function(e){
	if (isNaN(e.value))
	{
		prevention_level = 0;
	}
	else
	{
		prevention_level = e.value;
	}
});

///////////////////////////*  적용 버튼 클릭 이벤트  *///////////////////////////

webMI.addEvent("btn_apply", "click", function(e) {
	webMI.trigger.fire("Prevention_Check", {level : prevention_level, callback : function(access)	
	{
		if (access == false)
		{
			webMI.trigger.fire("Apply_Popup_Cancel");
			webMI.trigger.fire("Info_Popup_Open", { title : "T{권한}", info : "T{해당 기능에 대한 권한이 없습니다.}" });
			return;
		}
		else
		{
			webMI.trigger.fire("Apply");
			//webMI.trigger.fire("Apply_Popup_Cancel");
		}
	}});
});


///////////////////////////*  적용 팝업 닫기  *///////////////////////////

webMI.addEvent("btn_cancel", "click", function(e) {
	webMI.trigger.fire("Apply_Popup_Cancel");
});