var color = webMI.query["color"];

//////////초기화 인자들/////////
var sign_active = false;
var dot_num = 2;
var digit_num = 3;
var pre_value = 0;

var data_title = "";
var data_unit = "";

var parameter = "";
/////////////////////////////////////////
var check_value = null;
var now_data_string = "";
//var clicked = false;
var dot_active = false;

/////////////////색상 변수/////////////////////
var color_Font_Title;
var color_Popup_Border;
var color_Main_Background;
var color_Font_Default;
var color_TextBox_Stroke;
var color_Font_Disable;
var color_Font_Selected_Data;
var color_Under_Line;
var color_Green_Active;
var color_Bento;

//////////////////////////////////////////////////////

///////////////////////////*  주/야간 색상 변경 *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	if (color_mode == "Night")
	{
		color_Font_Title = color.Font_Title.Night;
		color_Popup_Border = color.Popup_Border.Night;
		color_Main_Background = color.Main_Background.Night;
		color_Font_Default = color.Font_Default.Night;
		color_TextBox_Stroke  = color.TextBox_Stroke.Night;
		color_Font_Disable = color.Font_Disable.Night;
		color_Font_Selected_Data = color.Font_Selected_Data.Night;
		color_Under_Line = color.Under_Line.Night;
		color_Green_Active = color.Green_Active.Night;
		color_Bento = color.Bento.Night;
	}
	else if (color_mode == "Day")
	{
		color_Font_Title = color.Font_Title.Day;
		color_Popup_Border = color.Popup_Border.Day;
		color_Main_Background = color.Main_Background.Day;
		color_Font_Default = color.Font_Default.Day;
		color_TextBox_Stroke  = color.TextBox_Stroke.Day;
		color_Font_Disable = color.Font_Disable.Day;
		color_Font_Selected_Data = color.Font_Selected_Data.Day;
		color_Under_Line = color.Under_Line.Day;
		color_Green_Active = color.Green_Active.Day;
		color_Bento = color.Bento.Day;
	}
	
	webMI.gfx.setFill("title_display1", color_Popup_Border);
	webMI.gfx.setFill("title_display2", color_Popup_Border);
	webMI.gfx.setStroke("title_display1",color_Popup_Border);
	webMI.gfx.setStroke("title_display2",color_Popup_Border);
	
	webMI.gfx.setStroke("back_display", color_Popup_Border);
	webMI.gfx.setFill("back_display", color_Main_Background);
	
	webMI.gfx.setFill("lbl_title", color_Main_Background);
	webMI.gfx.setFill("lbl_data_title", color_Font_Default);
	webMI.gfx.setFill("lbl_data", color_Font_Default);
	webMI.gfx.setFill("lbl_data_unit", color_Font_Default);
	
	webMI.gfx.setStroke("line_1", color_Under_Line);
	
	webMI.gfx.setFill("back_pad", color_Bento);
}

//////////////////팝업창 오픈전 초기 데이터 수집////////////////////////
webMI.trigger.connect("NumberPad_Init", function(e)
{
	sign_active = e.value.sign_active;
	dot_num = e.value.dot_num;
	digit_num = e.value.digit_num;
	pre_value = e.value.pre_value;
	
	data_title = e.value.data_title;
	data_unit = e.value.data_unit;
	
	parameter = e.value.parameter;
	
	now_data_string = String(pre_value);	
	
	if (dot_num == 0)
	{
		dot_active = false;
		webMI.trigger.fire("btn_inactive", "popup_dot");
	}
	else
	{
		dot_active = true;
		webMI.trigger.fire("btn_active", "popup_dot");
	}
	
	if (!sign_active)
	{
		webMI.trigger.fire("btn_inactive", "popup_plus");
		webMI.trigger.fire("btn_inactive", "popup_minus");
	}
	else
	{
		webMI.trigger.fire("btn_active", "popup_plus");
		webMI.trigger.fire("btn_active", "popup_minus");
	}
	
	webMI.gfx.setText("lbl_data_title", data_title);
	webMI.gfx.setText("lbl_data_unit", data_unit);	
	
	Init();
});

///////////////////////////*  닫기 버튼 클릭 이벤트  *///////////////////////////
webMI.addEvent("btn_close", "click", function(e)
{
	webMI.trigger.fire("NumberPad_Popup_Close");
});

//////////////////////// 적용 버튼 클릭////////////////////////
webMI.addEvent("btn_apply", "click", function(e) {

	if (check_value == null)
	{
		return;
	}

	webMI.trigger.fire("Prevention_Check", {level : 2, callback : function(access)	
	{
		if (access == false)
		{
			webMI.trigger.fire("Info_Popup_Open", { title : "T{권한}", info : "T{해당 기능에 대한 권한이 없습니다.}" });
			return;
		}
		else
		{
			webMI.trigger.fire("NumberPad_Popup_Done", { "parameter" : parameter, "data" :  check_value});
			webMI.trigger.fire("NumberPad_Popup_Close");
		}
	}});
});


///////////// 데이터 클릭 이벤트////////////////
/*webMI.addEvent("btn_data_click", "click", function(e)
{
	if (clicked)
	{
		if (check_value != null)
		{
			webMI.gfx.setText("lbl_data", Number(pre_value));
			webMI.gfx.setFill("lbl_data", color_Green_Active);
		}
		else
		{
			webMI.gfx.setText("lbl_data", Number(pre_value));
			webMI.gfx.setFill("lbl_data", color_Font_Default);
		}
		
		clicked = false;	
		check_value = null;
	}
	else
	{
		var temp_text = Digit_Count_to_Temp(digit_num, dot_num);
		
		now_data_string = temp_text;
		
		webMI.gfx.setText("lbl_data", temp_text);
		webMI.gfx.setFill("lbl_data", color_Font_Selected_Data);
		
		clicked = true;
	}
	
	webMI.trigger.fire("btn_inactive", "apply");
	Shadow_visible(clicked);
});*/

///////////////////////////*  글자수 리턴 함수  *///////////////////////////
function Digit_Count_to_Temp(digitNum, dotNum)
{
	let temp_text = "";
	
	for (let i = 0; i <digitNum; i++)
	{
		temp_text = temp_text + "_ ";
	}
	
	if (dotNum != 0)
	{
		temp_text = temp_text + ". ";
	}		
		
	for (let i = 0; i <dotNum; i++)
	{
		temp_text = temp_text + "_ ";
	}				
	
	return temp_text;
}

///////////////////////////*  숫자 버튼 클릭 이벤트 *///////////////////////////
function FooterNumber_Click(buttonIds)
{
	buttonIds.forEach(buttonId =>
	{
		webMI.addEvent(buttonId, "click", function(e)
		{
			webMI.gfx.setFill("lbl_data", color_Font_Selected_Data);
			let number = Number(buttonId.slice(-1));
			let minus = false;
			
			if (now_data_string.includes("_"))
			{
				now_data_string = "";
			}	
			
			if (now_data_string.charAt(0) == "-")
			{
				now_data_string = now_data_string.replace("-","");
				minus= true;
			}				
			
			let dot_none = !now_data_string.includes(".");
			let str_len = now_data_string.length;
			
			if (dot_none)
			{
				if (str_len < digit_num)
				{
					now_data_string = now_data_string + String(number);
				}
			}
			else
			{
				let temp_txt = now_data_string.split(".");
				temp_txt = temp_txt[temp_txt.length - 1];
				
				if (temp_txt.length < dot_num)
				{
					now_data_string = now_data_string + String(number);
				}		
			}
			
			now_data_string = minus ? "-" + now_data_string : now_data_string;
			webMI.gfx.setText("lbl_data", now_data_string);
		});
	});
}

FooterNumber_Click(["btn_1","btn_2","btn_3","btn_4","btn_5","btn_6","btn_7","btn_8","btn_9","btn_0"]);

/////////////////////// + 버튼 클릭 ///////////////////////
webMI.addEvent("btn_plus", "click", function(e) {

	if (!sign_active)
	{
		return;
	}
	
	if (now_data_string.includes("_"))
	{
		return;
	}		
	
	if (now_data_string.charAt(0) == "-")
	{
		now_data_string = now_data_string.replace("-","");
	}
	
	webMI.gfx.setText("lbl_data", now_data_string);
});

/////////////////////// - 버튼 클릭 ///////////////////////
webMI.addEvent("btn_minus", "click", function(e) {

	if (!sign_active)
	{
		return;
	}
	
	if (now_data_string.includes("_"))
	{
		now_data_string = "-";
	}	
		
	if (now_data_string.charAt(0) != "-")
	{
		now_data_string = "-" + now_data_string;
	}
	
	webMI.gfx.setText("lbl_data", now_data_string);
});

///////////////////////// . 버튼 클릭 ///////////////////////
webMI.addEvent("btn_dot", "click", function(e) {

	if (!dot_active)
	{
		return;
	}

	if (now_data_string.includes("_"))
	{
		now_data_string = "0.";
	}
	
	if (!now_data_string.includes("."))
	{
		now_data_string = now_data_string + ".";
	}	

	webMI.gfx.setText("lbl_data", now_data_string);
});

////////////////////// 지우기 버튼 클릭 //////////////////////////
webMI.addEvent("btn_backspace", "click", function(e) {

	if (now_data_string.includes("_"))
	{
		return;
	}
	
	if (now_data_string.length > 0)
	{
		now_data_string = now_data_string.slice(0, -1);
	}

	if (now_data_string.length == 0)
	{
		now_data_string = Digit_Count_to_Temp(digit_num, dot_num);
	}
	
	webMI.gfx.setText("lbl_data", now_data_string);
});

//////////////////////// 초기화 버튼 클릭	///////////////////////////
webMI.addEvent("btn_reset", "click", function(e) {
	Init();
});

////////////////// Shadow_visible///////////////////
/*function Shadow_visible(data_clicked)
{
	webMI.gfx.setVisible("shadow", !data_clicked);
}*/

/////////////////// 확인 버튼 클릭///////////////////////
webMI.addEvent("btn_check", "click", function(e) {
	if (now_data_string == "-" || now_data_string.includes("_"))
	{
		if (check_value != null)
		{
			//clicked = false;	
			now_data_string = String(check_value);
			
			webMI.gfx.setText("lbl_data", now_data_string);
			webMI.gfx.setFill("lbl_data", color_Green_Active);
			webMI.trigger.fire("btn_active", "apply");
		}
		else
		{
			Init();
		}
		return;
	}
	
	if (now_data_string.slice(-1) == ".")
	{
		now_data_string = now_data_string.slice(0, -1);
	}
	
	//clicked = false;	
	check_value = 	Number(now_data_string);
	//Shadow_visible(clicked);
	webMI.gfx.setText("lbl_data", now_data_string);
	webMI.gfx.setFill("lbl_data", color_Green_Active);
	webMI.trigger.fire("btn_active", "apply");
});

////////////// 선택 초기화////////////////////////////
function Init()
{
	now_data_string = String(pre_value);
	//clicked = false;	
	check_value = null;
	
	webMI.gfx.setText("lbl_data", now_data_string);
	webMI.gfx.setFill("lbl_data", color_Font_Default);
	webMI.trigger.fire("btn_inactive", "apply");
	//Shadow_visible(clicked);
}
