var color = webMI.query["color"];

var time_setting;
var timerId;

let Start_year;
let Start_month;
let Start_date;
let Start_hour;
let Start_min;
let Start_sec;

let End_year;
let End_month;
let End_date;
let End_hour;
let End_min;
let End_sec;

var push_keep_up_time = 150;

// 월별 일수 배열 (1:1월, 2:2월 ... 12:12월)
const daysInMonth = {
    1: 31, 2: 28, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
};

// 윤년 계산
function isLeapYear(year) {
    return (year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0));
}


///////////////////////////*  주/야간 색상 변경  *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	webMI.gfx.setFill("lbl_title",color.Main_Background[color_mode]);
	
	webMI.gfx.setFill("title_display1",color.Popup_Border[color_mode]);
	webMI.gfx.setFill("title_display2",color.Popup_Border[color_mode]);
	webMI.gfx.setStroke("title_display1",color.Popup_Border[color_mode]);
	webMI.gfx.setStroke("title_display2",color.Popup_Border[color_mode]);
	
	webMI.gfx.setStroke("back_display", color.Popup_Border[color_mode]);
	webMI.gfx.setFill("back_display", color.Main_Background[color_mode]);
	
	webMI.gfx.setStroke("line_1", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_2", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_3", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_4", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_5", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_6", color.Under_Line[color_mode]);	
	webMI.gfx.setStroke("line_7", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_8", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_9", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_10", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_11", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_12", color.Under_Line[color_mode]);	
	
	webMI.gfx.setFill("lbl_start", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_Start_year", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_Start_month", color.Font_Title[color_mode]);	
	webMI.gfx.setFill("lbl_Start_date", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_Start_hour", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_Start_minute", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_Start_sec", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_End", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_End_year", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_End_month", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_End_date", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_End_hour", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_End_minute", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_End_sec", color.Font_Title[color_mode]);
	
	webMI.gfx.setFill("Start_year", color.Font_Default[color_mode]);
	webMI.gfx.setFill("Start_month", color.Font_Default[color_mode]);
	webMI.gfx.setFill("Start_date", color.Font_Default[color_mode]);	
	webMI.gfx.setFill("Start_hour", color.Font_Default[color_mode]);
	webMI.gfx.setFill("Start_min", color.Font_Default[color_mode]);
	webMI.gfx.setFill("Start_sec", color.Font_Default[color_mode]);
	webMI.gfx.setFill("End_year", color.Font_Default[color_mode]);
	webMI.gfx.setFill("End_month", color.Font_Default[color_mode]);
	webMI.gfx.setFill("End_date", color.Font_Default[color_mode]);
	webMI.gfx.setFill("End_hour", color.Font_Default[color_mode]);
	webMI.gfx.setFill("End_min", color.Font_Default[color_mode]);
	webMI.gfx.setFill("End_sec", color.Font_Default[color_mode]);
}


///////////////////////////*  팝업 닫기 *///////////////////////////

webMI.addEvent("btn_close", "click", function(e)
{
	webMI.trigger.fire("Cloese_Time_Popup");
});

///////////////////////////*  현재 팝업창의 시간을 현재 시간으로 업데이트  *///////////////////////////

webMI.trigger.connect("Real_Time_Popup_Settings", function(e)
{
	let start_time = new Date(e.value.start_date);
	let end_time = new Date(e.value.end_date);
	
	Start_year = start_time.getFullYear();
	Start_month = start_time.getMonth() + 1;
	Start_date = start_time.getDate();
	Start_hour = start_time.getHours();
	Start_min = start_time.getMinutes();
	Start_sec = start_time.getSeconds();
	
	End_year = end_time.getFullYear();
	End_month = end_time.getMonth() + 1;
	End_date = end_time.getDate();
	End_hour = end_time.getHours();
	End_min = end_time.getMinutes();
	End_sec = end_time.getSeconds();
	
	webMI.gfx.setText("Start_year", Start_year);
	webMI.gfx.setText("Start_month", String(Start_month).padStart(2, '0'));
	webMI.gfx.setText("Start_date", String(Start_date).padStart(2, '0'));
	webMI.gfx.setText("Start_hour", String(Start_hour).padStart(2, '0'));
	webMI.gfx.setText("Start_min", String(Start_min).padStart(2, '0'));
	webMI.gfx.setText("Start_sec", String(Start_sec).padStart(2, '0'));
	
	webMI.gfx.setText("End_year", End_year);
	webMI.gfx.setText("End_month", String(End_month).padStart(2, '0'));
	webMI.gfx.setText("End_date", String(End_date).padStart(2, '0'));
	webMI.gfx.setText("End_hour", String(End_hour).padStart(2, '0'));
	webMI.gfx.setText("End_min", String(End_min).padStart(2, '0'));
	webMI.gfx.setText("End_sec", String(End_sec).padStart(2, '0'));
});

///////////////////////////*  Start UP/DOWN 버튼 클릭 이벤트  *///////////////////////////

function Date_Update_from_Start_Max()
{
	if (isLeapYear(Start_year) == true)
	{
		if (Number(Start_month) == 2)
		{
			if (Number(Start_date) > 29)
			{
				Start_date = 29;
				webMI.gfx.setText("Start_date", String(Start_date).padStart(2, '0'));
			}
		}
		else
		{
			if (daysInMonth[Number(Start_month)] < Number(Start_date))
			{
				Start_date = daysInMonth[Number(Start_month)];
				webMI.gfx.setText("Start_date", String(Start_date).padStart(2, '0'));
			}
		}
	}
	else
	{
			if (daysInMonth[Number(Start_month)] < Number(Start_date))
			{
				Start_date = daysInMonth[Number(Start_month)];
				webMI.gfx.setText("Start_date", String(Start_date).padStart(2, '0'));
			}
	}
}

function Start_Date_Event(buttonId)
{
	///////////////////////////*  년  *///////////////////////////
		
	if (buttonId == "btn_Start_Year_Down")
	{
		Start_year = Number(Start_year) - 1;
		
		if(Start_year < 2000)
		{
			Start_year = 2000;
		}		
		
		webMI.gfx.setText("Start_year", Start_year);
		Date_Update_from_Start_Max();
			
	} 
	else if (buttonId == "btn_Start_Year_Up")
	{
		Start_year = Number(Start_year) + 1;
		webMI.gfx.setText("Start_year", Start_year);
		Date_Update_from_Start_Max();
	}
	
	///////////////////////////*  월  *///////////////////////////
	
	else if (buttonId == "btn_Start_Month_Down")
	{
		if (Start_month <= 1)
		{
			Start_month = 12;
		}
		else
		{
			Start_month = Number(Start_month) - 1;
		}
		Date_Update_from_Start_Max();
		webMI.gfx.setText("Start_month", String(Start_month).padStart(2, '0'));
	} 
	else if (buttonId == "btn_Start_Month_Up")
	{
		if (Start_month >= 12)
		{
			Start_month = 1;
		}
		else
		{
			Start_month = Number(Start_month) + 1;
		}
		Date_Update_from_Start_Max();
		webMI.gfx.setText("Start_month", String(Start_month).padStart(2, '0'));
	}

	///////////////////////////*  일  *///////////////////////////
	
	else if (buttonId == "btn_Start_Date_Down")
	{
		if (Start_date <= 1)
		{
			let maxDays = daysInMonth[Start_month];
			
			if (Start_month === 2 && isLeapYear(Start_year))
			{
				maxDays = 29;  // 윤년 2월
			}
			
			Start_date = maxDays;
		}
		else
		{
			Start_date = Number(Start_date) - 1;
		}
		webMI.gfx.setText("Start_date", String(Start_date).padStart(2, '0'));
	} 
	else if (buttonId == "btn_Start_Date_Up")
	{
		if (Start_month === 2)
		{	
			if (isLeapYear(Start_year) && (Start_date >= 29))
			{
				Start_date = 1;
			}
			else if (isLeapYear(Start_year) == false && (Start_date >= 28))
			{
				Start_date = 1;
			}
			else
			{
				Start_date =  Number(Start_date) + 1;
			}
		}
		else if (Start_date >= daysInMonth[Start_month])
		{
			Start_date = 1;
		}
		else
		{
			Start_date =  Number(Start_date) + 1;
		}
		
		webMI.gfx.setText("Start_date", String(Start_date).padStart(2, '0'));
	}
	
	///////////////////////////*  시  *///////////////////////////
	
	else if (buttonId == "btn_Start_Hour_Down")
	{
		if (Start_hour <= 0)
		{
			Start_hour = 23;
		}
		else
		{
			Start_hour = Number(Start_hour) - 1;
		}
		webMI.gfx.setText("Start_hour", String(Start_hour).padStart(2, '0'));
	} 
	else if (buttonId == "btn_Start_Hour_Up")
	{
		if (Start_hour >= 23)
		{
			Start_hour = 0;
		}
		else
		{
			Start_hour = Number(Start_hour) + 1;
		}
		webMI.gfx.setText("Start_hour", String(Start_hour).padStart(2, '0'));
	} 
	
	///////////////////////////*  분  *///////////////////////////
	
	else if (buttonId == "btn_Start_Min_Down")
	{
		if (Start_min <= 0)
		{
			Start_min = 59;
		}
		else
		{
			Start_min = Number(Start_min) - 1;
		}
		webMI.gfx.setText("Start_min", String(Start_min).padStart(2, '0'));
	} 
	else if (buttonId == "btn_Start_Min_Up")
	{
		if (Start_min >= 59)
		{
			Start_min = 0;
		}
		else
		{
			Start_min = Number(Start_min) + 1;
		}
		webMI.gfx.setText("Start_min", String(Start_min).padStart(2, '0'));
	}
	
	///////////////////////////*  초  *///////////////////////////
	
	else if (buttonId == "btn_Start_Sec_Down")
	{
		if (Start_sec <= 0)
		{
			Start_sec = 59;
		}
		else
		{
			Start_sec = Number(Start_sec) - 1;
		}
		webMI.gfx.setText("Start_sec", String(Start_sec).padStart(2, '0'));
	} 
	else if (buttonId == "btn_Start_Sec_Up")
	{
		if (Start_sec >= 59)
		{
			Start_sec = 0;
		}
		else
		{
			Start_sec = Number(Start_sec) + 1;
		}
		webMI.gfx.setText("Start_sec", String(Start_sec).padStart(2, '0'));
	}
	
		/////////////////////누르고 있으면 300ms 마다 값이 증가/////////////	
	
	timerId = setTimeout(function() 
	{
		timerId  = null;
		Start_Date_Event(buttonId);
	}, push_keep_up_time);	
}

/////////////////이벤트 등록/////////////////////////////////////

function Start_Btn_Click_Event(buttonIds)
{
	buttonIds.forEach(buttonId =>
	{
		webMI.addEvent(buttonId,  ["touchstart"] , function(e)
		{	
			if (timerId  == null)
			{
				Start_Date_Event(buttonId);
			}		
		});
	});
	
	buttonIds.forEach(buttonId =>
	{
		webMI.addEvent(buttonId,  ["mouseup","mouseout","touchend","touchcancel"] , function(e)
		{					
				if (timerId  != null)
				{
					clearTimeout(timerId);
					timerId  = null;
				}
		});
	});
}

////////////////////////////////이벤트 한번에 등록///////////////////////////////////////
Start_Btn_Click_Event(["btn_Start_Year_Down", "btn_Start_Year_Up", 
								"btn_Start_Month_Down", "btn_Start_Month_Up", 
								"btn_Start_Date_Down", "btn_Start_Date_Up", 
								"btn_Start_Hour_Down", "btn_Start_Hour_Up", 
								"btn_Start_Min_Down", "btn_Start_Min_Up",
								"btn_Start_Sec_Down", "btn_Start_Sec_Up" ]);

///////////////////////////*  End UP/DOWN 버튼 클릭 이벤트  *///////////////////////////

function Date_Update_from_End_Max()
{
	if (isLeapYear(End_year) == true)
	{
		if (Number(End_month) == 2)
		{
			if (Number(End_date) > 29)
			{
				End_date = 29;
				webMI.gfx.setText("End_date", String(End_date).padStart(2, '0'));
			}
		}
		else
		{
			if (daysInMonth[Number(End_month)] < Number(End_date))
			{
				End_date = daysInMonth[Number(End_month)];
				webMI.gfx.setText("End_date", String(End_date).padStart(2, '0'));
			}
		}
	}
	else
	{
			if (daysInMonth[Number(End_month)] < Number(End_date))
			{
				End_date = daysInMonth[Number(End_month)];
				webMI.gfx.setText("End_date", String(End_date).padStart(2, '0'));
			}
	}
}

function End_Date_Event(buttonId)
{
	///////////////////////////*  년  *///////////////////////////
		
	if (buttonId == "btn_End_Year_Down")
	{
		End_year = Number(End_year) - 1;
		
		if(End_year < 2000)
		{
			End_year = 2000;
		}		
		
		webMI.gfx.setText("End_year", End_year);
		Date_Update_from_End_Max();
			
	} 
	else if (buttonId == "btn_End_Year_Up")
	{
		End_year = Number(End_year) + 1;
		webMI.gfx.setText("End_year", End_year);
		Date_Update_from_End_Max();
	}
	
	///////////////////////////*  월  *///////////////////////////
	
	else if (buttonId == "btn_End_Month_Down")
	{
		if (End_month <= 1)
		{
			End_month = 12;
		}
		else
		{
			End_month = Number(End_month) - 1;
		}
		Date_Update_from_End_Max();
		webMI.gfx.setText("End_month", String(End_month).padStart(2, '0'));
	} 
	else if (buttonId == "btn_End_Month_Up")
	{
		if (End_month >= 12)
		{
			End_month = 1;
		}
		else
		{
			End_month = Number(End_month) + 1;
		}
		Date_Update_from_End_Max();
		webMI.gfx.setText("End_month", String(End_month).padStart(2, '0'));
	}

	///////////////////////////*  일  *///////////////////////////
	
	else if (buttonId == "btn_End_Date_Down")
	{
		if (End_date <= 1)
		{
			let maxDays = daysInMonth[End_month];
			
			if (End_month === 2 && isLeapYear(End_year))
			{
				maxDays = 29;  // 윤년 2월
			}
			
			End_date = maxDays;
		}
		else
		{
			End_date = Number(End_date) - 1;
		}
		webMI.gfx.setText("End_date", String(End_date).padStart(2, '0'));
	} 
	else if (buttonId == "btn_End_Date_Up")
	{
		if (End_month === 2)
		{	
			if (isLeapYear(End_year) && (End_date >= 29))
			{
				End_date = 1;
			}
			else if (isLeapYear(End_year) == false && (End_date >= 28))
			{
				End_date = 1;
			}
			else
			{
				End_date =  Number(End_date) + 1;
			}
		}
		else if (End_date >= daysInMonth[End_month])
		{
			End_date = 1;
		}
		else
		{
			End_date =  Number(End_date) + 1;
		}
		
		webMI.gfx.setText("End_date", String(End_date).padStart(2, '0'));
	}
	
	///////////////////////////*  시  *///////////////////////////
	
	else if (buttonId == "btn_End_Hour_Down")
	{
		if (End_hour <= 0)
		{
			End_hour = 23;
		}
		else
		{
			End_hour = Number(End_hour) - 1;
		}
		webMI.gfx.setText("End_hour", String(End_hour).padStart(2, '0'));
	} 
	else if (buttonId == "btn_End_Hour_Up")
	{
		if (End_hour >= 23)
		{
			End_hour = 0;
		}
		else
		{
			End_hour = Number(End_hour) + 1;
		}
		webMI.gfx.setText("End_hour", String(End_hour).padStart(2, '0'));
	} 
	
	///////////////////////////*  분  *///////////////////////////
	
	else if (buttonId == "btn_End_Min_Down")
	{
		if (End_min <= 0)
		{
			End_min = 59;
		}
		else
		{
			End_min = Number(End_min) - 1;
		}
		webMI.gfx.setText("End_min", String(End_min).padStart(2, '0'));
	} 
	else if (buttonId == "btn_End_Min_Up")
	{
		if (End_min >= 59)
		{
			End_min = 0;
		}
		else
		{
			End_min = Number(End_min) + 1;
		}
		webMI.gfx.setText("End_min", String(End_min).padStart(2, '0'));
	}
	
	///////////////////////////*  초  *///////////////////////////
	
	else if (buttonId == "btn_End_Sec_Down")
	{
		if (End_sec <= 0)
		{
			End_sec = 59;
		}
		else
		{
			End_sec = Number(End_sec) - 1;
		}
		webMI.gfx.setText("End_sec", String(End_sec).padStart(2, '0'));
	} 
	else if (buttonId == "btn_End_Sec_Up")
	{
		if (End_sec >= 59)
		{
			End_sec = 0;
		}
		else
		{
			End_sec = Number(End_sec) + 1;
		}
		webMI.gfx.setText("End_sec", String(End_sec).padStart(2, '0'));
	}
	
	/////////////////////누르고 있으면 300ms 마다 값이 증가/////////////	
	
	timerId = setTimeout(function() 
	{
		timerId  = null;
		End_Date_Event(buttonId);
	}, push_keep_up_time);	
}

///////////////////이벤트 등록//////////////////////////////////////

function End_Btn_Click_Event(buttonIds)
{
	buttonIds.forEach(buttonId =>
	{
		webMI.addEvent(buttonId,  [ "touchstart"] , function(e)
		{	
			if (timerId  == null)
			{
				End_Date_Event(buttonId);
			}		
		});
	});
	
	buttonIds.forEach(buttonId =>
	{
		webMI.addEvent(buttonId,  ["mouseup","mouseout","touchend","touchcancel"] , function(e)
		{					
				if (timerId  != null)
				{
					clearTimeout(timerId);
					timerId  = null;
				}
		});
	});
}

/////////////////////////이벤트 한번에 등록//////////////////////////////////

End_Btn_Click_Event(["btn_End_Year_Down", "btn_End_Year_Up", 
								"btn_End_Month_Down", "btn_End_Month_Up", 
								"btn_End_Date_Down", "btn_End_Date_Up", 
								"btn_End_Hour_Down", "btn_End_Hour_Up", 
								"btn_End_Min_Down", "btn_End_Min_Up",
								"btn_End_Sec_Down", "btn_End_Sec_Up" ]);


///////////////////////적용 버튼 클릭 시 Date 값 전달/////////////////////////////////							
webMI.addEvent("btn_apply", "click", function(e) {

var startDate = new Date(Start_year, Start_month - 1, Start_date, Start_hour, Start_min, Start_sec);
var endDate = new Date(End_year, End_month - 1, End_date, End_hour, End_min, End_sec);

webMI.trigger.fire("Period_Date_Value", { start_date : startDate.getTime(), end_date : endDate.getTime()});
webMI.trigger.fire("Cloese_Time_Popup");
});

