color = webMI.query["color"];

var img_ship_depth_x = document.getElementById("depth_ship").transform.animVal[0].matrix.e;
var img_ship_depth_y = document.getElementById("depth_ship").transform.animVal[0].matrix.f

var latitude_line_standard_Y = webMI.gfx.getY1("standard_latitude");
var longitude_line_standard_X = webMI.gfx.getX1("standard_longitude");
var depth_max_y = 65;	////depth_ship이 depth 0일 때의 위치(depth_ship의 y 값 + height) 와 바닥의 위치(line_depth_max의 y) 값의 차

var img_map_half_width = 316/2;
var img_map_half_hight = 129/2;
var point_length = 6;

///////////////////////////*  주/야간 색상 변경  *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	webMI.gfx.setFill("lbl_title",color.Main_Background[color_mode]);
	
	webMI.gfx.setFill("title_display1",color.Popup_Border[color_mode]);
	webMI.gfx.setFill("title_display2",color.Popup_Border[color_mode]);
	webMI.gfx.setStroke("title_display1", color.Popup_Border[color_mode]);
	webMI.gfx.setStroke("title_display2", color.Popup_Border[color_mode]);
	
	webMI.gfx.setStroke("back_display", color.Popup_Border[color_mode]);
	webMI.gfx.setFill("back_display", color.Main_Background[color_mode]);
	
	webMI.gfx.setFill("bento_1", color.Bento[color_mode]);
	webMI.gfx.setFill("bento_2", color.Bento[color_mode]);
	webMI.gfx.setFill("bento_3", color.Bento[color_mode]);
	webMI.gfx.setFill("bento_4", color.Bento[color_mode]);
	webMI.gfx.setFill("bento_5", color.Bento[color_mode]);
	
	webMI.gfx.setFill("lbl_roll_text", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_heading_text", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_roll", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_heading", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_roll_unit", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_heading_unit", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_pitch_text", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_depth_text", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_pitch", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_depth", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_pitch_unit", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_depth_unit", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_longitude_text", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_latitude_text", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_longitude", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_latitude", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_heading_N", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_heading_W", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_heading_W2", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_heading_E", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_heading_E2", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_heading_S", color.Font_Title[color_mode]);

	webMI.gfx.setFill("standard_latitude_P", color.Font_Title[color_mode]);
	webMI.gfx.setFill("standard_latitude_E", color.Font_Title[color_mode]);
	
	webMI.gfx.setStroke("line_longitude", color.Red[color_mode]);
	webMI.gfx.setStroke("line_latitude", color.Red[color_mode]);

	webMI.gfx.setStroke("dot_roll_line", color.Red[color_mode]);
	webMI.gfx.setStroke("dot_heading_line", color.Red[color_mode]);
	webMI.gfx.setStroke("dot_pitch_line", color.Red[color_mode]);
	
	webMI.gfx.setStroke("dot_redline1", color.Font_Title[color_mode]);
	webMI.gfx.setStroke("dot_redline2", color.Font_Title[color_mode]);
	webMI.gfx.setStroke("dot_redline3", color.Font_Title[color_mode]);
	webMI.gfx.setStroke("dot_redline4", color.Font_Title[color_mode]);
	webMI.gfx.setStroke("dot_redline5", color.Font_Title[color_mode]);
	webMI.gfx.setStroke("dot_redline6", color.Font_Title[color_mode]);
	
	webMI.gfx.setStroke("standard_longitude", color.Font_Title[color_mode]);
	webMI.gfx.setStroke("standard_latitude", color.Font_Title[color_mode]);

	var temp_element = document.getElementById("standard_depth_arrow");		
	temp_element = temp_element.querySelectorAll("*");
	temp_element.forEach(child => {
		webMI.gfx.setStroke(child.id,color.Red[color_mode]);
		
		if (child.id == "standard_depth_arrow_1")
		{
			webMI.gfx.setFill(child.id, color.Red[color_mode]);
		}
	});

	webMI.gfx.setStroke("line_1", color.TextBox_Stroke[color_mode]);
	webMI.gfx.setStroke("line_2", color.TextBox_Stroke[color_mode]);
	webMI.gfx.setStroke("line_3", color.TextBox_Stroke[color_mode]);
	webMI.gfx.setStroke("line_4", color.TextBox_Stroke[color_mode]);
	webMI.gfx.setStroke("line_5", color.TextBox_Stroke[color_mode]);
	webMI.gfx.setStroke("line_6", color.TextBox_Stroke[color_mode]);
	webMI.gfx.setStroke("line_depth_max", color.Font_Default[color_mode]);
	webMI.gfx.setStroke("line_depth_wave", color.Font_Default[color_mode]);

	temp_element = document.getElementById("draw_roll");		
	temp_element = temp_element.querySelectorAll("*");
	temp_element.forEach(child => {
		webMI.gfx.setStroke(child.id,color.Font_Default[color_mode]);
	});
	
	temp_element = document.getElementById("draw_heading");		
	temp_element = temp_element.querySelectorAll("*");
	temp_element.forEach(child => {
		webMI.gfx.setStroke(child.id,color.Font_Default[color_mode]);
	});
	
	temp_element = document.getElementById("draw_pitch");		
	temp_element = temp_element.querySelectorAll("*");
	temp_element.forEach(child => {
		webMI.gfx.setStroke(child.id,color.Font_Default[color_mode]);
	});
	
	temp_element = document.getElementById("line_depth_ship");		
	temp_element = temp_element.querySelectorAll("*");
	temp_element.forEach(child => {
		webMI.gfx.setStroke(child.id, color.Font_Default[color_mode]);
		
		if (child.id == "line_depth_ship_1")
		{
			webMI.gfx.setFill(child.id, color.Bento[color_mode]);
		}
	});
	
	webMI.gfx.setFill("point", color.Font_Selected_Data[color_mode]);
	webMI.gfx.setStroke("point", "#000000");
}


///////////////////////////*  팝업 닫기  *///////////////////////////

webMI.trigger.connect("Cloese_TOP_Popup", function(e) {
	webMI.display.closeWindow();
});


///////////////////////////*  경도 *///////////////////////////

webMI.data.subscribe("AGENT.OBJECTS.03_ALGOR..Longitude", function(e)
{
	let value = e.value;
	
	let str = DecimalToDMS(value);	
	
	let degrees = String(str.degrees);
	let minutes =String(str.minutes).padStart(2, '0');
	let seconds = String(str.seconds).padStart(2, '0');
	let display = `${degrees}° ${minutes}' ${seconds}"`;
	
	let move_x = Number(longitude_line_standard_X) + Number(Scale_Data(value, -180, 180, -img_map_half_width, img_map_half_width));
	
	webMI.gfx.setX1("line_longitude",move_x);
	webMI.gfx.setX2("line_longitude",move_x + 0.1);
	
	webMI.gfx.setX("point",move_x - (point_length / 2));
	
	webMI.gfx.setText("lbl_longitude", display);
});


///////////////////////////*  위도 구독 *///////////////////////////

webMI.data.subscribe("AGENT.OBJECTS.03_ALGOR..Latitude", function(e)
{
	let value = e.value;
	
	let str = DecimalToDMS(value);	
	
	let degrees = String(str.degrees);
	let minutes =String(str.minutes).padStart(2, '0');
	let seconds = String(str.seconds).padStart(2, '0');
	let display = `${degrees}° ${minutes}' ${seconds}"`;
	
	let move_y = Number(latitude_line_standard_Y) - Number(Scale_Data(value, -90, 90, -img_map_half_hight, img_map_half_hight));
	
	webMI.gfx.setY1("line_latitude",move_y);
	webMI.gfx.setY2("line_latitude",move_y + 0.1);

	webMI.gfx.setY("point",move_y - (point_length / 2));
	
	webMI.gfx.setText("lbl_latitude", display);
});


///////////////////////////*  횡경사각 구독 *///////////////////////////

webMI.data.subscribe("AGENT.OBJECTS.03_ALGOR..Roll", function(e)
{
	let value = parseFloat(e.value.toFixed(2)); // 소수점 2자리까지
	
	webMI.gfx.setRotation("draw_roll", webMI.translate(value, 0, 360, 0,360));
	webMI.gfx.setRotation("dot_roll_line", webMI.translate(value, 0, 360, 0,360));
	webMI.gfx.setText("lbl_roll", String(e.value.toFixed(2)));
});


///////////////////////////*  종경사각 구독 *///////////////////////////

webMI.data.subscribe("AGENT.OBJECTS.03_ALGOR..Pitch", function(e)
{
	let value = parseFloat(e.value.toFixed(2)); // 소수점 2자리까지
	
	webMI.gfx.setRotation("draw_pitch", webMI.translate(value, 0, 360, 0,360));
	webMI.gfx.setRotation("dot_pitch_line", webMI.translate(value, 0, 360, 0,360));
	webMI.gfx.setText("lbl_pitch", String(e.value.toFixed(2)));
});


///////////////////////////*  방위각 구독 *///////////////////////////

webMI.data.subscribe("AGENT.OBJECTS.03_ALGOR..Heading", function(e)
{
	let value = parseFloat(e.value.toFixed(2)); // 소수점 2자리까지
	
	webMI.gfx.setRotation("draw_heading", webMI.translate(value, 0, 360, 0,360));
	webMI.gfx.setRotation("dot_heading_line", webMI.translate(value, 0, 360, 0,360));
	webMI.gfx.setText("lbl_heading", String(e.value.toFixed(2)));
});


///////////////////////////*  심도 구독 *///////////////////////////

webMI.data.subscribe("AGENT.OBJECTS.03_ALGOR..Depth", function(e)										
{
	var depth_move_y = depth_max_y - webMI.gfx.getY("depth_ship") - webMI.gfx.getHeight("depth_ship");
	let value = parseFloat(e.value.toFixed(1)); // 소수점 1자리까지
	webMI.gfx.setText("lbl_depth", String(e.value.toFixed(1)));
	
	let img_ship_depth = document.getElementById("depth_ship");  
	
	var y_loacation = img_ship_depth_y + Scale_Data(value, 0, 600, 0, depth_move_y);
	
	img_ship_depth.setAttribute("transform", `matrix(1,0,0,1,${img_ship_depth_x},${y_loacation})`);				////depth_ship에 그룹을 해제 후 다시 만들었다면 그때 기준의 matrix로 변경해야함
	
});

///////////////////스케일 함수/////////////////////////
function Scale_Data(value, inMin, inMax, outMin, outMax) {

	if (value > inMax)
	{
		value = inMax;
	}
	else if (value < inMin)
	{
		value = inMin;
	}

  return ((value - inMin) * (outMax - outMin)) / (inMax - inMin) + outMin;
}

////////// 경도/위도 값 반환 //////////////
function DmsToDecimal(degrees, minutes, seconds) {
  return degrees + minutes / 60 + seconds / 3600;
}

///////// 경도/위도 도, 분, 초 분리/////////////////
function DecimalToDMS(decimal) {
  const degrees = Math.floor(decimal);
  const minutesFull = (decimal - degrees) * 60;
  const minutes = Math.floor(minutesFull);
  const seconds = ((minutesFull - minutes) * 60).toFixed(0);

  return {
    degrees,
    minutes,
    seconds: parseFloat(seconds)
  };
}