var color = webMI.query["color"];
var probe_num = 0;
let subscriptions = [];

///////////////////////////*  주/야간 색상 변경  *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	webMI.gfx.setFill("tb_title", color.Font_Default[color_mode]);
	
	webMI.gfx.setFill("rect_title", color.Table_Title[color_mode]);
	
	webMI.gfx.setStroke("rect_title", color.Table_Border[color_mode]);
}

//////////////////프로브 선택에 따라 데이터 전시 변경///////////////////
webMI.trigger.connect("Probe_Feedback_Manual_Init", function(e)
{
	probe_num = Number(e.value.probe_num);
	Subscribe_Data();
})

//////////////////프로브 선택에 따라 데이터 전시 변경///////////////////
webMI.trigger.connect("Probe_Feedback_Manual_Unsubscribe", function(e)
{
	if (subscriptions.length != 0)
	{
		subscriptions.forEach(id => webMI.data.unsubscribe(id));
		subscriptions = []; // 구독 취소
	}
	
	probe_num = 0;
})

/////////////데이터 구독///////////////////////
function Subscribe_Data()
{
	if (subscriptions.length != 0)
	{
		subscriptions.forEach(id => webMI.data.unsubscribe(id));
		subscriptions = []; // 구독 취소
	}

	///////////////////////////*  무전류 영향 자기장 *///////////////////////////

	let subId = webMI.data.subscribe("AGENT.OBJECTS.06_PROBE..Probe" + probe_num + ".No_Current_V",function(e)
	{
		webMI.gfx.setText("tb_no_current_V_text_center", e.value.toFixed(1));
		webMI.gfx.setFill("tb_no_current_V_text_center", color.Font_Default[color_mode]);
	});
	
	subscriptions.push(subId); // 구독 ID 저장
	
	subId = webMI.data.subscribe("AGENT.OBJECTS.06_PROBE..Probe" + probe_num + ".No_Current_A",function(e)
	{
		webMI.gfx.setText("tb_no_current_A_text_center", e.value.toFixed(1));
		webMI.gfx.setFill("tb_no_current_A_text_center", color.Font_Default[color_mode]);
	});
	
	subscriptions.push(subId); // 구독 ID 저장
	
	subId = webMI.data.subscribe("AGENT.OBJECTS.06_PROBE..Probe" + probe_num + ".No_Current_L",function(e)
	{
		webMI.gfx.setText("tb_no_current_L_text_center", e.value.toFixed(1));
		webMI.gfx.setFill("tb_no_current_L_text_center", color.Font_Default[color_mode]);
	});
	
	subscriptions.push(subId); // 구독 ID 저장	
	
	subId = webMI.data.subscribe("AGENT.OBJECTS.06_PROBE..Probe" + probe_num + ".No_Current_Magnitude",function(e)
	{
		webMI.gfx.setText("tb_no_current_mag_text_center", e.value.toFixed(1));
		webMI.gfx.setFill("tb_no_current_mag_text_center", color.Font_Default[color_mode]);
	});
	
	subscriptions.push(subId); // 구독 ID 저장
	
	///////////////////////////*  전류 영향 자기장 *///////////////////////////
	
	subId = webMI.data.subscribe("AGENT.OBJECTS.06_PROBE..Probe" + probe_num + ".Current_V",function(e)
	{
		webMI.gfx.setText("tb_current_V_text_center", e.value.toFixed(1));
		webMI.gfx.setFill("tb_current_V_text_center", color.Font_Default[color_mode]);
	});
	
	subscriptions.push(subId); // 구독 ID 저장
	
	subId = webMI.data.subscribe("AGENT.OBJECTS.06_PROBE..Probe" + probe_num + ".Current_A",function(e)
	{
		webMI.gfx.setText("tb_current_A_text_center", e.value.toFixed(1));
		webMI.gfx.setFill("tb_current_A_text_center", color.Font_Default[color_mode]);
	});
	
	subscriptions.push(subId); // 구독 ID 저장
	
	subId = webMI.data.subscribe("AGENT.OBJECTS.06_PROBE..Probe" + probe_num + ".Current_L",function(e)
	{
		webMI.gfx.setText("tb_current_L_text_center", e.value.toFixed(1));
		webMI.gfx.setFill("tb_current_L_text_center", color.Font_Default[color_mode]);
	});
	
	subscriptions.push(subId); // 구독 ID 저장
	
	subId = webMI.data.subscribe("AGENT.OBJECTS.06_PROBE..Probe" + probe_num + ".Current_Magnitude",function(e)
	{
		webMI.gfx.setText("tb_current_mag_text_center", e.value.toFixed(1));
		webMI.gfx.setFill("tb_current_mag_text_center", color.Font_Default[color_mode]);
	});
	
	subscriptions.push(subId); // 구독 ID 저장
}

