var color = webMI.query["color"];
var subscription = null;	// 구독 리스트
var auto_control_addr = "";	

var probe_num = 0;
var control_state = 0;
var auto_control_command_addr = {1 : "AGENT.OBJECTS.06_PROBE..Probe1_Feedback_Command", 2: "AGENT.OBJECTS.06_PROBE..Probe2_Feedback_Command"};	//1일때 시작 , 2일때 취소

/////////// 0 : - , 1 :  자동 조정 중, 2 : 자동 조정 완료
var auto_control_state_addr = {1 : "AGENT.OBJECTS.06_PROBE..Probe1_Feedback_Status", 2 : "AGENT.OBJECTS.06_PROBE..Probe2_Feedback_Status"};

/////////////////색상 변수/////////////////////
var color_Font_Default;
var color_Table_Border;
var color_Bento;

///////////////////////////*  주/야간 색상 변경  *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	color_Font_Default = color.Font_Default[color_mode];
	color_color_Table_Border = color.Table_Border[color_mode];
	color_Bento = color.Bento[color_mode];
	
	webMI.gfx.setFill("lbl_title", color_Font_Default);
	webMI.gfx.setFill("text", color_Font_Default);	
	
	webMI.gfx.setFill("top", color_Bento);
	
	webMI.gfx.setStroke("top", color_color_Table_Border);
	webMI.gfx.setStroke("border", color_color_Table_Border);
	webMI.gfx.setStroke("line", color_color_Table_Border);
}

/////////////////////선택된 프로브 번호/////////////////////////
webMI.trigger.connect("Probe_Feedback_Auto_Init", function(e)
{
	probe_num = e.value.probe_num;
	
	if (subscription != null)
	{
		webMI.data.unsubscribe(subscription);
		subscriptions = null; // 구독 취소
	}	
	
	subscription = webMI.data.subscribe(auto_control_state_addr[probe_num], function(e)
	{
		control_state = e.value;	
	
		if(control_state == 0)
		{
			webMI.trigger.fire("btn_active", "start");
			webMI.trigger.fire("btn_inactive", "cancel");
			
			webMI.gfx.setText("text", "-");
		}
		else
		{
			webMI.trigger.fire("btn_inactive", "start");
			webMI.trigger.fire("btn_active", "cancel");
			
			if (control_state == 1)
			{
				webMI.gfx.setText("text", "T{자동 조정 중}");	// 태그 추가 필요
			}
			else if (control_state == 2)
			{
				webMI.gfx.setText("text", "T{자동 조정 완료}");	// 태그 추가 필요
			}
		}
	});
});

///////////////////////////*  시작 버튼 클릭 이벤트  *///////////////////////////

webMI.addEvent("btn_start", "click", function(e)
{
	if (control_state != 0)
	{
		return;
	}

	control_state = -1;		
	
	webMI.trigger.fire("btn_inactive", "start");
	webMI.data.write(auto_control_command_addr[probe_num], 1);
});


///////////////////////////*  취소 버튼 클릭 이벤트  *///////////////////////////
webMI.addEvent("btn_cancel", "click", function(e)
{
	if (control_state == 0)
	{
		return;
	}
	
	control_state = 0;	
	
	webMI.trigger.fire("btn_inactive", "cancel");
	webMI.data.write(auto_control_command_addr[probe_num], 2);
});

////////////////////// 구독 취소///////////////////////////////////
webMI.trigger.connect("Probe_Feedback_Auto_Unsubscribe", function (e)
{
	webMI.gfx.setText("text", "-");
	probe_num = 0;
	
	if (subscription != null)
	{
		webMI.data.unsubscribe(subscription);
		subscription = null;
	}
});