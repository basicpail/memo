var color = webMI.query["color"];
var top_popup_open = false;

var now_content;

webMI.trigger.fire("btn_inactive", "ship_apply");
var apply_active = false;

///////////////////////////*  주/야간 색상 변경 *///////////////////////////

var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	webMI.gfx.setFill("lbl_title",color.Main_Background[color_mode]);
	
	webMI.gfx.setFill("title_display1",color.Popup_Border[color_mode]);
	webMI.gfx.setFill("title_display2",color.Popup_Border[color_mode]);
	webMI.gfx.setStroke("title_display1", color.Popup_Border[color_mode]);
	webMI.gfx.setStroke("title_display2", color.Popup_Border[color_mode]);
	
	webMI.gfx.setStroke("back_display", color.Popup_Border[color_mode]);
	webMI.gfx.setFill("back_display", color.Main_Background[color_mode]);
	
	webMI.gfx.setFill("text_roll", color.Font_Title[color_mode]);	
	webMI.gfx.setFill("text_pitch", color.Font_Title[color_mode]);	
	webMI.gfx.setFill("text_heading", color.Font_Title[color_mode]);
	webMI.gfx.setFill("text_depth", color.Font_Title[color_mode]);
	webMI.gfx.setFill("text_longitude", color.Font_Title[color_mode]);
	webMI.gfx.setFill("text_latitude", color.Font_Title[color_mode]);
	
	webMI.gfx.setFill("lbl_roll", color.Font_Default[color_mode]);	
	webMI.gfx.setFill("lbl_pitch", color.Font_Default[color_mode]);	
	webMI.gfx.setFill("lbl_heading", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl_depth", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl_longitude", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl_latitude", color.Font_Default[color_mode]);
	
	webMI.gfx.setFill("lbl_roll_unit", color.Font_Default[color_mode]);	
	webMI.gfx.setFill("lbl_pitch_unit", color.Font_Default[color_mode]);	
	webMI.gfx.setFill("lbl_heading_unit", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl_depth_unit", color.Font_Default[color_mode]);
	
	webMI.gfx.setFill("bento_1", color.Bento[color_mode]);
	
	webMI.gfx.setStroke("line1", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line2", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line3", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line4", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line5", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line6", color.Under_Line[color_mode]);
}

webMI.trigger.connect("Submarine_Info_Data_Read", function(e)
{
	webMI.trigger.fire("btn_inactive", "ship_apply");
	preClicked_data = null;
	nowClicked_data = null;
	previousValues = {};
	checkValues = {};
	apply_active = false;	
	top_popup_open = false;
	Click_active();
	Color_Day_Night(color_mode);
	
	///////////////////////////*  경도 읽어오기  *///////////////////////////
	
	webMI.data.read("AGENT.OBJECTS.03_ALGOR..Longitude", function(e)
	{
		let value = e.value;
		webMI.data.write("AGENT.OBJECTS.03_ALGOR..Longitude_Temp", e.value);												// 데이터 쓰기
		
		let str = DecimalToDMS(value);	
		
		let degrees = String(str.degrees).padStart(3, '0');
		let minutes =String(str.minutes).padStart(2, '0');
		let seconds = String(str.seconds).padStart(2, '0');
		let display = `${degrees}° ${minutes}' ${seconds}"`;
	
		webMI.gfx.setText("lbl_longitude", display);
		
		previousValues["lbl_longitude"] = display;
	});
	
	
	///////////////////////////*  위도 읽어오기  *///////////////////////////
	
	webMI.data.read("AGENT.OBJECTS.03_ALGOR..Latitude", function(e)
	{
		let value = e.value;
		webMI.data.write("AGENT.OBJECTS.03_ALGOR..Latitude_Temp", e.value);												// 데이터 쓰기
		
		let str = DecimalToDMS(value);	
		
		let degrees = String(str.degrees).padStart(2, '0');
		let minutes =String(str.minutes).padStart(2, '0');
		let seconds = String(str.seconds).padStart(2, '0');
		let display = `${degrees}° ${minutes}' ${seconds}"`;
	
		webMI.gfx.setText("lbl_latitude", display);
	
		previousValues["lbl_latitude"] = display;
	});
	
	
	///////////////////////////*  횡경사각 읽어오기  *///////////////////////////
	
	webMI.data.read("AGENT.OBJECTS.03_ALGOR..Roll", function(e)
	{
		let value = parseFloat(e.value.toFixed(2)); // 소수점 2자리까지
		webMI.data.write("AGENT.OBJECTS.03_ALGOR..Roll_Temp", e.value);												// 데이터 쓰기
		
		webMI.gfx.setText("lbl_roll", value);
		previousValues["lbl_roll"] = value;
	});
	
	
	///////////////////////////*  종경사각 읽어오기  *///////////////////////////
	
	webMI.data.read("AGENT.OBJECTS.03_ALGOR..Pitch", function(e)
	{
		let value = parseFloat(e.value.toFixed(2)); // 소수점 2자리까지
		webMI.data.write("AGENT.OBJECTS.03_ALGOR..Pitch_Temp", e.value);												// 데이터 쓰기
		
		webMI.gfx.setText("lbl_pitch", value);
		previousValues["lbl_pitch"] = value;
	});
	
	
	///////////////////////////*  방위각 읽어오기  *///////////////////////////
	
	webMI.data.read("AGENT.OBJECTS.03_ALGOR..Heading", function(e)
	{
		let value = parseFloat(e.value.toFixed(2)); // 소수점 2자리까지
		webMI.data.write("AGENT.OBJECTS.03_ALGOR..Heading_Temp", e.value);												// 데이터 쓰기
		
		webMI.gfx.setText("lbl_heading", value);
		previousValues["lbl_heading"] = value;
	});
	
	
	///////////////////////////*  심도 읽어오기  *///////////////////////////
	
	webMI.data.read("AGENT.OBJECTS.03_ALGOR..Depth", function(e)
	{
		let value = parseFloat(e.value.toFixed(1)); // 소수점 1자리까지
		webMI.data.write("AGENT.OBJECTS.03_ALGOR..Depth_Temp", e.value);												// 데이터 쓰기
		
		webMI.gfx.setText("lbl_depth", value);
		previousValues["lbl_depth"] = value;
	});
});

///////////////////////////*  닫기 버튼 클릭 이벤트  *///////////////////////////

webMI.addEvent("btn_close", "click", function(e)
{
	if (top_popup_open)
	{
		return;
	}

	top_popup_open = false;
	Click_active();

	preClicked_data = null;
	nowClicked_data = null;
	previousValues = {};
	checkValues = {};
	webMI.trigger.fire("Submarine_Info_Data_Close");
});

var nowClicked_data = null;
var preClicked_data = null;

let checkValues = {};		// 확인값 저장

var lbl_roll = webMI.gfx.getText("lbl_roll")
var lbl_pitch = webMI.gfx.getText("lbl_pitch")
var lbl_heading = webMI.gfx.getText("lbl_heading")
var lbl_depth = webMI.gfx.getText("lbl_depth")
var lbl_longitude = webMI.gfx.getText("lbl_longitude")
var lbl_latitude = webMI.gfx.getText("lbl_latitude")

let previousValues = {lbl_roll, lbl_pitch, lbl_heading, lbl_depth, lbl_longitude, lbl_latitude};  // 이전값 저장

let now_text;
let pre_text;
var digit_count;

///////////////////////////*  값 클릭 이벤트  *///////////////////////////

function DataClickEvents(data_ids)
{
	data_ids.forEach(data_id =>
	{
		webMI.addEvent(data_id, "click", function(e)
		{
			if (top_popup_open)
			{
				return;
			}		
		
			let target = e.target;	// 현재 선택 셀
			
            nowClicked_data = target.id;		// target.id = manual_popup_btn_click_lbl_xxx
            
			let split = nowClicked_data.split("_");
			now_text = "lbl_" + split.slice(-1).join("_");  // now_text = lbl_xxx
			
			if (now_text != "lbl_longitude" && now_text != "lbl_latitude")
			{
				webMI.trigger.fire("btn_active", "TEST_dot");
			}
			else
			{
				webMI.trigger.fire("btn_inactive", "TEST_dot");
			}
			
			if (preClicked_data != null)	// 이전값이 null이 아닐 때 pre_text 추출
			{
				let sp =  preClicked_data.split("_");
				pre_text = "lbl_" + sp.slice(-1).join("_");	// pre_text = lbl_xxx
			}
			
			webMI.gfx.setVisible("shadow", false);	// 변경할 텍스트 선택 시 키패드 입력 가능
			
			if (preClicked_data == nowClicked_data)	// 이전에 클릭한 셀을 다시 클릭하는 경우
			{
				if (checkValues[now_text] != undefined)
				{
					webMI.gfx.setText(now_text, checkValues[now_text])	// now_text 이전값 복원
					webMI.gfx.setFill(now_text, color.Green_Active[color_mode]);	// 텍스트 색상 원래대로
				}
				else
				{
					webMI.gfx.setText(now_text, previousValues[now_text])	// now_text 이전값 복원
					webMI.gfx.setFill(now_text, color.Font_Default[color_mode]);	// 텍스트 색상 원래대로
				}
				
				nowClicked_data = null;
				
				webMI.gfx.setVisible("shadow", true);	// 현재 선택한 텍스트가 없는 경우 키패드 입력 불가
			}
			else	// 이전에 클릭한 셀과 다른 셀을 클릭하는 경우
			{
				if (preClicked_data != null)
				{
					webMI.gfx.setFill(pre_text, color.Font_Default[color_mode]);	// 폰트 색상 기본
					// pre_text 이전값 복원 또는 확인값 있는 경우 확인값으로
					webMI.gfx.setText(pre_text, previousValues[pre_text])	// pre_text 이전값 복원
				}
				
				webMI.gfx.setFill(now_text, color.Font_Selected_Data[color_mode]);	// 폰트 색 파랑
				
				webMI.gfx.setText(now_text, Digit_Count()); // 선택 시 텍스트
			}
			
            preClicked_data = nowClicked_data;  // 마지막 클릭 셀 업데이트
		});
	});
}

DataClickEvents(["btn_click_roll", "btn_click_pitch", "btn_click_heading", "btn_click_depth", "btn_click_longitude", "btn_click_latitude"]);


///////////////////////////*  글자수 리턴 함수  *///////////////////////////

function Digit_Count()
{
	if (now_text == "lbl_roll" || now_text == "lbl_pitch")
	{
		digit_count = '_ _ . _ _';
	}
	else if (now_text == "lbl_heading")
	{
		digit_count = '_ _ _ . _ _';
	}
	else if (now_text == "lbl_depth")
	{
		digit_count = '_ _ _ _ . _';
	}
	else if (now_text == "lbl_longitude")
	{
		digit_count = '_ _ _° _ _\' _ _\"';
	}
	else if (now_text == "lbl_latitude")
	{
		digit_count = '_ _° _ _\' _ _\"';
	}
	
	return digit_count;
}


///////////////////////////*  키패드 버튼 클릭 이벤트 *///////////////////////////

function FooterButtonClickEvents_coeff(buttonIds)
{
	buttonIds.forEach(buttonId =>
	{
		webMI.addEvent(buttonId, "click", function(e)
		{
			let clickedButton = e.target.id.replace('manual_popup_btn_', '').replace('_btn_click', '');

			let split = nowClicked_data.split("_");
			now_text = "lbl_" + split.slice(-1).join("_");  // now_text = lbl_xxx
			
			now_content = webMI.gfx.getText(now_text);
			
			if (nowClicked_data != null)	// 클릭된 셀이 있는 경우
			{
				if (clickedButton >= 0) // 숫자 버튼
				{
					if (/\d/.test(now_content) || now_content[0] == '-')	// 선택한 텍스트에 숫자가 있거나 마이너스 부호가 있는 경우
					{
						now_content += clickedButton;
						webMI.gfx.setText(now_text, now_content);
					}
					else
					{
						now_content = clickedButton;	// 초기화 후 클릭한 버튼 숫자 전시
						webMI.gfx.setText(now_text, now_content);
					}
					
					var split_str = now_content.split('.'); // 정수 및 소수 자리수 제한
					var max_integer_length = 0;				// 정수 최대 자리수
					var max_decimal_length = 0;				// 소수 최대 자리수
					
					var max_length = 0;
					
					if (Digit_Count() == '_ _ . _ _') 
					{
						max_integer_length = 2;
						max_decimal_length = 2;
					} 
					else if (Digit_Count() == '_ _ _ . _ _') 
					{
						max_integer_length = 3;
						max_decimal_length = 2;
					} 
					else if (Digit_Count() == '_ _ _ _ . _') 
					{
						max_integer_length = 4;
						max_decimal_length = 1;
					}
					else if (Digit_Count() == '_ _ _° _ _\' _ _\"') 
					{
						max_length = 7;
					}
					else if (Digit_Count() == '_ _° _ _\' _ _\"') 
					{
						max_length = 6;
					}
					
					if (max_length > 0)		// 경도 위도 처리
					{
						var number = now_content.replace(/[^0-9\-]/g, ''); // 숫자와 '-'만 추출
						var isNegative = number.startsWith("-");
						
						if (isNegative)
						{
							number = number.slice(1);
						}
						
						number = number.slice(0, max_length);
					
						let degrees, minutes, seconds;
						
						if (max_length === 7)	// 경도
						{
							degrees = number.slice(0, 3);
							minutes = number.slice(3, 5);
							seconds = number.slice(5, 7);
						}
						else	// 위도
						{
							degrees = number.slice(0, 2);
							minutes = number.slice(2, 4);
							seconds = number.slice(4, 6);
						}
					
						now_content = `${isNegative ? '-' : ''}${degrees}° ${minutes}' ${seconds}"`;
					}
					else
					{
						if (split_str[0][0] == '-')	// 마이너스 부호 고려 소수점 자리수
						{
							split_str[0] = split_str[0].slice(0, max_integer_length + 1);
						}
						else 
						{
							split_str[0] = split_str[0].slice(0, max_integer_length);
						}
						
						if (split_str.length == 2)
						{
							split_str[1] = split_str[1].slice(0, max_decimal_length);
							now_content = split_str[0] + '.' + split_str[1]; // 정수부 + 소수부
						}
						else 
						{
							now_content = split_str[0]; // 정수부만 있을 경우
						}
					}
					
					webMI.gfx.setText(now_text, now_content);

				/*
					if (clickedButton > 0)	// '0'만 있으면 지우기
					{
						if (/^0+$/.test(now_content))
						{
							now_content = '';
						}
					}
					*/
				}
				else if (clickedButton == "plus")	// + 버튼
				{
					if (now_content[0] == '-')
					{
						now_content = now_content.substring(1);		// 마이너스 부호 삭제
						webMI.gfx.setText(now_text, now_content);  // 업데이트된 값 설정
						
						if (now_content.length === 0)
						{
							webMI.gfx.setText(now_text, Digit_Count());
						}
					}
				}
				else if (clickedButton == "minus")	// - 버튼
				{
					if (now_content[0] != '-')		// 텍스트 맨 앞에 마이너스 부호가 없다면
					{
						if (!/\d/.test(now_content))	// 선택된 텍스트에 숫자 포함 x
						{
							now_content = '';
							webMI.gfx.setText(now_text, now_content);
						}
						webMI.gfx.setText(now_text, '-' + now_content);
					}
				}
				else if (clickedButton == "dot")	// . 버튼
				{
					if (now_text == "lbl_longitude" || now_text == "lbl_latitude")
					{
						return;
					}				
				
					if (!/\d/.test(now_content))	// 선택된 텍스트에 숫자 포함 x
					{
						now_content = '0';
					}
					
					if (!now_content.includes('.'))
					{
						if(now_content == '-')
						{
							now_content = '-0';
						}
						webMI.gfx.setText(now_text, now_content + '.');
					}
				}
				else if (clickedButton == "backspace")		// 백스페이스 버튼																					경도 위도 백스페이스 버튼 확인
				{
					if (/\d/.test(now_content))	// 선택된 텍스트에 숫자 포함
					{
						 // 문자열을 뒤에서부터 검사해서 마지막 숫자의 위치 찾기(경도/위도 단위 제외 삭제)
						for (let i = now_content.length - 1; i >= 0; i--)
						{
							if (/\d/.test(now_content[i]))
							{
								now_content = now_content.slice(0, i) + now_content.slice(i + 1);		// 해당 숫자 제거
								break;
							}
						}
						
						webMI.gfx.setText(now_text, now_content);
					}
					if (now_content == '' || now_content == '° \' \"' || (now_content[0] == '-' && now_content[1] == null))
					{
						webMI.gfx.setText(now_text, Digit_Count());
					}
				}
				else if (clickedButton == "reset")		// 초기화 버튼
				{
					console.log(previousValues[now_text])
					webMI.gfx.setText(now_text, previousValues[now_text]);	// 이전 값으로 변경
					webMI.gfx.setFill(now_text, color.Font_Default[color_mode]);	// 텍스트 색상 원래대로
					delete checkValues[now_text];
					
					if (Object.keys(checkValues).length === 0)
					{
						webMI.trigger.fire("btn_inactive", "ship_apply");
						apply_active = false;
					}
					
					nowClicked_data = null;
					preClicked_data = null;
					
					webMI.gfx.setVisible("shadow", true);	// 키패드 입력 불가
				}
				else if (clickedButton == "check")		// 확인 버튼
				{	
					var no_change = false;
					
					if (!/\d/.test(now_content))	// 아무것도 쓰지 않고 확인 버튼 누르는 경우 이전 값
					{
						no_change = true;
						now_content = previousValues[now_text];
					}
					else if (now_content.slice(-1) == '.')	// 마지막 글자가 점인 경우 점 삭제
					{
						now_content = now_content.slice(0, -1);
					}
									
					if (now_text == "lbl_longitude" || now_text == "lbl_latitude")				
					{
						var minus = now_content.charAt(0) == "-" ? true : false;				
						var cleaned = now_content.replace(/[^\d]+/g, ' ').trim();
						var parts = cleaned.split(/\s+/);  // 공백 기준으로 분할
						var char_num = now_text == "lbl_longitude" ? 3 : 2;		
						var temp_value = 0; 
						
						if (parts.length == 0)
						{
							now_content =  now_text == "lbl_longitude" ? '000° 00\' 00\"' : '00° 00\' 00\"';
						}
						else if (parts.length == 1)
						{					
							now_content = parts[0].padStart(char_num, '0') + '° 00\' 00\"';
							temp_value = DmsToDecimal(Number(parts[0]),0,0);
						}
						else if (parts.length == 2)
						{
							now_content = parts[0].padStart(char_num, '0') + "° " +  parts[1].padStart(2, '0') +'\' 00\"';
							temp_value = DmsToDecimal(Number(parts[0]),Number(parts[1]),0);
						}
						else if (parts.length == 3)
						{
							now_content = parts[0].padStart(char_num, '0') + "° " +  parts[1].padStart(2, '0') + '\' ' + parts[2].padStart(2, '0') +  '\"';
							temp_value = DmsToDecimal(Number(parts[0]),Number(parts[1]),Number(parts[2]));
						}
						
						if (now_text == "lbl_longitude" )
						{
							now_content = temp_value >= 180 ? '180° 00\' 00\"' : now_content; 
						}
						else
						{
							now_content = temp_value >= 90 ? '90° 00\' 00\"' : now_content; 
						}
						 			
						now_content = minus == true ? "-" + now_content : now_content;
					}
				
					webMI.gfx.setText(now_text, now_content);
					
					if (!no_change)
					{
						checkValues[now_text] = now_content;
					}
					
					if (checkValues[now_text] != undefined)
					{
						webMI.gfx.setFill(now_text, color.Green_Active[color_mode]);	// 텍스트 색상 원래대로
					}
					else
					{
						webMI.gfx.setFill(now_text, color.Font_Default[color_mode]);	// 텍스트 색상 원래대로
					}
					
					nowClicked_data = null;
					preClicked_data = null;
					webMI.gfx.setVisible("shadow", true);	// 키패드 입력 불가
					
					if (Object.keys(checkValues).length != 0)
					{
						apply_active = true;
						webMI.trigger.fire("btn_active", "ship_apply");
					}
					else
					{
						apply_active = false;
						webMI.trigger.fire("btn_inactive", "ship_apply");
					}
				 }
			}
		});
	});
}

FooterButtonClickEvents_coeff(["btn_1", "btn_2", "btn_3", "btn_4", "btn_5", "btn_6", "btn_7", "btn_8", "btn_9", "btn_0", "btn_plus", "btn_minus", "btn_dot", "btn_backspace", "btn_reset", "btn_check"]);


///////////////////////////*  적용 버튼 클릭 이벤트 *///////////////////////////

webMI.addEvent("btn_apply", "click", function(e)
{
	if (apply_active && !top_popup_open)
	{
		webMI.trigger.fire("Prevention_Check", {level : 2, callback : function(access)	
		{
			if (access == false)
			{
				webMI.trigger.fire("Info_Popup_Open", { title : "T{권한}", info : "T{해당 기능에 대한 권한이 없습니다.}" });
			}
			else
			{
				webMI.trigger.fire("Submarine_Info_Data_Apply", checkValues);
			}
		
			top_popup_open = true;
			Click_active();
			
			if (nowClicked_data == null)
			{
				return;
			}		
			
			var now_text = "lbl_" + nowClicked_data.split("_").pop();		
			
			if (checkValues[now_text] != undefined)
			{
				webMI.gfx.setText(now_text, checkValues[now_text])	// now_text 이전값 복원
				webMI.gfx.setFill(now_text, color.Green_Active[color_mode]);	// 텍스트 색상 원래대로
			}
			else
			{
				webMI.gfx.setText(now_text, previousValues[now_text])	// now_text 이전값 복원
				webMI.gfx.setFill(now_text, color.Font_Default[color_mode]);	// 텍스트 색상 원래대로
			}
			
			nowClicked_data = null;
			
			webMI.gfx.setVisible("shadow", true);	// 현재 선택한 텍스트가 없는 경우 키패드 입력 불가		
		}});
	}
});

////////// 경도/위도 값 반환 //////////////
function DmsToDecimal(degrees, minutes, seconds) {
  return degrees + minutes / 60 + seconds / 3600;
}

///////// 경도/위도 도, 분, 초 분리/////////////////
function DecimalToDMS(decimal) {
  const degrees = Math.floor(decimal);
  const minutesFull = (decimal - degrees) * 60;
  const minutes = Math.floor(minutesFull);
  const seconds = ((minutesFull - minutes) * 60).toFixed(0);

  return {
    degrees,
    minutes,
    seconds: parseFloat(seconds)
  };
}

///////////////////////////*  적용 확인 팝업 취소 버튼  *///////////////////////////
webMI.trigger.connect("Apply_Popup_Cancel", function(e)
{
	top_popup_open = false;
	Click_active();
});

////////////// Info 팝업창 닫기///////////////////////////
webMI.trigger.connect("Info_Popup_Close", function(e)
{
	top_popup_open = false;
	Click_active();
});

////////////////////모든 클릭 활성화 비활성화/////////////////////////////////
function Click_active()
{
	if (top_popup_open)
	{
		webMI.trigger.fire("btn_inactive", "ship_close");
		webMI.trigger.fire("btn_inactive", "ship_apply");
	}
	else
	{
		if (apply_active)
		{
			webMI.trigger.fire("btn_active", "ship_apply");
		}
		else
		{
			webMI.trigger.fire("btn_inactive", "ship_apply");
		}			
			
		webMI.trigger.fire("btn_active", "ship_close");		
	}
}