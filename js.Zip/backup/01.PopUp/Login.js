var color = webMI.query["color"];

var keyboard_open = false;
var keyboard_type = "";

var id_data = "";
var pw_data = "";

var info_text_x = 73;
var info_text_y = 142;

var info_btn_x = 73;
var info_btn_y = 259;

var log_out_on = false;

/////////////////색상 변수/////////////////////
var color_Font_Title;
var color_Popup_Border;
var color_Main_Background;
var color_Font_Default;
var color_TextBox_Stroke;
var color_Font_Disable;

///////////로그인 팝업으로 시작////////////
Login_Group_Change();

//////////Login 정보 변경 감지//////////////
webMI.trigger.connect("Login_Change", function(e)
{
	if (e.value != "Level1")
	{
		log_out_on = true;
		webMI.gfx.setFill("lbl_id", color_Font_Disable);
		webMI.gfx.setFill("text_id", color_Font_Disable);
		webMI.gfx.setFill("lbl_pw", color_Font_Disable);
		webMI.gfx.setFill("text_pw", color_Font_Disable);
		webMI.gfx.setText("btn_apply_label_center", "T{로그아웃}");
	}
	else
	{
		log_out_on = false;
		webMI.gfx.setFill("lbl_id", color_Font_Default);
		webMI.gfx.setFill("text_id", color_Font_Default);
		webMI.gfx.setFill("lbl_pw", color_Font_Default);
		webMI.gfx.setFill("text_pw", color_Font_Default);
		webMI.gfx.setText("btn_apply_label_center", "T{로그인}");
	}
});

//////////로그인 팝업창 초기화///////////////////
login_popup_init();

function login_popup_init()
{
	if (localStorage.getItem("UserLevel") != "Level1")
	{
		webMI.gfx.setText("text_id", "");
		webMI.gfx.setText("text_pw", "");
		log_out_on = true;
		webMI.gfx.setFill("lbl_id", color_Font_Disable);
		webMI.gfx.setFill("text_id", color_Font_Disable);
		webMI.gfx.setFill("lbl_pw", color_Font_Disable);
		webMI.gfx.setFill("text_pw", color_Font_Disable);
		webMI.gfx.setText("btn_apply_label_center", "T{로그아웃}");
	}
	else
	{
		webMI.gfx.setText("text_id", "");
		webMI.gfx.setText("text_pw", "");
		log_out_on = false;
		webMI.gfx.setFill("lbl_id", color_Font_Default);
		webMI.gfx.setFill("text_id", color_Font_Default);
		webMI.gfx.setFill("lbl_pw", color_Font_Default);
		webMI.gfx.setFill("text_pw", color_Font_Default);
		webMI.gfx.setText("btn_apply_label_center", "T{로그인}");
	}	
}

webMI.trigger.connect("Login_Popup_init", function(e)
{
	login_popup_init();
});

///////////////////////////*  주/야간 색상 변경 *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	if (color_mode == "Night")
	{
		color_Font_Title = color.Font_Title.Night;
		color_Popup_Border = color.Popup_Border.Night;
		color_Main_Background = color.Main_Background.Night;
		color_Font_Default = color.Font_Default.Night;
		color_TextBox_Stroke  = color.TextBox_Stroke.Night;
		color_Font_Disable = color.Font_Disable.Night;
	}
	else if (color_mode == "Day")
	{
		color_Font_Title = color.Font_Title.Day;
		color_Popup_Border = color.Popup_Border.Day;
		color_Main_Background = color.Main_Background.Day;
		color_Font_Default = color.Font_Default.Day;
		color_TextBox_Stroke  = color.TextBox_Stroke.Day;
		color_Font_Disable = color.Font_Disable.Day;
	}
	
	webMI.gfx.setFill("title_display1", color_Popup_Border);
	webMI.gfx.setFill("title_display2", color_Popup_Border);
	webMI.gfx.setStroke("title_display1",color_Popup_Border);
	webMI.gfx.setStroke("title_display2",color_Popup_Border);
	
	webMI.gfx.setStroke("back_display", color_Popup_Border);
	webMI.gfx.setFill("back_display", color_Main_Background);
	
	webMI.gfx.setStroke("back_display_info", color_Popup_Border);
	webMI.gfx.setFill("back_display_info", color_Main_Background);	
	
	webMI.gfx.setFill("lbl_title", color_Main_Background);
	
	webMI.gfx.setFill("lbl_id", color_Font_Default);
	webMI.gfx.setFill("text_id", color_Font_Default);
	webMI.gfx.setFill("lbl_pw", color_Font_Default);
	webMI.gfx.setFill("text_pw", color_Font_Default);
	
	webMI.gfx.setStroke("line_id", color_TextBox_Stroke);
	webMI.gfx.setStroke("line_pw", color_TextBox_Stroke);
	
	webMI.gfx.setFill("text_info", color_Font_Default);

}

/////////////버튼 클릭 이벤트///////////////////////
webMI.addEvent("btn_close", "click", function(e) {

	if (keyboard_open)
	{
		return;		
	}

	webMI.trigger.fire("Login_Close");
});

webMI.addEvent("btn_apply", "click", function(e) {

	if (keyboard_open)
	{
		return;		
	}
	
	if (log_out_on)
	{
		let previous_level =  localStorage.getItem("UserLevel");
			
		 let temp_level = "Level1";		
		 localStorage.setItem("UserName", "-");
		 localStorage.setItem("UserLevel", temp_level);
		 webMI.trigger.fire("Login_Change",temp_level);
		 webMI.trigger.fire("Event_Add", "Logout : " + previous_level);			/////Default에 정의되어있음
		 webMI.data.write("AGENT.OBJECTS.Control._level", 1);
		 return;
	}

	var para = {};
	para["id"] = id_data;
	para["pw"] = pw_data;
	para["callback"] = Login;

	webMI.trigger.fire("Login_Check", para);
});

//////////////로그인/////////////////////////
function Login(success, level)
{
	////////////로그인 실패에 대한 화면은 "group_login" 그룹 뒤에 있음/////////////
	if (success)
	{
		localStorage.setItem("UserName", id_data);
		localStorage.setItem("UserLevel", level);
		localStorage.setItem("NoTouchCount", 0);
		webMI.trigger.fire("Login_Close");
		webMI.trigger.fire("Login_Change",level);
		webMI.trigger.fire("Event_Add", "Login : " + level);			/////Default에 정의되어있음
		webMI.data.write("AGENT.OBJECTS.Control._level", Number(level.slice(-1)));
	}
	else
	{
		Info_Group_Change();
	}
}

////////////keyboard 종료/////////////////////////
webMI.trigger.connect("Keyboard_Close", function(e)
{
	keyboard_open = false;
	keyboard_type = "";	
	webMI.trigger.fire("Login_Popup_Down");
});
	
////////////keyboard 에서 PW 값 수신/////////////////////////
webMI.trigger.connect("Keyboard_Enter_PW", function(e)
{
	var str = e.value;
	
	pw_data = str;
	
	var pw_star = "";
	
	for (var i = 0; i < pw_data.length; i++)
	{
		pw_star = pw_star + "*";
	}
	
	webMI.trigger.fire("Login_Popup_Down");
	webMI.gfx.setText("text_pw", pw_star);
});

////////////keyboard 에서 ID 값 수신/////////////////////////
webMI.trigger.connect("Keyboard_Enter_ID", function(e)
{
	id_data = e.value;

	webMI.trigger.fire("Login_Popup_Down");
	webMI.gfx.setText("text_id", id_data);
});

////////////ID 클릭 이벤트//////////////////////////
webMI.addEvent("btn_ID", "click", function(e) {
	
	if (keyboard_open || log_out_on)
	{
		return;
	}
	
	keyboard_type = "ID";	
	webMI.trigger.fire("Login_Popup_Up");
	webMI.trigger.fire("Keyboard_Open", { type : keyboard_type});
	keyboard_open = true;
});

////////////pw 클릭 이벤트//////////////////////////
webMI.addEvent("btn_PW", "click", function(e) {
	
	if (keyboard_open || log_out_on)
	{
		return;
	}
	
	keyboard_type = "PW";	
	
	webMI.trigger.fire("Login_Popup_Up");
	webMI.trigger.fire("Keyboard_Open", { type : keyboard_type});
	keyboard_open = true;
});

//////////////login 그룹 보이기///////////////
function login_visible() {
	var login_group = document.getElementById("group_login");		
	
	if (login_group) {
		login_group = login_group.querySelectorAll("*");
		login_group.forEach(control => {
			var last_name = control.id.split("_");
			last_name = last_name[last_name.length - 1];

			if(last_name != "line1" && last_name != "line2")		
			{
				control.style.visibility = "visible";
				control.style.display = "block";
			}	
		});
	}
}

//////////////login 그룹 숨기기///////////////
function login_hidden() {
	var login_group = document.getElementById("group_login");		
	
	if (login_group) {
		login_group = login_group.querySelectorAll("*");
		login_group.forEach(control => {
			control.style.visibility = "hidden";
			control.style.display = "none";
		});
	}
}

//////////////info 그룹 보이기///////////////
function info_visible() {
	var login_group = document.getElementById("group_info");		
	
	if (login_group) {
		login_group = login_group.querySelectorAll("*");
		login_group.forEach(control => {
			var last_name = control.id.split("_");
			last_name = last_name[last_name.length - 1];

			if(last_name != "line1" && last_name != "line2")		
			{
				control.style.visibility = "visible";
				control.style.display = "block";
			}	
		});
	}
}

//////////////info 그룹 숨기기///////////////
function info_hidden() {
	var login_group = document.getElementById("group_info");		
	
	if (login_group) {
		login_group = login_group.querySelectorAll("*");
		login_group.forEach(control => {
			control.style.visibility = "hidden";
			control.style.display = "none";
		});
	}
}

///////////// 정보 창으로 전환
function Info_Group_Change()
{
	login_hidden();
	info_visible();
	webMI.gfx.setText("lbl_title", "T{오류}");
}
	
///////////// 로그인 창으로 전환
function Login_Group_Change()
{
	login_visible();
	info_hidden();
	webMI.gfx.setText("lbl_title", "T{로그인}");
}

////////////확인 클릭 이벤트//////////////////////////
webMI.addEvent("btn_info", "click", function(e) {
	
	Login_Group_Change();
});