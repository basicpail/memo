var color = webMI.query["color"];
var page_max = 0;
var page_num = 1;
var next_btn_active = false;
var pre_btn_active = false;
var keyboard_open = false;
var language_mode = localStorage.getItem("Language_Mode");
const ROW_NUM = 7;
let fillter = "";
let search_true = false;

let search_text = "";

var coilMapping =
{
	1: "V1", 2: "V2", 3: "V3", 4: "V4", 5: "V5",
	6: "V6", 7: "V7", 8: "V8", 9: "A1",  10: "A2",
	11: "A3", 12: "A4", 13: "A5", 14: "L1", 15: "L2",
	16: "L3", 17: "L4", 18: "L5", 19: "L6", 20: "L7",
	21: "L8", 22: "L9", 23: "L10", 24: "L11", 25: "L12"
};

var fillter_btn_name = ["btn_all", "btn_Probe", "btn_Magnetic_Field", "btn_PSU_Current_Coeff", "btn_PSU_Current","btn_Submarine_Info_Data"];

var axis_Mapping =
{
	1: "V", 2: "A", 3: "L"
};

var MF_Mapping =
{
	1: "CMS", 2: "Exposure", 3: "Probe"
};

var MF_KoMapping =
{
	1: "함정 성분 자기장 - 지구 자기장 맵", 2: "함정 노출 자기장", 3: "함정 성분 자기장 - 3축 자기센서 프로브"
};

var typeMapping = { 1: "Permanent", 2: "Induced", 3: "Eddy" };
var typeKoMapping = { 1: "영구 ", 2: "유도 ", 3: "와" };

var data_list = [];
var search_list;
var select_num = -1;

Data_init();

function Data_List_Add(name, addr)
{
	let list = {name : name, addr : addr};
	
	data_list.push(list);
};

///////////////////////////*  주/야간 색상 변경 *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	webMI.gfx.setFill("table_header", color.Table_Title[color_mode]);	
	webMI.gfx.setStroke("table_header", color.Table_Border[color_mode]);	
	
	webMI.gfx.setFill("text", color.Font_Default[color_mode]);
	webMI.gfx.setFill("title_display1", color.Popup_Border[color_mode]);
	webMI.gfx.setFill("title_display2", color.Popup_Border[color_mode]);
	webMI.gfx.setStroke("title_display1",color.Popup_Border[color_mode]);
	webMI.gfx.setStroke("title_display2",color.Popup_Border[color_mode]);
	
	webMI.gfx.setStroke("back_display", color.Popup_Border[color_mode]);
	webMI.gfx.setFill("back_display", color.Main_Background[color_mode]);

	webMI.gfx.setFill("lbl_title", color.Main_Background[color_mode]);

	webMI.gfx.setFill("lbl_page", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl_data_title", color.Font_Title[color_mode]);
	
	webMI.gfx.setFill("text_all_count", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_all_count", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_header", color.Font_Default[color_mode]);
	
	webMI.gfx.setFill("bento_1", color.Bento[color_mode]);
	
	webMI.gfx.setFill("back_search", color.Btn_Background[color_mode]);
	
	let control1 = document.getElementById("img_search");
    control1.href.baseVal = '../../Icon/Search_' + color_mode + '.png';
}

///////////////// 헤더 넘버 셋팅 /////////////////////////
function Header_Num_Set()
{
	for (let row = 0; row < ROW_NUM; row++)
	{
		let temp_num = row + (page_num - 1) * ROW_NUM + 1;	
	
		if (temp_num <= search_list.length)
		{
			webMI.gfx.setText(`row_num_${row}_text_center`, temp_num);
		}
		else
		{
			webMI.gfx.setText(`row_num_${row}_text_center`, "");
		}
	}
}

/////////////확인 클릭 이벤트///////////////////////
webMI.addEvent("btn_Check", "click", function(e) {

	if (select_num == -1 || keyboard_open)
	{
		return;
	}

	let addr_index = search_list[select_num].index;

	webMI.trigger.fire("Channel_Select_Done",{ name : search_list[select_num].name, addr : search_list[select_num].addr });

	webMI.trigger.fire("Channel_Popup_Close");
});

/////////////닫기 클릭 이벤트///////////////////////
webMI.addEvent("btn_Close", "click", function(e) {

	if (keyboard_open)
	{
		return;		
	}

	for (let row = 0; row < ROW_NUM; row++)
	{
		let cell_text_id = `row_${row}_text_center`;
		webMI.gfx.setText(cell_text_id, "");
	}

	webMI.trigger.fire("Channel_Close");
});

//////////////// 해당 함수 호출 시 팝업창 초기화 //////////////////////////////////////
webMI.trigger.connect("Channel_Popup_Init", function(e)
{	
	webMI.trigger.fire("btn_inactive","Channel_Select");	
	select_num = -1;
	next_btn_active = false;
	pre_btn_active = false;
	page_num = 1;
	search_true = false;
	fillter = "all";
		
	Fillter_Set();
	Fillter_Btn_Lamp_Update();
});

//////////////////필터 세팅////////////////////
function Fillter_Set()
{
	if (fillter == "all")
	{
		search_list = data_list
	}
	else
	{
		
		let temp_fillter = fillter == "PSU_Current" ? ".PSU_Current." : "." + fillter;
			
		search_list = data_list.filter(item => item.addr.includes(temp_fillter)); 
	}
	
	if (search_true)
	{
		if (search_text != "")
		{
			search_list = search_list.filter(item => item.name.includes(search_text)); 
		}
	}
	else
	{
		search_text == "";
		webMI.gfx.setText("text", "");
	}

	page_num = 1;
	page_max = Math.floor((search_list.length - 1) / ROW_NUM) + 1;

	page_max = page_max < 1 ? 1 : page_max;	

	List_Upadate(page_num);
	Header_Num_Set();
	Page_Text_Update(page_num, page_max);	
		
	webMI.gfx.setText("lbl_all_count", String(search_list.length).padStart(3, '0'));
}

////////////검색 텍스트 클릭 이벤트(키보드 오픈)//////////////////////////
webMI.addEvent("btn_Search_text", "click", function(e) {
	
	if (keyboard_open)
	{
		return;
	}
	
	keyboard_type = "Channel_search";	
	webMI.trigger.fire("Keyboard_Open", { type : keyboard_type, language : language_mode});
	keyboard_open = true;
	
	fillter_btn_name.forEach(buttonId =>
	{
		webMI.trigger.fire("btn_inactive_click",buttonId);
	});
});

////////////keyboard 에서 필터 값 수신/////////////////////////
webMI.trigger.connect("Keyboard_Enter_Channel_search", function(e)
{
	search_text = e.value;
	keyboard_open = false;
	webMI.gfx.setText("text", search_text);
});

/////////////// 검색 버튼 클릭 //////////////////////////////////////////
webMI.addEvent("btn_Search", "click", function(e) {
	if (keyboard_open || search_text == "")
	{
		return;
	}	

	search_list = search_list.filter(item => item.name.toLowerCase().includes(search_text.toLowerCase())); 
	
	select_num = -1;
	page_num = 1;
	page_max = Math.floor((search_list.length - 1) / ROW_NUM) + 1;

	page_max = page_max < 1 ? 1 : page_max;	
	
	List_Upadate(page_num);
	Page_Text_Update(page_num, page_max);	
	Header_Num_Set();
	
	webMI.gfx.setText("lbl_all_count", String(search_list.length).padStart(3, '0'));
	
	search_true =true;
});

///////////////////////////*  버튼 누를 때 효과  *///////////////////////////
webMI.addEvent("btn_Search", ["mousedown","touchstart"], function(e)
{
	if (keyboard_open || search_text == "")
	{
		return;
	}	
	
	webMI.gfx.setFill("back_search", color.Btn_Background_Down[color_mode]);
});


webMI.addEvent("btn_Search", ["mouseup","touchend"], function(e)
{
	webMI.gfx.setFill("back_search", color.Btn_Background[color_mode]);
});

////////////keyboard 종료/////////////////////////
webMI.trigger.connect("Keyboard_Close", function(e)
{
	keyboard_open = false;
	fillter_btn_name.forEach(buttonId =>
	{
		webMI.trigger.fire("btn_active", buttonId);
	});
});

///////현재 페이지/최대 페이지 갯수 글자 업데이트////////////
function Page_Text_Update(pageNum, pageMax)
{
	webMI.gfx.setText("lbl_page", String(pageNum).padStart(2, '0') + " | " + String(pageMax).padStart(2, '0'));
	Page_btn_Active(pageNum);
}

////////////페이지 이동 버튼 활성화 비활성화 ////////////////////
function Page_btn_Active(pageNum)
{
	if (pageNum >= page_max)
	{
		webMI.trigger.fire("btn_inactive","next_page_of_channel");
		webMI.trigger.fire("btn_inactive","max_next_page_of_channel");
		next_btn_active = false;
	}
	else
	{
		webMI.trigger.fire("btn_active","next_page_of_channel");
		webMI.trigger.fire("btn_active","max_next_page_of_channel");
		next_btn_active = true;
	}
		
	if (pageNum <= 1)
	{
		webMI.trigger.fire("btn_inactive","pre_page_of_channel");
		webMI.trigger.fire("btn_inactive","max_pre_page_of_channel");
		pre_btn_active = false;
	}
	else
	{
		webMI.trigger.fire("btn_active","pre_page_of_channel");
		webMI.trigger.fire("btn_active","max_pre_page_of_channel");
		pre_btn_active = true;
	}
}

/////////// 데이터 리스트 업데이트/////////////////
function List_Upadate(pageNum)
{
	for (let row = 0; row < ROW_NUM; row++)
	{
		let real_index = row + (page_num - 1) * ROW_NUM;		
		let cell_text_id = `row_${row}_text_center`;
		
		if (search_list[real_index] != undefined)
		{
			webMI.gfx.setText(cell_text_id, search_list[real_index].name);
		}
		else
		{
			webMI.gfx.setText(cell_text_id, "");
		}
	}
	
	Text_Color_Update(pageNum);
}

////////////필터 선택//////////////////////////////
Fillter_Select(fillter_btn_name);

function Fillter_Select(buttonIds)
{
	buttonIds.forEach(buttonId =>
	{
		webMI.addEvent(buttonId, "click", function(e)
		{
			if (keyboard_open)
			{
				return;
			}
			
			select_num = -1;
			fillter = buttonId.replace("btn_","");
			search_true = false;
			Fillter_Set();
			Fillter_Btn_Lamp_Update();
			Text_Color_Update(page_num);
		});
	});
}	

function Fillter_Btn_Lamp_Update()
{
	fillter_btn_name.forEach(buttonId =>
	{
		var temp = buttonId.replace("btn_","");
		
		if (temp == fillter)
		{
			webMI.trigger.fire("btn_lamp_on", buttonId);
		}
		else
		{
			webMI.trigger.fire("btn_lamp_off", buttonId);
		}
	});
}
	
/////////// 셀 선택/////////////////
Cell_Click(["row_0", "row_1", "row_2", "row_3", "row_4","row_5", "row_6"]);

function Cell_Click(buttonIds)
{
	buttonIds.forEach(buttonId =>
	{
		webMI.addEvent(buttonId, "click", function(e)
		{
			if (keyboard_open)
			{
				return;
			}		
				
			var now_index = Number(buttonId.slice(-1)) + (page_num - 1) * ROW_NUM;
			
			if (search_list[now_index]== undefined)
			{
				return;
			}	
			
			if (select_num == now_index)
			{
				select_num = -1;
				webMI.trigger.fire("btn_inactive","Channel_Select");
			}		
			else
			{
				select_num = now_index;
				webMI.trigger.fire("btn_active","Channel_Select");
			}
				
			Text_Color_Update(page_num);			
		});
	});
}

//////// 셀 텍스트 색상 결정/////////////////////
function Text_Color_Update(pageNum)
{
	for (let i = 0; i < ROW_NUM; i++)
	{
		let now_index = i + (pageNum - 1) * ROW_NUM;
		
		if (search_list[now_index] != undefined)
		{
			if (select_num == now_index)
			{
				webMI.gfx.setFill("row_" + i+ "_text_center", color.Font_Selected_Data[color_mode]);
			}
			else
			{
				webMI.gfx.setFill("row_" + i+ "_text_center", color.Font_Default[color_mode]);
			}
		}
		else
		{
			webMI.gfx.setFill("row_" + i+ "_text_center", color.Font_Disable[color_mode]);
		}
	}
}

/////////이전페이지////////////////////
webMI.addEvent("btn_pre_page", "click", function(e) {

	if (!pre_btn_active || keyboard_open)
	{
		return;
	}
		
	select_num = -1;
	webMI.trigger.fire("btn_inactive","Channel_Select");
	page_num--;
	
	List_Upadate(page_num);	
	Header_Num_Set();	
	Page_Text_Update(page_num, page_max);	
	
});

///////다음페이지/////////////////////
webMI.addEvent("btn_next_page", "click", function(e) {

	if (!next_btn_active || keyboard_open)
	{
		return;
	}
		
	select_num = -1;
	webMI.trigger.fire("btn_inactive","Channel_Select");
	page_num++;
	
	List_Upadate(page_num);		
	Header_Num_Set();
	Page_Text_Update(page_num, page_max);
});

/////////최대 이전페이지////////////////////
webMI.addEvent("btn_pre_page_max", "click", function(e) {

	if (!pre_btn_active || keyboard_open)
	{
		return;
	}
		
	select_num = -1;
	webMI.trigger.fire("btn_inactive","Channel_Select");
	page_num = 1;
	
	List_Upadate(page_num);	
	Header_Num_Set();	
	Page_Text_Update(page_num, page_max);	
	
});

///////최대 다음페이지/////////////////////
webMI.addEvent("btn_next_page_max", "click", function(e) {

	if (!next_btn_active || keyboard_open)
	{
		return;
	}
		
	select_num = -1;
	webMI.trigger.fire("btn_inactive","Channel_Select");
	page_num = page_max;
	
	List_Upadate(page_num);		
	Header_Num_Set();
	Page_Text_Update(page_num, page_max);
});

function Data_init()
{
	/////////// 제1 프로브//////////////
	Data_List_Add(`T{3축 자기센서 제1 프로브 정렬 영구 Offset V축}`,  "AGENT.OBJECTS.01.Probe1 .Alignment._Permanent_Offset."+ "V" +"_axis");
	Data_List_Add(`T{3축 자기센서 제1 프로브 정렬 유도 계수 V축}`,  "AGENT.OBJECTS.01.Probe1 .Alignment._Induced_Factor."+ "V" +"_axis");
	Data_List_Add(`T{3축 자기센서 제1 프로브 정렬 기울기 V축}`,  "AGENT.OBJECTS.01.Probe1 .Alignment._Tilt_Value."+ "V" +"_axis");
	
	Data_List_Add(`T{3축 자기센서 제1 프로브 정렬 영구 Offset A축}`,  "AGENT.OBJECTS.01.Probe1 .Alignment._Permanent_Offset."+ "A" +"_axis");
	Data_List_Add(`T{3축 자기센서 제1 프로브 정렬 유도 계수 A축}`,  "AGENT.OBJECTS.01.Probe1 .Alignment._Induced_Factor."+ "A" +"_axis");
	Data_List_Add(`T{3축 자기센서 제1 프로브 정렬 기울기 A축}`,  "AGENT.OBJECTS.01.Probe1 .Alignment._Tilt_Value."+ "A" +"_axis");
	
	Data_List_Add(`T{3축 자기센서 제1 프로브 정렬 영구 Offset L축}`,  "AGENT.OBJECTS.01.Probe1 .Alignment._Permanent_Offset."+ "L" +"_axis");
	Data_List_Add(`T{3축 자기센서 제1 프로브 정렬 유도 계수 L축}`,  "AGENT.OBJECTS.01.Probe1 .Alignment._Induced_Factor."+ "L" +"_axis");
	Data_List_Add(`T{3축 자기센서 제1 프로브 정렬 기울기 L축}`,  "AGENT.OBJECTS.01.Probe1 .Alignment._Tilt_Value."+ "L" +"_axis");
	
	Data_List_Add(`T{3축 자기센서 제1 프로브 테스트 트림 내부 V축}`,  "AGENT.OBJECTS.01.Probe1 .TestTrim._Internal."+ "V" +"_axis");
	Data_List_Add(`T{3축 자기센서 제1 프로브 테스트 트림 내부 A축}`,  "AGENT.OBJECTS.01.Probe1 .TestTrim._Internal."+ "A" +"_axis");
	Data_List_Add(`T{3축 자기센서 제1 프로브 테스트 트림 내부 L축}`,  "AGENT.OBJECTS.01.Probe1 .TestTrim._Internal."+ "L" +"_axis");
	
	Data_List_Add(`T{3축 자기센서 제1 프로브 테스트 트림 외부 V축}`,  "AGENT.OBJECTS.01.Probe1 .TestTrim._External."+ "V" +"_axis");
	Data_List_Add(`T{3축 자기센서 제1 프로브 테스트 트림 외부 A축}`,  "AGENT.OBJECTS.01.Probe1 .TestTrim._External."+ "A" +"_axis");
	Data_List_Add(`T{3축 자기센서 제1 프로브 테스트 트림 외부 L축}`,  "AGENT.OBJECTS.01.Probe1 .TestTrim._External."+ "L" +"_axis");
	
	///프로브1 V센서
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 V1축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V1.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 V1축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V1.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 V1축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V1.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 V1축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_V1.Current`);
	
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 V2축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V2.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 V2축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V2.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 V2축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V2.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 V2축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_V2.Current`);
	
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 V3축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V3.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 V3축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V3.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 V3축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V3.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 V3축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_V3.Current`);
	
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 V4축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V4.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 V4축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V4.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 V4축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V4.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 V4축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_V4.Current`);
	
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 V5축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V5.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 V5축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V5.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 V5축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V5.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 V5축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_V5.Current`);
	
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 V6축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V6.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 V6축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V6.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 V6축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V6.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 V6축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_V6.Current`);
	
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 V7축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V7.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 V7축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V7.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 V7축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V7.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 V7축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_V7.Current`);
	
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 V8축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V8.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 V8축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V8.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 V8축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_V8.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 V8축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_V8.Current`);
	
	///프로브1 A센서
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 A1축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_A1.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 A1축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_A1.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 A1축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_A1.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 A1축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_A1.Current`);
	
		Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 A2축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_A2.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 A2축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_A2.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 A2축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_A2.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 A2축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_A2.Current`);
	
		Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 A3축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_A3.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 A3축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_A3.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 A3축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_A3.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 A3축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_A3.Current`);
	
		Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 A4축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_A4.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 A4축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_A4.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 A4축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_A4.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 A4축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_A4.Current`);
	
		Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 A5축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_A5.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 A5축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_A5.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 A5축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_A5.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 A5축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_A5.Current`);	
	
	///프로브1 L센서
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 L1축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L1.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 L1축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L1.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 L1축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L1.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 L1축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_L1.Current`);
	
		Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 L2축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L2.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 L2축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L2.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 L2축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L2.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 L2축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_L2.Current`);
	
		Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 L3축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L3.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 L3축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L3.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 L3축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L3.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 L3축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_L3.Current`);
	
		Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 L4축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L4.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 L4축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L4.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 L4축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L4.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 L4축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_L4.Current`);
	
		Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 L5축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L5.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 L5축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L5.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 L5축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L5.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 L5축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_L5.Current`);
	
		Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 L6축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L6.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 L6축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L6.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 L6축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L6.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 L6축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_L6.Current`);
	
		Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 L7축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L7.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 L7축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L7.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 L7축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L7.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 L7축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_L7.Current`);
	
		Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 L8축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L8.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 L8축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L8.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 L8축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L8.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 L8축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_L8.Current`);
	
		Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 L9축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L9.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 L9축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L9.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 L9축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L9.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 L9축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_L9.Current`);
	
		Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 L10축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L10.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 L10축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L10.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 L10축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L10.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 L10축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_L10.Current`);
	
		Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 L11축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L11.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 L11축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L11.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 L11축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L11.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 L11축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_L11.Current`);
	
		Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 V센서 L12축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L12.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 A센서 L12축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L12.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 L센서 L12축}`, 
	 `AGENT.OBJECTS.01.Probe1.Feedback._Probe_L12.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제1 프로브 피드백 보상인자 전류 L12축}`, 
	`AGENT.OBJECTS.01.Probe1.Feedback._Probe_L12.Current`);
	
	/////////제2 프로브////////////////
	Data_List_Add(`T{3축 자기센서 제2프로브 정렬 영구 Offset V축}`,  "AGENT.OBJECTS.01.Probe2.Alignment._Permanent_Offset."+ "V" +"_axis");
	Data_List_Add(`T{3축 자기센서 제2프로브 정렬 유도 계수 V축}`,  "AGENT.OBJECTS.01.Probe2.Alignment._Induced_Factor."+ "V" +"_axis");
	Data_List_Add(`T{3축 자기센서 제2프로브 정렬 기울기 V축}`,  "AGENT.OBJECTS.01.Probe2.Alignment._Tilt_Value."+ "V" +"_axis");
	
	Data_List_Add(`T{3축 자기센서 제2프로브 정렬 영구 Offset A축}`,  "AGENT.OBJECTS.01.Probe2.Alignment._Permanent_Offset."+ "A" +"_axis");
	Data_List_Add(`T{3축 자기센서 제2프로브 정렬 유도 계수 A축}`,  "AGENT.OBJECTS.01.Probe2.Alignment._Induced_Factor."+ "A" +"_axis");
	Data_List_Add(`T{3축 자기센서 제2 프로브 정렬 기울기 A축}`,  "AGENT.OBJECTS.01.Probe2.Alignment._Tilt_Value."+ "A" +"_axis");
	
	Data_List_Add(`T{3축 자기센서 제2 프로브 정렬 영구 Offset L축}`,  "AGENT.OBJECTS.01.Probe2.Alignment._Permanent_Offset."+ "L" +"_axis");
	Data_List_Add(`T{3축 자기센서 제2 프로브 정렬 유도 계수 L축}`,  "AGENT.OBJECTS.01.Probe2.Alignment._Induced_Factor."+ "L" +"_axis");
	Data_List_Add(`T{3축 자기센서 제2 프로브 정렬 기울기 L축}`,  "AGENT.OBJECTS.01.Probe2.Alignment._Tilt_Value."+ "L" +"_axis");
	
	Data_List_Add(`T{3축 자기센서 제2 프로브 테스트 트림 내부 V축}`,  "AGENT.OBJECTS.01.Probe2.TestTrim._Internal."+ "V" +"_axis");
	Data_List_Add(`T{3축 자기센서 제2 프로브 테스트 트림 내부 A축}`,  "AGENT.OBJECTS.01.Probe2.TestTrim._Internal."+ "A" +"_axis");
	Data_List_Add(`T{3축 자기센서 제2 프로브 테스트 트림 내부 L축}`,  "AGENT.OBJECTS.01.Probe2.TestTrim._Internal."+ "L" +"_axis");
	
	Data_List_Add(`T{3축 자기센서 제2 프로브 테스트 트림 외부 V축}`,  "AGENT.OBJECTS.01.Probe2.TestTrim._External."+ "V" +"_axis");
	Data_List_Add(`T{3축 자기센서 제2 프로브 테스트 트림 외부 A축}`,  "AGENT.OBJECTS.01.Probe2.TestTrim._External."+ "A" +"_axis");
	Data_List_Add(`T{3축 자기센서 제2 프로브 테스트 트림 외부 L축}`,  "AGENT.OBJECTS.01.Probe2.TestTrim._External."+ "L" +"_axis");
	
	///프로브2 V센서
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 V1축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V1.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 V1축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V1.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 V1축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V1.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 V1축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_V1.Current`);
	
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 V2축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V2.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 V2축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V2.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 V2축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V2.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 V2축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_V2.Current`);
	
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 V3축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V3.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 V3축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V3.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 V3축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V3.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 V3축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_V3.Current`);
	
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 V4축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V4.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 V4축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V4.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 V4축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V4.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 V4축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_V4.Current`);
	
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 V5축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V5.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 V5축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V5.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 V5축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V5.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 V5축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_V5.Current`);
	
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 V6축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V6.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 V6축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V6.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 V6축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V6.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 V6축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_V6.Current`);
	
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 V7축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V7.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 V7축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V7.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 V7축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V7.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 V7축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_V7.Current`);
	
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 V8축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V8.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 V8축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V8.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 V8축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_V8.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 V8축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_V8.Current`);
	
	///프로브2 A센서
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 A1축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_A1.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 A1축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_A1.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 A1축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_A1.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 A1축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_A1.Current`);
	
		Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 A2축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_A2.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 A2축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_A2.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 A2축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_A2.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 A2축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_A2.Current`);
	
		Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 A3축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_A3.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 A3축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_A3.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 A3축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_A3.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 A3축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_A3.Current`);
	
		Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 A4축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_A4.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 A4축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_A4.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 A4축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_A4.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 A4축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_A4.Current`);
	
		Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 A5축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_A5.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 A5축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_A5.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 A5축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_A5.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 A5축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_A5.Current`);	
	
	///프로브2 L센서
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 L1축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L1.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 L1축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L1.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 L1축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L1.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 L1축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_L1.Current`);
	
		Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 L2축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L2.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 L2축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L2.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 L2축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L2.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 L2축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_L2.Current`);
	
		Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 L3축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L3.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 L3축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L3.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 L3축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L3.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 L3축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_L3.Current`);
	
		Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 L4축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L4.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 L4축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L4.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 L4축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L4.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 L4축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_L4.Current`);
	
		Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 L5축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L5.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 L5축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L5.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 L5축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L5.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 L5축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_L5.Current`);
	
		Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 L6축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L6.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 L6축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L6.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 L6축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L6.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 L6축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_L6.Current`);
	
		Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 L7축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L7.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 L7축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L7.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 L7축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L7.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 L7축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_L7.Current`);
	
		Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 L8축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L8.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 L8축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L8.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 L8축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L8.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 L8축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_L8.Current`);
	
		Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 L9축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L9.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 L9축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L9.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 L9축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L9.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 L9축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_L9.Current`);
	
		Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 L10축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L10.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 L10축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L10.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 L10축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L10.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 L10축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_L10.Current`);
	
		Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 L11축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L11.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 L11축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L11.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 L11축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L11.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 L11축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_L11.Current`);
	
		Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 V센서 L12축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L12.Compensation_Factor_V`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 A센서 L12축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L12.Compensation_Factor_A`);
	 Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 L센서 L12축}`, 
	 `AGENT.OBJECTS.01.Probe2.Feedback._Probe_L12.Compensation_Factor_L`);
	Data_List_Add(`T{3축 자기센서 제2 프로브 피드백 보상인자 전류 L12축}`, 
	`AGENT.OBJECTS.01.Probe2.Feedback._Probe_L12.Current`);

	///// 코일전원 공급기//////////
	///////////////V축///////////////////////////////
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 V1축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V1.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 V1축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V1.Current_Permanent`);
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 V1축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V1.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 V1축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V1.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 V1축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V1.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 V1축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V1.Current_Eddy`);
	
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 V2축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V2.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 V2축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V2.Current_Permanent`);
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 V2축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V2.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 V2축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V2.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 V2축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V2.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 V2축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V2.Current_Eddy`);
	
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 V3축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V3.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 V3축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V3.Current_Permanent`);
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 V3축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V3.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 V3축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V3.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 V3축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V3.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 V3축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V3.Current_Eddy`);
	
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 V4축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V4.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 V4축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V4.Current_Permanent`);
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 V4축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V4.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 V4축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V4.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 V4축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V4.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 V4축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V4.Current_Eddy`);
	
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 V5축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V5.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 V5축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V5.Current_Permanent`);
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 V5축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V5.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 V5축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V5.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 V5축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V5.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 V5축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V5.Current_Eddy`);
	
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 V6축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V6.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 V6축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V6.Current_Permanent`);
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 V6축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V6.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 V6축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V6.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 V6축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V6.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 V6축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V6.Current_Eddy`);
	
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 V7축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V7.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 V7축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V7.Current_Permanent`);
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 V7축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V7.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 V7축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V7.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 V7축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V7.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 V7축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V7.Current_Eddy`);
	
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 V8축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V8.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 V8축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V8.Current_Permanent`);
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 V8축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V8.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 V8축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V8.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 V8축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.V8.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 V8축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.V8.Current_Eddy`);
	
	///////////////A축///////////////////////////////
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 A1축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.A1.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 A1축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.A1.Current_Permanent`);		
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 A1축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.A1.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 A1축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.A1.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 A1축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.A1.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 A1축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.A1.Current_Eddy`);
	
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 A2축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.A2.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 A2축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.A2.Current_Permanent`);		
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 A2축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.A2.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 A2축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.A2.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 A2축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.A2.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 A2축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.A2.Current_Eddy`);
	
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 A3축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.A3.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 A3축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.A3.Current_Permanent`);		
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 A3축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.A3.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 A3축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.A3.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 A3축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.A3.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 A3축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.A3.Current_Eddy`);
	
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 A4축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.A4.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 A4축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.A4.Current_Permanent`);		
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 A4축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.A4.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 A4축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.A4.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 A4축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.A4.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 A4축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.A4.Current_Eddy`);
	
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 A5축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.A5.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 A5축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.A5.Current_Permanent`);		
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 A5축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.A5.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 A5축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.A5.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 A5축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.A5.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 A5축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.A5.Current_Eddy`);
	
	///////////////L축///////////////////////////////
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 L1축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L1.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 L1축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L1.Current_Permanent`);
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 L1축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L1.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 L1축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L1.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 L1축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L1.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 L1축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L1.Current_Eddy`);
	
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 L2축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L2.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 L2축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L2.Current_Permanent`);
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 L2축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L2.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 L2축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L2.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 L2축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L2.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 L2축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L2.Current_Eddy`);
	
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 L3축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L3.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 L3축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L3.Current_Permanent`);
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 L3축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L3.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 L3축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L3.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 L3축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L3.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 L3축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L3.Current_Eddy`);
	
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 L4축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L4.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 L4축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L4.Current_Permanent`);
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 L4축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L4.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 L4축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L4.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 L4축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L4.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 L4축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L4.Current_Eddy`);		
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 L4축}`, 
	
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L5.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 L5축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L5.Current_Permanent`);
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 L5축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L5.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 L5축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L5.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 L5축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L5.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 L5축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L5.Current_Eddy`);
	
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 L6축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L6.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 L6축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L6.Current_Permanent`);
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 L6축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L6.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 L6축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L6.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 L6축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L6.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 L6축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L6.Current_Eddy`);
	
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 L7축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L7.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 L7축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L7.Current_Permanent`);
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 L7축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L7.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 L7축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L7.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 L7축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L7.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 L7축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L7.Current_Eddy`);
	
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 L8축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L8.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 L8축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L8.Current_Permanent`);
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 L8축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L8.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 L8축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L8.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 L8축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L8.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 L8축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L8.Current_Eddy`);
	
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 L9축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L9.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 L9축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L9.Current_Permanent`);
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 L9축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L9.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 L9축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L9.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 L9축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L9.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 L9축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L9.Current_Eddy`);
	
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 L10축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L10.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 L10축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L10.Current_Permanent`);
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 L10축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L10.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 L10축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L10.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 L10축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L10.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 L10축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L10.Current_Eddy`);
	
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 L11축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L11.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 L11축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L11.Current_Permanent`);
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 L11축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L11.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 L11축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L11.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 L11축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L11.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 L11축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L11.Current_Eddy`);
	
	Data_List_Add(`T{코일 전원공급기 영구 전류 계수 L12축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L12.Current_Coeff_Permanent`);
	Data_List_Add(`T{코일 전원공급기 영구 전류 L12축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L12.Current_Permanent`);
	
	Data_List_Add(`T{코일 전원공급기 유도 전류 계수 L12축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L12.Current_Coeff_Induced`);
	Data_List_Add(`T{코일 전원공급기 유도 전류 L12축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L12.Current_Induced`);
	
	Data_List_Add(`T{코일 전원공급기 와전류 계수 L12축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current_Coeff.L12.Current_Coeff_Eddy`);
	Data_List_Add(`T{코일 전원공급기 와전류 L12축}`, 
	`AGENT.OBJECTS.Analog_Data.PSU_Current.L12.Current_Eddy`);

	///////////자기장///////////////////
	Data_List_Add(`T{함정 성분 자기장 - 지구 자기장 맵 V축}`, 
		`AGENT.OBJECTS.Analog_Data.Magnetic_Field.CMS.V_axis`);
	Data_List_Add(`T{함정 성분 자기장 - 지구 자기장 맵 A축}`, 
		`AGENT.OBJECTS.Analog_Data.Magnetic_Field.CMS.A_axis`);
	Data_List_Add(`T{함정 성분 자기장 - 지구 자기장 맵 L축}`, 
		`AGENT.OBJECTS.Analog_Data.Magnetic_Field.CMS.L_axis`);
	Data_List_Add(`T{함정 성분 자기장 - 지구 자기장 맵 통합}`, 
		`AGENT.OBJECTS.Analog_Data.Magnetic_Field.CMS.Magnitude`);
		
	Data_List_Add(`T{함정 노출 자기장 V축}`, 
		`AGENT.OBJECTS.Analog_Data.Magnetic_Field.Exposure.V_axis`);
	Data_List_Add(`T{함정 노출 자기장 A축}`, 
		`AGENT.OBJECTS.Analog_Data.Magnetic_Field.Exposure.A_axis`);
	Data_List_Add(`T{함정 노출 자기장 L축}`, 
		`AGENT.OBJECTS.Analog_Data.Magnetic_Field.Exposure.L_axis`);
	Data_List_Add(`T{함정 노출 자기장 통합}`, 
		`AGENT.OBJECTS.Analog_Data.Magnetic_Field.Exposure.Magnitude`);
		
	Data_List_Add(`T{함정 성분 자기장 - 3축 자기센서 프로브 V축}`, 
		`AGENT.OBJECTS.Analog_Data.Magnetic_Field.Probe.V_axis`);
	Data_List_Add(`T{함정 성분 자기장 - 3축 자기센서 프로브 A축}`, 
		`AGENT.OBJECTS.Analog_Data.Magnetic_Field.Probe.A_axis`);
	Data_List_Add(`T{함정 성분 자기장 - 3축 자기센서 프로브 L축}`, 
		`AGENT.OBJECTS.Analog_Data.Magnetic_Field.Probe.L_axis`);
	Data_List_Add(`T{함정 성분 자기장 - 3축 자기센서 프로브 통합}`, 
		`AGENT.OBJECTS.Analog_Data.Magnetic_Field.Probe.Magnitude`);

	//////////함정보////////////
	Data_List_Add(`T{함 정보 - 심도}`, `AGENT.OBJECTS.Analog_Data.Submarine_Info_Data._Depth`);
	Data_List_Add(`T{함 정보 - 경도}`, `AGENT.OBJECTS.Analog_Data.Submarine_Info_Data._Longitude`);
	Data_List_Add(`T{함 정보 - 위도}`, `AGENT.OBJECTS.Analog_Data.Submarine_Info_Data._Latitude`);
	Data_List_Add(`T{함 정보 - 횡경사각}`, `AGENT.OBJECTS.Analog_Data.Submarine_Info_Data._Roll`);
	Data_List_Add(`T{함 정보 - 종경사각}`, `AGENT.OBJECTS.Analog_Data.Submarine_Info_Data._Pitch`);
	Data_List_Add(`T{함 정보 - 방위각}`, `AGENT.OBJECTS.Analog_Data.Submarine_Info_Data._Heading`);
	
	data_list.sort((a, b) => a.name.localeCompare(b.name));
}	