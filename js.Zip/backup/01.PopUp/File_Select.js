var color = webMI.query["color"];
var page_max = 0;
var page_num = 0;
var next_btn_active = false;
var pre_btn_active = false;
const ROW_NUM = 7;

var data_list;
var select_num = -1;
var title;
var data_name;

///////////////////////////*  주/야간 색상 변경 *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

webMI.gfx.setText("lbl_header", "");

function Color_Day_Night(color_mode)
{
	webMI.gfx.setFill("table_header", color.Table_Title[color_mode]);	
	webMI.gfx.setStroke("table_header", color.Table_Border[color_mode]);	

	webMI.gfx.setFill("title_display1", color.Popup_Border[color_mode]);
	webMI.gfx.setFill("title_display2", color.Popup_Border[color_mode]);
	webMI.gfx.setStroke("title_display1",color.Popup_Border[color_mode]);
	webMI.gfx.setStroke("title_display2",color.Popup_Border[color_mode]);
	
	webMI.gfx.setStroke("back_display", color.Popup_Border[color_mode]);
	webMI.gfx.setFill("back_display", color.Main_Background[color_mode]);

	webMI.gfx.setFill("lbl_title", color.Main_Background[color_mode]);

	webMI.gfx.setFill("lbl_page", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl_header", color.Font_Default[color_mode]);
}

///////////////// 헤더 넘버 셋팅 /////////////////////////
function Header_Num_Set()
{
	for (let row = 0; row < ROW_NUM; row++)
	{
		let temp_num = row + (page_num - 1) * ROW_NUM + 1;	
	
		if (temp_num <= data_list.length)
		{
			webMI.gfx.setText(`row_num_${row}_text_center`, temp_num);
		}
		else
		{
			webMI.gfx.setText(`row_num_${row}_text_center`, "");
		}
	}
}

/////////////버튼 클릭 이벤트///////////////////////
webMI.addEvent("btn_Check", "click", function(e) {

	let prevention_level = 2;

	if (select_num == -1)
	{
		return;
	}

	webMI.trigger.fire("Prevention_Check", {level : prevention_level, callback : function(access)	
	{
		webMI.gfx.setText("lbl_header", "");
		
		if (access == false)
		{
			webMI.trigger.fire("File_Popup_Close");
			webMI.trigger.fire("Info_Popup_Open", { title : "T{권한}", info : "T{해당 기능에 대한 권한이 없습니다.}" });
		
			return;
		}
		else
		{
			webMI.trigger.fire("File_Select_Done",{"title" : title,"path" : data_list[select_num].path});
			webMI.trigger.fire("File_Popup_Close");
		}
	}});
	
});

/////////////버튼 클릭 이벤트///////////////////////
webMI.addEvent("btn_Close", "click", function(e) {
	webMI.gfx.setText("lbl_header", "");
	webMI.trigger.fire("File_Popup_Close");
});

/////////////선택 옵션에 따라 초기화////////////////////////
webMI.trigger.connect("File_Popup_Init", function(e)
{
	title = e.value.data_title;
	
	data_name = e.value.data_name;
	
	webMI.gfx.setText("lbl_header",title + " T{설정 날짜}");
	
	webMI.trigger.fire("btn_inactive","File_Select");	
	select_num = -1;
	next_btn_active = false;
	pre_btn_active = false;
	
	webMI.data.call("ListDirectory",{"Path" : "DataSetting/" + data_name}, function(content) {							////Library -> Atvise -> webMI Method Scripts -> ListDirectory		/// content.error == -1 이면 오류
			var data_num = content.length;
			
			if ((content.error != undefined && content.error == -1) || data_num == 0)
			{
				webMI.trigger.fire("File_Popup_Close");
				webMI.trigger.fire("Info_Popup_Open", { title : "T{오류}", info : "T{기록된 파일이 없습니다.}" });
				return;
			}			

			page_max = Math.floor((data_num - 1) / ROW_NUM) + 1;					//몫만 구하여 페이지 최대 갯수 구함
			page_max = page_max < 1 ? 1 : page_max;
			page_num = 1;
			
			Page_Text_Update(page_num, page_max);

			data_list = content.map((_, index) => content[content.length - 1 - index]);;
			
			List_Upadate(page_num);
	});

});

///////현재 페이지/최대 페이지 갯수 글자 업데이트////////////
function Page_Text_Update(pageNum, pageMax)
{
	webMI.gfx.setText("lbl_page", String(pageNum).padStart(2, '0') + " | " + String(pageMax).padStart(2, '0'));
	Page_btn_Active(pageNum);
}

////////////페이지 이동 버튼 활성화 비활성화 ////////////////////
function Page_btn_Active(pageNum)
{
	if (pageNum >= page_max)
	{
		webMI.trigger.fire("btn_inactive","next_page_of_file");
		webMI.trigger.fire("btn_inactive","next_max_page_of_file");
		next_btn_active = false;
	}
	else
	{
		webMI.trigger.fire("btn_active","next_page_of_file");
		webMI.trigger.fire("btn_active","next_max_page_of_file");
		next_btn_active = true;
	}
		
	if (pageNum <= 1)
	{
		webMI.trigger.fire("btn_inactive","pre_page_of_file");
		webMI.trigger.fire("btn_inactive","pre_max_page_of_file");
		pre_btn_active = false;
	}
	else
	{
		webMI.trigger.fire("btn_active","pre_page_of_file");
		webMI.trigger.fire("btn_active","pre_max_page_of_file");
		pre_btn_active = true;
	}
}

/////////// 데이터 리스트 업데이트/////////////////
function List_Upadate(pageNum)
{
	var index = (pageNum - 1) * ROW_NUM;
	
	for (let i = 0; i < ROW_NUM; i++)
	{
		let now_index = i + index;		
		
		if (data_list[now_index] != undefined)
		{
			let date_text = Date_from_name(data_list[now_index].name);
			let head_name = data_list[now_index].name.split("_");			
			let tail_name = data_list[now_index].name.split(".");
			
			head_name = head_name[0] + "_" + head_name[1];
			tail_name = tail_name.slice(-1)[0].toLowerCase();			
			
			if (new Date(date_text) == "Invalid Date" || head_name != data_name || tail_name != "csv")
			{
				data_list.splice(now_index, 1);
				page_max = Math.floor((data_list.length - 1) / ROW_NUM) + 1 ;
				page_max = page_max < 1 ? 1 : page_max;
				Page_Text_Update(page_num, page_max);
				i--;
			}
			else
			{
				webMI.gfx.setText("row_" + i+ "_text_center", date_text);
			}
		}
		else
		{
			webMI.gfx.setText("row_" + i+ "_text_center", "");
		}
	}
	
	Text_Color_Update(pageNum);
	Header_Num_Set();
}
	
/////파일 이름에서 날짜만 추출/////////////
function Date_from_name(name)
{
	var temp = name.split('_');

	var temp_date_time = temp[temp.length - 2] + " " + temp[temp.length - 1];

	let year = temp_date_time.slice(0, 4);
    let month = temp_date_time.slice(4, 6);
    let day = temp_date_time.slice(6, 8);
    let hour = temp_date_time.slice(9, 11);
    let minute = temp_date_time.slice(11, 13);
    let second = temp_date_time.slice(13, 15);

    // ISO 형식으로 변환
    return `${year}/${month}/${day} ${hour}:${minute}:${second}`;
}

/////////// 날짜 셀 선택/////////////////
Cell_Click(["row_0", "row_1", "row_2", "row_3", "row_4","row_5", "row_6"]);

function Cell_Click(buttonIds)
{
	buttonIds.forEach(buttonId =>
	{
		webMI.addEvent(buttonId, "click", function(e)
		{
			var now_index = Number(buttonId.slice(-1)) + (page_num - 1) * ROW_NUM;
			
			if (data_list[now_index] == undefined)
			{
				return;
			}	
			
			if (select_num != now_index)
			{
				select_num = now_index;
				webMI.trigger.fire("btn_active","File_Select");
			}
			else
			{
				select_num = -1;
				webMI.trigger.fire("btn_inactive","File_Select");
			}
			
			Text_Color_Update(page_num);
			
		});
	});
}

//////// 셀 텍스트 색상 결정/////////////////////
function Text_Color_Update(pageNum)
{
	for (let i = 0; i < ROW_NUM; i++)
	{
		let now_index = i + (pageNum - 1) * ROW_NUM;
		
		if (data_list[now_index] != undefined)
		{
			if (select_num == now_index)
			{
				webMI.gfx.setFill("row_" + i+ "_text_center", color.Font_Selected_Data[color_mode]);
			}
			else
			{
				webMI.gfx.setFill("row_" + i+ "_text_center", color.Font_Default[color_mode]);
			}
		}
		else
		{
			webMI.gfx.setFill("row_" + i+ "_text_center", color.Font_Disable[color_mode]);
		}
	}
}

/////////이전페이지////////////////////
webMI.addEvent("btn_pre_page", "click", function(e) {
	
	if (!pre_btn_active)
	{
		return;
	}
		
	select_num = -1;
	webMI.trigger.fire("btn_inactive","File_Select");
	page_num--;
	
	List_Upadate(page_num);		
	Page_Text_Update(page_num, page_max);	
	
});

///////다음페이지/////////////////////
webMI.addEvent("btn_next_page", "click", function(e) {

	if (!next_btn_active)
	{
		return;
	}
		
	select_num = -1;
	webMI.trigger.fire("btn_inactive","File_Select");
	page_num++;
	
	List_Upadate(page_num);		
	Page_Text_Update(page_num, page_max);
});

/////////최대 이전페이지////////////////////
webMI.addEvent("btn_pre_page_max", "click", function(e) {
	if (!next_btn_active)
	{
		return;
	}
		
	select_num = -1;
	webMI.trigger.fire("btn_inactive","File_Select");
	page_num = 1;
	
	List_Upadate(page_num);		
	Page_Text_Update(page_num, page_max);
});

///////최대 다음페이지/////////////////////
webMI.addEvent("btn_next_page_max", "click", function(e) {

	if (!next_btn_active)
	{
		return;
	}
		
	select_num = -1;
	webMI.trigger.fire("btn_inactive","File_Select");
	page_num = page_max;
	
	List_Upadate(page_num);		
	Page_Text_Update(page_num, page_max);
});