var color = webMI.query["color"];

///////////////////////////*  주/야간 색상 변경 *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	webMI.gfx.setFill("lbl_title",color.Main_Background[color_mode]);
	
	webMI.gfx.setFill("title_display1",color.Popup_Border[color_mode]);
	webMI.gfx.setFill("title_display2",color.Popup_Border[color_mode]);
	webMI.gfx.setStroke("title_display1", color.Popup_Border[color_mode]);
	webMI.gfx.setStroke("title_display2", color.Popup_Border[color_mode]);
	
	webMI.gfx.setStroke("back_display", color.Popup_Border[color_mode]);
	webMI.gfx.setFill("back_display", color.Main_Background[color_mode]);
	
	webMI.gfx.setFill("rect_sds",color.Bento[color_mode]);
	webMI.gfx.setFill("rect_probe1",color.Bento[color_mode]);
	webMI.gfx.setFill("rect_probe2",color.Bento[color_mode]);
	
	webMI.gfx.setStroke("rect_sds",color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_probe1",color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_probe2",color.Popup_Rect[color_mode]);
	
	webMI.gfx.setFill("lbl_sds",color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_probe1_1",color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_probe1_2",color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_probe2_1",color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_probe2_2",color.Font_Title[color_mode]);
	
	webMI.gfx.setFill("lbl_probe1_net1",color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_probe1_net2",color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_probe2_net1",color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_probe2_net2",color.Font_Title[color_mode]);
}


///////////////////////////*  닫기 버튼 클릭 이벤트  *///////////////////////////

webMI.addEvent("btn_close", "click", function(e)
{
	webMI.trigger.fire("Probe_Popup_Close");
});


///////////////////////////*  소자제어기 - 3축 자기센서 프로브1 Net 1  *///////////////////////////															subscribe or read 확인!!

webMI.data.subscribe("AGENT.OBJECTS.03_ALGOR..Probe1.Net1", function(e)
{
	if (!e.value)
	{
		webMI.gfx.setStroke("line_probe1_net1", color.Line_Com_Normal_Popup[color_mode]);
	}
	else
	{
		webMI.gfx.setStroke("line_probe1_net1", color.Line_Com_Fault[color_mode]);
	}
});


///////////////////////////*  소자제어기 - 3축 자기센서 프로브1 Net 2  *///////////////////////////

webMI.data.subscribe("AGENT.OBJECTS.03_ALGOR..Probe1.Net2", function(e)
{
	if (!e.value)
	{
		webMI.gfx.setStroke("line_probe1_net2", color.Line_Com_Normal_Popup[color_mode]);
	}
	else
	{
		webMI.gfx.setStroke("line_probe1_net2", color.Line_Com_Fault[color_mode]);
	}
});


///////////////////////////*  소자제어기 - 3축 자기센서 프로브2 Net 1  *///////////////////////////

webMI.data.subscribe("AGENT.OBJECTS.03_ALGOR..Probe2.Net1", function(e)
{
	if (!e.value)
	{
		webMI.gfx.setStroke("line_probe2_net1", color.Line_Com_Normal_Popup[color_mode]);
	}
	else
	{
		webMI.gfx.setStroke("line_probe2_net1", color.Line_Com_Fault[color_mode]);
	}
});


///////////////////////////*  소자제어기 - 3축 자기센서 프로브2 Net 2  *///////////////////////////

webMI.data.subscribe("AGENT.OBJECTS.03_ALGOR..Probe2.Net2", function(e)
{
	if (!e.value)
	{
		webMI.gfx.setStroke("line_probe2_net2", color.Line_Com_Normal_Popup[color_mode]);
	}
	else
	{
		webMI.gfx.setStroke("line_probe2_net2", color.Line_Com_Fault[color_mode]);
	}
});