var color = webMI.query["color"];

///////////////////////////*  주/야간 색상 변경  *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	webMI.gfx.setFill("back_display", color.Main_Background[color_mode]);		// 배경색
	webMI.gfx.setStroke("back_display", color.Popup_Stroke[color_mode]);		// 배경 테두리
	webMI.gfx.setFill("title_display1", color.Popup_Stroke[color_mode]);				// 팝업 이름 배경
	webMI.gfx.setFill("title_display2", color.Popup_Stroke[color_mode]);			// 팝업 이름 배경
	webMI.gfx.setStroke("title_display1", color.Popup_Stroke[color_mode]);
	webMI.gfx.setStroke("title_display2", color.Popup_Stroke[color_mode]);
	
	webMI.gfx.setFill("lbl_title", color.Popup_Font_Title[color_mode]);				// 팝업 이름 라벨
	
	webMI.gfx.setStroke("rect_psu_v1", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_v2", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_v3", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_v4", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_v5", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_v6", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_v7", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_v8", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_a1", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_a2", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_a3", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_a4", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_a5", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_l1", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_l2", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_l3", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_l4", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_l5", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_l6", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_l7", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_l8", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_l9", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_l10", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_l11", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_psu_l12", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_net1", color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_net2", color.Popup_Rect[color_mode]);
	
	webMI.gfx.setFill("lbl1_psu_v1", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_v2", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_v3", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_v4", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_v5", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_v6", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_v7", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_v8", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_a1", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_a2", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_a3", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_a4", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_a5", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_l1", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_l2", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_l3", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_l4", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_l5", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_l6", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_l7", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_l8", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_l9", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_l10", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_l11", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl1_psu_l12", color.Font_Default[color_mode]);
	
	webMI.gfx.setFill("lbl2_psu_v1", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_v2", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_v3", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_v4", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_v5", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_v6", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_v7", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_v8", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_a1", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_a2", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_a3", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_a4", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_a5", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_l1", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_l2", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_l3", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_l4", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_l5", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_l6", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_l7", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_l8", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_l9", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_l10", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_l11", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl2_psu_l12", color.Font_Default[color_mode]);
	
	webMI.gfx.setFill("lbl_net1", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl_net2", color.Font_Default[color_mode]);
	
	webMI.gfx.setStroke("line_net1", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setStroke("line_net2", color.Line_Com_Normal_Popup[color_mode]);
	
	webMI.gfx.setFill("rect_v1", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_v2", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_v3", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_v4", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_v5", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_v6", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_v7", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_v8", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_a1", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_a2", color.Line_Com_Normal_Popup[color_mode]);	
	webMI.gfx.setFill("rect_a3", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_a4", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_a5", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_l1", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_l2", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_l3", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_l4", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_l5", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_l6", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_l7", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_l8", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_l9", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_l10", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_l11", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("rect_l12", color.Line_Com_Normal_Popup[color_mode]);
	
	webMI.gfx.setFill("circle_v1", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_v2", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_v3", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_v4", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_v5", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_v6", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_v7", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_v8", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_a1", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_a2", color.Line_Com_Normal_Popup[color_mode]);	
	webMI.gfx.setFill("circle_a3", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_a4", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_a5", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_l1", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_l2", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_l3", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_l4", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_l5", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_l6", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_l7", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_l8", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_l9", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_l10", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_l11", color.Line_Com_Normal_Popup[color_mode]);
	webMI.gfx.setFill("circle_l12", color.Line_Com_Normal_Popup[color_mode]);
}


///////////////////////////*  닫기 버튼 클릭 이벤트  *///////////////////////////

webMI.addEvent("btn_close", "click", function(e)
{
	webMI.trigger.fire("PSU_Popup_Close");
});


///////////////////////////*  V코일 연동 데이터 읽기  *///////////////////////////

for (let v = 1; v <= 8; v++)
{
  for (let n = 1; n <= 2; n++)
  {
    let node = `AGENT.OBJECTS.03_ALGOR..PSU_V${v}_Comm.Net${n}`;
    let lineID = `line_psu_V${v}_net${n}`;

    webMI.data.subscribe(node, function(e)
    {
		  let temp_color = !e.value ? color.Line_Com_Normal_Popup[color_mode] : color.Line_Com_Fault[color_mode]
		  webMI.gfx.setStroke(lineID, temp_color);
    });
  }
}


///////////////////////////*  A코일 연동 데이터 읽기  *///////////////////////////

for (let v = 1; v <= 5; v++)
{
  for (let n = 1; n <= 2; n++)
  {
    let node = `AGENT.OBJECTS.03_ALGOR..PSU_A${v}_Comm.Net${n}`;
    let lineID = `line_psu_A${v}_net${n}`;

    webMI.data.subscribe(node, function(e)
    {
		  let temp_color = !e.value ? color.Line_Com_Normal_Popup[color_mode] : color.Line_Com_Fault[color_mode];
		  webMI.gfx.setStroke(lineID, temp_color);
    });
  }
}


///////////////////////////*  L코일 연동 데이터 읽기  *///////////////////////////

for (let v = 1; v <= 12; v++)
{
  for (let n = 1; n <= 2; n++)
  {
    let node = `AGENT.OBJECTS.03_ALGOR..PSU_L${v}_Comm.Net${n}`;
    let lineID = `line_psu_L${v}_net${n}`;

    webMI.data.subscribe(node, function(e)
    {
		  let temp_color = !e.value ? color.Line_Com_Normal_Popup[color_mode] : color.Line_Com_Fault[color_mode];
		  webMI.gfx.setStroke(lineID, temp_color);
    });
  }
}

function Group_Color_Set(id, temp_color)
{	
	var temp_element = document.getElementById(id);		
	temp_element = temp_element.querySelectorAll("*");
	temp_element.forEach(child => {
		webMI.gfx.setStroke(child.id,temp_color);
		
	});
}