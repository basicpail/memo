var color = webMI.query["color"];

///////////////////////////*  주/야간 색상 변경  *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	webMI.gfx.setFill("back_display", color.Main_Background[color_mode]);		// 배경색
	webMI.gfx.setStroke("back_display", color.Popup_Stroke[color_mode]);		// 배경 테두리
	webMI.gfx.setFill("title_display1", color.Popup_Stroke[color_mode]);				// 팝업 이름 배경
	webMI.gfx.setFill("title_display2", color.Popup_Stroke[color_mode]);			// 팝업 이름 배경
	webMI.gfx.setStroke("title_display1", color.Popup_Stroke[color_mode]);
	webMI.gfx.setStroke("title_display2", color.Popup_Stroke[color_mode]);
	
	webMI.gfx.setFill("lbl_title", color.Popup_Font_Title[color_mode]);				// 팝업 이름 라벨
	
	webMI.gfx.setStroke("rect_mcu1", color.Popup_Rect[color_mode]);				// MCU #1 사각형
	webMI.gfx.setFill("lbl_mcu1", color.Font_Default[color_mode]);					// MCU #1 라벨
	
	webMI.gfx.setStroke("rect_mcu2", color.Popup_Rect[color_mode]);				// MCU #2 사각형
	webMI.gfx.setFill("lbl_mcu2", color.Font_Default[color_mode]);					// MCU #2 라벨
	
	webMI.gfx.setStroke("rect_rcu", color.Popup_Rect[color_mode]);				// RCU 사각형
	webMI.gfx.setFill("lbl_rcu", color.Font_Default[color_mode]);						// RCU 라벨
	
	webMI.gfx.setStroke("rect_dpu_1-1", color.Popup_Rect[color_mode]);			// DPU #1-1 사각형
	webMI.gfx.setFill("lbl_dpu_1-1", color.Font_Default[color_mode]);				// DPU #1-1 라벨
	
	webMI.gfx.setStroke("rect_dpu_1-2", color.Popup_Rect[color_mode]);			// DPU #1-2 사각형
	webMI.gfx.setFill("lbl_dpu_1-2", color.Font_Default[color_mode]);				// DPU #1-2 라벨
	
	webMI.gfx.setStroke("rect_dpu_2-1", color.Popup_Rect[color_mode]);			// DPU #2-1 사각형
	webMI.gfx.setFill("lbl_dpu_2-1", color.Font_Default[color_mode]);				// DPU #2-1 라벨
	
	webMI.gfx.setStroke("rect_dpu_2-2", color.Popup_Rect[color_mode]);			// DPU #2-2 사각형
	webMI.gfx.setFill("lbl_dpu_2-2", color.Font_Default[color_mode]);				// DPU #2-2 라벨
	
	webMI.gfx.setStroke("rect_net1", color.Popup_Rect[color_mode]);				// NET #1 사각형
	webMI.gfx.setFill("lbl_net1", color.Font_Default[color_mode]);						// NET #1 라벨
	webMI.gfx.setFill("line_net1", color.Font_Default[color_mode]);					// NET #1 라인
	
	webMI.gfx.setStroke("rect_net2", color.Popup_Rect[color_mode]);				// NET #2 사각형
	webMI.gfx.setFill("lbl_net2", color.Font_Default[color_mode]);						// NET #2 라벨
	webMI.gfx.setFill("line_net2", color.Font_Default[color_mode]);					// NET #2 라인
	
	webMI.gfx.setFill("rect1", color.Popup_Rect[color_mode]);							// 라인 연결 사각형
	webMI.gfx.setFill("rect2", color.Popup_Rect[color_mode]);
	webMI.gfx.setFill("rect3", color.Popup_Rect[color_mode]);
	webMI.gfx.setFill("rect4", color.Popup_Rect[color_mode]);
	webMI.gfx.setFill("rect5", color.Popup_Rect[color_mode]);
	webMI.gfx.setFill("rect6", color.Popup_Rect[color_mode]);
	webMI.gfx.setFill("rect7", color.Popup_Rect[color_mode]);
	
	webMI.gfx.setFill("circle1", color.Popup_Rect[color_mode]);						// 라인 연결 원
	webMI.gfx.setFill("circle2", color.Popup_Rect[color_mode]);
	webMI.gfx.setFill("circle3", color.Popup_Rect[color_mode]);
	webMI.gfx.setFill("circle4", color.Popup_Rect[color_mode]);
	webMI.gfx.setFill("circle5", color.Popup_Rect[color_mode]);
	webMI.gfx.setFill("circle6", color.Popup_Rect[color_mode]);
	webMI.gfx.setFill("circle7", color.Popup_Rect[color_mode]);
}


///////////////////////////*  닫기 버튼 클릭 이벤트  *///////////////////////////

webMI.addEvent("btn_close", "click", function(e)
{
	webMI.trigger.fire("Inner_Popup_Close");
});


///////////////////////////* RCU - NET #1   *///////////////////////////

webMI.data.subscribe("AGENT.OBJECTS.03_ALGOR..RCU.Net1", function(e)
{
	if (!e.value)
	{
		webMI.gfx.setStroke("line_rcu_net1", color.Line_Com_Normal_Popup[color_mode]);
	}
	else
	{
		webMI.gfx.setStroke("line_rcu_net1", color.Line_Com_Fault[color_mode]);
	}
});

///////////////////////////*  RCU - NET #2  *///////////////////////////

webMI.data.subscribe("AGENT.OBJECTS.03_ALGOR..RCU.Net2", function(e)
{
	if (!e.value)
	{
		webMI.gfx.setStroke("line_rcu_net2", color.Line_Com_Normal_Popup[color_mode]);
	}
	else
	{
		webMI.gfx.setStroke("line_rcu_net2", color.Line_Com_Fault[color_mode]);
	}
});
