var color = webMI.query["color"];

///////////////////////////*  주/야간 색상 변경 *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	webMI.gfx.setFill("lbl_title",color.Main_Background[color_mode]);
	
	webMI.gfx.setFill("title_display1",color.Popup_Border[color_mode]);
	webMI.gfx.setFill("title_display2",color.Popup_Border[color_mode]);
	webMI.gfx.setStroke("title_display1",color.Popup_Border[color_mode]);
	webMI.gfx.setStroke("title_display2",color.Popup_Border[color_mode]);
	
	webMI.gfx.setStroke("back_display", color.Popup_Border[color_mode]);
	webMI.gfx.setFill("back_display", color.Main_Background[color_mode]);
	
	webMI.gfx.setFill("lbl_probe1_net1",color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_probe1_net2",color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_probe2_net1",color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_probe2_net2",color.Font_Title[color_mode]);
	
	webMI.gfx.setFill("rect_sds",color.Bento[color_mode]);
	webMI.gfx.setFill("rect_ipms",color.Bento[color_mode]);
	webMI.gfx.setFill("rect_cms",color.Bento[color_mode]);
	
	webMI.gfx.setStroke("rect_sds",color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_ipms",color.Popup_Rect[color_mode]);
	webMI.gfx.setStroke("rect_cms",color.Popup_Rect[color_mode]);
	
	webMI.gfx.setFill("lbl_sds",color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_ipms",color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_battle",color.Font_Title[color_mode]);
}

///////////////////////////*  닫기 버튼 클릭 이벤트  *///////////////////////////

webMI.addEvent("btn_close", "click", function(e)
{
	webMI.trigger.fire("Ethernet_Popup_Close");
});


///////////////////////////*  소자제어기 - 통합플랫폼관리체계 Net 1  *///////////////////////////															subscribe or read 확인!!

webMI.data.subscribe("AGENT.OBJECTS.03_ALGOR..IPMS.Net1", function(e)
{
	if (!e.value)
	{
		webMI.gfx.setStroke("line_ipms_net1", color.Line_Com_Normal_Popup[color_mode]);
	}
	else
	{
		webMI.gfx.setStroke("line_ipms_net1",color.Line_Com_Fault[color_mode]);
	}
});


///////////////////////////*  소자제어기 - 통합플랫폼관리체계 Net 2  *///////////////////////////

webMI.data.subscribe("AGENT.OBJECTS.03_ALGOR..IPMS.Net2", function(e)
{
	if (!e.value)
	{
		webMI.gfx.setStroke("line_ipms_net2", color.Line_Com_Normal_Popup[color_mode]);
	}
	else
	{
		webMI.gfx.setStroke("line_ipms_net2", color.Line_Com_Fault[color_mode]);
	}
});


///////////////////////////*  소자제어기 - 전투체계 Net 1  *///////////////////////////

webMI.data.subscribe("AGENT.OBJECTS.03_ALGOR..CMS.Net1", function(e)
{
	if (!e.value)
	{
		webMI.gfx.setStroke("line_cms_net1", color.Line_Com_Normal_Popup[color_mode]);
	}
	else
	{
		webMI.gfx.setStroke("line_cms_net1", color.Line_Com_Fault[color_mode]);
	}
});


///////////////////////////*  소자제어기 - 전투체계 Net 2  *///////////////////////////

webMI.data.subscribe("AGENT.OBJECTS.03_ALGOR..CMS.Net2", function(e)
{
	if (!e.value)
	{
		webMI.gfx.setStroke("line_cms_net2", color.Line_Com_Normal_Popup[color_mode]);
	}
	else
	{
		webMI.gfx.setStroke("line_cms_net2", color.Line_Com_Fault[color_mode]);
	}
});