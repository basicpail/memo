var color = webMI.query["color"];

var btn_auto_lamp = document.getElementById("btn_auto_lamp");
var btn_manual_lamp = document.getElementById("btn_manual_lamp");

var time_setting;
var timerId;

let UTC_year;
let UTC_month;
let UTC_date;
let UTC_hour;
let UTC_min;
let UTC_sec;

let LT_year;
let LT_month;
let LT_date;
let LT_hour;
let LT_min;
let LT_sec;

var push_keep_up_time = 150;

// 월별 일수 배열 (1:1월, 2:2월 ... 12:12월)
const daysInMonth = {
    1: 31, 2: 28, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
};

// 윤년 계산
function isLeapYear(year) {
    return (year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0));
}

/////////////권한 확인////////////////////////////////////////
function Prevention_Check(prevention_level, callback)
{
	webMI.trigger.fire("Prevention_Check", {level : prevention_level, callback : function(access)	
	{
		if (access == false)
		{
			webMI.trigger.fire("Info_Popup_Open", { title : "T{권한}", info : "T{해당 기능에 대한 권한이 없습니다.}" });
			return;
		}
		else
		{
			callback();
		}
	}});
}

///////////////////////////*  주/야간 색상 변경  *///////////////////////////

var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	webMI.gfx.setFill("lbl_title",color.Main_Background[color_mode]);
	
	webMI.gfx.setFill("title_display1",color.Popup_Border[color_mode]);
	webMI.gfx.setFill("title_display2",color.Popup_Border[color_mode]);
	webMI.gfx.setStroke("title_display1", color.Popup_Border[color_mode]);
	webMI.gfx.setStroke("title_display2", color.Popup_Border[color_mode]);
	
	webMI.gfx.setStroke("back_display", color.Popup_Border[color_mode]);
	webMI.gfx.setFill("back_display", color.Main_Background[color_mode]);
	
	webMI.gfx.setStroke("line_1", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_2", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_3", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_4", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_5", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_6", color.Under_Line[color_mode]);	
	webMI.gfx.setStroke("line_7", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_8", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_9", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_10", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_11", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_12", color.Under_Line[color_mode]);	
	
	webMI.gfx.setFill("lbl_UTC", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_UTC_year", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_UTC_month", color.Font_Title[color_mode]);	
	webMI.gfx.setFill("lbl_UTC_date", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_UTC_hour", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_UTC_minute", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_UTC_sec", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_LT", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_LT_year", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_LT_month", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_LT_date", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_LT_hour", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_LT_minute", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_LT_sec", color.Font_Title[color_mode]);
	
	webMI.gfx.setFill("UTC_year", color.Font_Default[color_mode]);
	webMI.gfx.setFill("UTC_month", color.Font_Default[color_mode]);
	webMI.gfx.setFill("UTC_date", color.Font_Default[color_mode]);	
	webMI.gfx.setFill("UTC_hour", color.Font_Default[color_mode]);
	webMI.gfx.setFill("UTC_min", color.Font_Default[color_mode]);
	webMI.gfx.setFill("UTC_sec", color.Font_Default[color_mode]);
	webMI.gfx.setFill("LT_year", color.Font_Default[color_mode]);
	webMI.gfx.setFill("LT_month", color.Font_Default[color_mode]);
	webMI.gfx.setFill("LT_date", color.Font_Default[color_mode]);
	webMI.gfx.setFill("LT_hour", color.Font_Default[color_mode]);
	webMI.gfx.setFill("LT_min", color.Font_Default[color_mode]);
	webMI.gfx.setFill("LT_sec", color.Font_Default[color_mode]);

}

///////////////////////////*  현재 팝업창의 시간을 현재 시간으로 업데이트  *///////////////////////////

webMI.trigger.connect("Real_Time_Popup_Settings", function(e)
{
	let d = new Date();
	
	UTC_year = d.getUTCFullYear();
	UTC_month = d.getUTCMonth() + 1;
	UTC_date = d.getUTCDate();
	UTC_hour = d.getUTCHours();
	UTC_min = d.getUTCMinutes();
	UTC_sec = d.getUTCSeconds();
	
	d.setHours(d.getHours() + 9);	
	
	LT_year = d.getUTCFullYear();
	LT_month = d.getUTCMonth() + 1;
	LT_date = d.getUTCDate();
	LT_hour = d.getUTCHours();
	LT_min = d.getUTCMinutes();
	LT_sec = d.getUTCSeconds();
	
	webMI.gfx.setText("UTC_year", UTC_year);
	webMI.gfx.setText("UTC_month", String(UTC_month).padStart(2, '0'));
	webMI.gfx.setText("UTC_date", String(UTC_date).padStart(2, '0'));
	webMI.gfx.setText("UTC_hour", String(UTC_hour).padStart(2, '0'));
	webMI.gfx.setText("UTC_min", String(UTC_min).padStart(2, '0'));
	webMI.gfx.setText("UTC_sec", String(UTC_sec).padStart(2, '0'));
	
	webMI.gfx.setText("LT_year", LT_year);
	webMI.gfx.setText("LT_month", String(LT_month).padStart(2, '0'));
	webMI.gfx.setText("LT_date", String(LT_date).padStart(2, '0'));
	webMI.gfx.setText("LT_hour", String(LT_hour).padStart(2, '0'));
	webMI.gfx.setText("LT_min", String(LT_min).padStart(2, '0'));
	webMI.gfx.setText("LT_sec", String(LT_sec).padStart(2, '0'));
	
});

///////////////////////////*  시간 세팅 읽어오기  *///////////////////////////

webMI.data.read("SYSTEM.GLOBALS.SDS.Time",function(e)
{
	if (e.value == "auto")
	{
		Time_Setting("auto");
	}
	else if (e.value = "manual")
	{
		Time_Setting("manual");
	}
});


///////////////////////////*  자동 버튼 클릭 이벤트  *///////////////////////////

webMI.addEvent("btn_auto", "click", function(e)
{
	let temp_prevention_level = 3;
	
	Prevention_Check(temp_prevention_level, () => {
		Time_Setting("auto");
		webMI.trigger.fire("Event_Add", "Data Change : Time Mode Change - Auto");			/////Default에 정의되어있음
	});
});


///////////////////////////*  수동 버튼 클릭 이벤트  *///////////////////////////

webMI.addEvent("btn_manual", "click", function(e)
{
	let temp_prevention_level = 3;
	
	Prevention_Check(temp_prevention_level, () => {
		Time_Setting("manual");
		webMI.trigger.fire("Event_Add", "Data Change : Time Mode Change - Manual");			/////Default에 정의되어있음
	});
});

function Time_Setting(mode)
{
	if (mode == "auto")
	{
		btn_auto_lamp.setAttribute("fill", color.BtnLamp_On[color_mode]);
		btn_manual_lamp.setAttribute("fill", color.BtnLamp_Off[color_mode]);

		webMI.trigger.fire("btn_inactive", "time");
		webMI.trigger.fire("btn_inactive", "apply");
		time_setting = "auto";
		webMI.data.write("SYSTEM.GLOBALS.SDS.Time", time_setting);
	}
	else if (mode == "manual")
	{
		btn_auto_lamp.setAttribute("fill", color.BtnLamp_Off[color_mode]);
		btn_manual_lamp.setAttribute("fill", color.BtnLamp_On[color_mode]);
		
		webMI.trigger.fire("btn_active", "time");
		webMI.trigger.fire("btn_active", "apply");
		time_setting = "manual";
		webMI.data.write("SYSTEM.GLOBALS.SDS.Time", time_setting);
	}
}

///////////////////////////*  LT UP/DOWN 버튼 클릭 이벤트  *///////////////////////////

function Date_Update_from_Max()
{
	if (isLeapYear(UTC_year) == true)
	{
		if (Number(UTC_month) == 2)
		{
			if (Number(UTC_date) > 29)
			{
				UTC_date = 29;
				webMI.gfx.setText("UTC_date", String(UTC_date).padStart(2, '0'));
			}
		}
		else
		{
			if (daysInMonth[Number(UTC_month)] < Number(UTC_date))
			{
				UTC_date = daysInMonth[Number(UTC_month)];
				webMI.gfx.setText("UTC_date", String(UTC_date).padStart(2, '0'));
			}
		}
	}
	else
	{
			if (daysInMonth[Number(UTC_month)] < Number(UTC_date))
			{
				UTC_date = daysInMonth[Number(UTC_month)];
				webMI.gfx.setText("UTC_date", String(UTC_date).padStart(2, '0'));
			}
	}
}

//////////////UTC에서 바꾼 시간을 LT에 적용
function LT_lbl_Update()
{
	let ltDate = new Date(UTC_year, UTC_month - 1, UTC_date, UTC_hour, UTC_min, UTC_sec);
	
	ltDate.setHours(ltDate.getHours() + 9);
	
	LT_year = ltDate.getUTCFullYear();
	LT_month = ltDate.getUTCMonth() + 1;
	LT_date = ltDate.getUTCDate();
	LT_hour = ltDate.getUTCHours();
	LT_min = ltDate.getUTCMinutes();
	LT_sec = ltDate.getUTCSeconds();	
	
	webMI.gfx.setText("LT_year", String(LT_year).padStart(2, '0'));
	webMI.gfx.setText("LT_month",String(LT_month).padStart(2, '0'));
	webMI.gfx.setText("LT_date", String(LT_date).padStart(2, '0'));
	webMI.gfx.setText("LT_hour", String(LT_hour).padStart(2, '0'));
	webMI.gfx.setText("LT_min", String(LT_min).padStart(2, '0'));
	webMI.gfx.setText("LT_sec", String(LT_sec).padStart(2, '0'));
	
}

function Data_Event(buttonId)
{
	///////////////////////////*  년  *///////////////////////////
		
	if (buttonId == "btn_DOWN_UTC_year")
	{
		UTC_year = Number(UTC_year) - 1;
		
		if(UTC_year < 2000)
		{
			UTC_year = 2000;
		}		
		
		webMI.gfx.setText("UTC_year", UTC_year);
		Date_Update_from_Max();
			
	} 
	else if (buttonId == "btn_UP_UTC_year")
	{
		UTC_year = Number(UTC_year) + 1;
		webMI.gfx.setText("UTC_year", UTC_year);
		Date_Update_from_Max();
	}
	
	///////////////////////////*  월  *///////////////////////////
	
	else if (buttonId == "btn_DOWN_UTC_month")
	{
		if (UTC_month <= 1)
		{
			UTC_month = 12;
		}
		else
		{
			UTC_month = Number(UTC_month) - 1;
		}
		Date_Update_from_Max();
		webMI.gfx.setText("UTC_month", String(UTC_month).padStart(2, '0'));
	} 
	else if (buttonId == "btn_UP_UTC_month")
	{
		if (UTC_month >= 12)
		{
			UTC_month = 1;
		}
		else
		{
			UTC_month = Number(UTC_month) + 1;
		}
		Date_Update_from_Max();
		webMI.gfx.setText("UTC_month", String(UTC_month).padStart(2, '0'));
	}

	///////////////////////////*  일  *///////////////////////////
	
	else if (buttonId == "btn_DOWN_UTC_date")
	{
		if (UTC_date <= 1)
		{
			let maxDays = daysInMonth[UTC_month];
			
			if (UTC_month === 2 && isLeapYear(UTC_year))
			{
				maxDays = 29;  // 윤년 2월
			}
			
			UTC_date = maxDays;
		}
		else
		{
			UTC_date = Number(UTC_date) - 1;
		}
		webMI.gfx.setText("UTC_date", String(UTC_date).padStart(2, '0'));
	} 
	else if (buttonId == "btn_UP_UTC_date")
	{
		if (UTC_month === 2)
		{	
			if (isLeapYear(UTC_year) && (UTC_date >= 29))
			{
				UTC_date = 1;
			}
			else if (isLeapYear(UTC_year) == false && (UTC_date >= 28))
			{
				UTC_date = 1;
			}
			else
			{
				UTC_date =  Number(UTC_date) + 1;
			}
		}
		else if (UTC_date >= daysInMonth[UTC_month])
		{
			UTC_date = 1;
		}
		else
		{
			UTC_date =  Number(UTC_date) + 1;
		}
		
		webMI.gfx.setText("UTC_date", String(UTC_date).padStart(2, '0'));
	}
	
	///////////////////////////*  시  *///////////////////////////
	
	else if (buttonId == "btn_DOWN_UTC_hour")
	{
		if (UTC_hour <= 0)
		{
			UTC_hour = 23;
		}
		else
		{
			UTC_hour = Number(UTC_hour) - 1;
		}
		webMI.gfx.setText("UTC_hour", String(UTC_hour).padStart(2, '0'));
	} 
	else if (buttonId == "btn_UP_UTC_hour")
	{
		if (UTC_hour >= 23)
		{
			UTC_hour = 0;
		}
		else
		{
			UTC_hour = Number(UTC_hour) + 1;
		}
		webMI.gfx.setText("UTC_hour", String(UTC_hour).padStart(2, '0'));
	} 
	
	///////////////////////////*  분  *///////////////////////////
	
	else if (buttonId == "btn_DOWN_UTC_min")
	{
		if (UTC_min <= 0)
		{
			UTC_min = 59;
		}
		else
		{
			UTC_min = Number(UTC_min) - 1;
		}
		webMI.gfx.setText("UTC_min", String(UTC_min).padStart(2, '0'));
	} 
	else if (buttonId == "btn_UP_UTC_min")
	{
		if (UTC_min >= 59)
		{
			UTC_min = 0;
		}
		else
		{
			UTC_min = Number(UTC_min) + 1;
		}
		webMI.gfx.setText("UTC_min", String(UTC_min).padStart(2, '0'));
	}
	
	///////////////////////////*  초  *///////////////////////////
	
	else if (buttonId == "btn_DOWN_UTC_sec")
	{
		if (UTC_sec <= 0)
		{
			UTC_sec = 59;
		}
		else
		{
			UTC_sec = Number(UTC_sec) - 1;
		}
		webMI.gfx.setText("UTC_sec", String(UTC_sec).padStart(2, '0'));
	} 
	else if (buttonId == "btn_UP_UTC_sec")
	{
		if (UTC_sec >= 59)
		{
			UTC_sec = 0;
		}
		else
		{
			UTC_sec = Number(UTC_sec) + 1;
		}
		webMI.gfx.setText("UTC_sec", String(UTC_sec).padStart(2, '0'));
	}
	
	LT_lbl_Update();
	
	timerId = setTimeout(function() 
	{
		timerId  = null;
		Data_Event(buttonId);
	}, push_keep_up_time);	
}

function UTC_Btn_Click_Event(buttonIds)
{
	buttonIds.forEach(buttonId =>
	{
		webMI.addEvent(buttonId,  ["touchstart"] , function(e)				//"mousedown"
		{
			if (time_setting == "auto")
			{
				return;
			}
					
			if (timerId  == null)
			{
				Data_Event(buttonId);
			}		
		});
	});
	
	buttonIds.forEach(buttonId =>
	{
		webMI.addEvent(buttonId,  ["mouseup","mouseout","touchend","touchcancel"] , function(e)
		{					
				if (timerId  != null)
				{
					clearTimeout(timerId);
					timerId  = null;
				}
		});
	});
}

UTC_Btn_Click_Event(["btn_DOWN_UTC_year", "btn_UP_UTC_year", 
								"btn_DOWN_UTC_month", "btn_UP_UTC_month", 
								"btn_DOWN_UTC_date", "btn_UP_UTC_date", 
								"btn_DOWN_UTC_hour", "btn_UP_UTC_hour", 
								"btn_DOWN_UTC_min", "btn_UP_UTC_min",
								 "btn_UP_UTC_sec", "btn_DOWN_UTC_sec" ]);
							
//////////////적용 버튼///////////////
webMI.addEvent("btn_apply", "click", function(e) {
	let temp_prevention_level = 3;
	
	Prevention_Check(temp_prevention_level, () => {
		webMI.trigger.fire("Cloese_Time_Popup");
		webMI.trigger.fire("Event_Add", "Data Change : Time Change");			/////Default에 정의되어있음
	});
});

///////////////////////////*  팝업 닫기 *///////////////////////////

webMI.addEvent("btn_close", "click", function(e)
{
	webMI.trigger.fire("Cloese_Time_Popup");
});
