var once_Capital_shift = false;
var cpas_lock = false;
var password_on = false;
var currentText = "";
var parameter = "";
var language = "en";
var timerId = null;
var max_len = 21;
var color = webMI.query["color"];

////// 색상 변수////////////////////
var color_Btn_Background_Down;
var color_Table_Cell_Background_Control;
var color_Font_Default;
var color_Popup_Border;
var color_Main_Background;
var color_Under_Line;
var color_Bento;
var color_Btn_Background;

// 초성 테이블 (19개)
const CHOSEONG = [
    'ㄱ', 'ㄲ', 'ㄴ', 'ㄷ', 'ㄸ', 'ㄹ', 'ㅁ', 'ㅂ', 'ㅃ', 'ㅅ', 'ㅆ', 'ㅇ', 'ㅈ', 'ㅉ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ'
];

// 중성 테이블 (21개)
const JUNGSEONG = [
    'ㅏ', 'ㅐ', 'ㅑ', 'ㅒ', 'ㅓ', 'ㅔ', 'ㅕ', 'ㅖ', 'ㅗ', 'ㅘ', 'ㅙ', 'ㅚ', 'ㅛ', 'ㅜ', 'ㅝ', 'ㅞ', 'ㅟ', 'ㅠ', 'ㅡ', 'ㅢ', 'ㅣ'
];

const DOUBLE_JUNGSEONG = {
	'ㅗㅏ': 'ㅘ',
	'ㅗㅐ': 'ㅙ',
	'ㅗㅣ': 'ㅚ',
	'ㅜㅓ': 'ㅝ',
	'ㅜㅔ': 'ㅞ',
	'ㅜㅣ': 'ㅟ',
	'ㅡㅣ': 'ㅢ'
};

// 종성 테이블 (28개, 없음 포함)
const JONGSEONG = [
    '', 'ㄱ', 'ㄲ', 'ㄳ', 'ㄴ', 'ㄵ', 'ㄶ', 'ㄷ', 'ㄹ', 'ㄺ', 'ㄻ', 'ㄼ', 'ㄽ', 'ㄾ', 'ㄿ', 'ㅀ', 'ㅁ', 'ㅂ', 'ㅄ', 'ㅅ', 'ㅆ', 'ㅇ', 'ㅈ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ'
];

const DOUBLE_JONGSEONG = {
    'ㄱㅅ': 'ㄳ',
    'ㄴㅈ': 'ㄵ',
    'ㄴㅎ': 'ㄶ',
    'ㄹㄱ': 'ㄺ',
    'ㄹㅁ': 'ㄻ',
    'ㄹㅂ': 'ㄼ',
    'ㄹㅅ': 'ㄽ',
    'ㄹㅌ': 'ㄾ',
    'ㄹㅍ': 'ㄿ',
    'ㄹㅎ': 'ㅀ',
    'ㅂㅅ': 'ㅄ'
};

var cho = null;  // 초성 (자음)
var jung = null; // 중성 (모음)
var jong = null; // 종성 (받침)

document.getElementById("text").style.whiteSpace = "pre";

///////////////////////////*  주/야간 색상 변경 *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	color_Btn_Background_Down = color.Btn_Background_Down[color_mode];
	color_Table_Cell_Background_Control = color.Table_Cell_Background_Control[color_mode];
	color_Font_Default = color.Font_Default[color_mode];
	color_Btn_Background = color.Btn_Background[color_mode];
	color_Popup_Border = color.Popup_Border[color_mode];
	color_Under_Line = color.Under_Line[color_mode];
	color_Bento = color.Bento[color_mode];
	color_Main_Background = color.Main_Background[color_mode];
	webMI.trigger.fire("kepad_color_change", color_mode);	
	
	webMI.gfx.setFill("title_display1", color_Popup_Border);
	webMI.gfx.setFill("title_display2", color_Popup_Border);
	webMI.gfx.setStroke("title_display1",color_Popup_Border);
	webMI.gfx.setStroke("title_display2",color_Popup_Border);
	
	webMI.gfx.setStroke("back_display", color_Popup_Border);
	webMI.gfx.setFill("back_display", color_Main_Background);
	
	webMI.gfx.setFill("lbl_title", color_Main_Background);
	webMI.gfx.setStroke("line_1", color_Under_Line);
	
	webMI.gfx.setFill("text", color_Font_Default);
	webMI.gfx.setFill("back_pad", color_Bento);
	
	webMI.gfx.setFill("btn_enter_back", color_Btn_Background);
	
	webMI.gfx.setFill("text_enter", color_Font_Default);
}


/////////////////////키보드 초기화///////////////////////////////
webMI.trigger.connect("keyboard_init", function(e)
{
	currentText = "";
	parameter = e.value.parameter;
	max_len = e.value.max_len;
	password_on = e.value.password_on;
	once_Capital_shift = false;
	cpas_lock = false;
	
	webMI.gfx.setFill("btn_mask_label_center",color_Font_Default);	
	
	if (password_on)
	{
		webMI.gfx.setText("btn_mask_label_center", "T{텍스트 보이기}");		
	}	
	else
	{
		webMI.gfx.setText("btn_mask_label_center", "T{텍스트 숨기기}");
	}

	if (e.value.language != undefined)
	{
		language = e.value.language;	
	}
	else
	{
		language = "en";	
	}
	
	webMI.trigger.fire("Keyboard_en_ko_Change", language);
	webMI.trigger.fire("Keyboard_Capital_Small_Change", "Small");
	displayCurrentText();
});

/////////////글자 전시 변경//////////////////////
function displayCurrentText()
{
	if (password_on == false)
	{
		webMI.gfx.setText("text", currentText);
	}
	else
	{
		var text_star = "";
		var max = currentText.length;
		
		if (max > 40)
		{
			max = 40;
		}		
		
		for (var i = 0; i < max; i++ )
		{
			text_star += "*";
		}
		webMI.gfx.setText("text", text_star);
	}
}

///////////////////백스페이스////////////////////////////////////

webMI.addEvent("btn_back", "click", function(e) {
	webMI.trigger.fire("Keyboard_Btn_Click", "BackSpace");
});

/////////////////엔터///////////////////////////////////////////

webMI.addEvent(["btn_enter_click1", "btn_enter_click2"], "click", function(e) {
	webMI.trigger.fire("Keyboard_Enter_"+ parameter, currentText);
	webMI.trigger.fire("Keyboard_Close");
});

////////////////////쉬프트////////////////////////////////
webMI.addEvent("btn_shift_left", "click", function(e) {
if (cpas_lock == false)
{
	if (once_Capital_shift == true)
	{
		webMI.trigger.fire("Keyboard_Capital_Small_Change", "Small");
		once_Capital_shift = false;
	}
	else
	{
		webMI.trigger.fire("Keyboard_Capital_Small_Change", "Capital");
		once_Capital_shift = true;
	}
}
});

//////////////////Cpas Lock /////////////////////////////////////
webMI.addEvent("btn_cpas", "click", function(e) {
if (cpas_lock == true)
{
	webMI.trigger.fire("Keyboard_Capital_Small_Change", "Small");
	cpas_lock = false;
	if (once_Capital_shift == true)
	{
		once_Capital_shift = false;
	}
}
else
{
	webMI.trigger.fire("Keyboard_Capital_Small_Change", "Capital");
	cpas_lock = true;
	
	if (once_Capital_shift == true)
	{
		once_Capital_shift = false;
	}
}

});

/////////////////종료///////////////////////////////////////////
webMI.addEvent("btn_close", "click", function(e) {
	webMI.trigger.fire("Keyboard_Close");
});

/////////////////스페이스 바///////////////////////////////////////////

webMI.addEvent("btn_spacebar", "click", function(e) {
webMI.trigger.fire("Keyboard_Btn_Click", " ");
});

/////////////////텍스트 숨김버튼///////////////////////////////////////////

webMI.addEvent("btn_mask", "click", function(e) {
	if (password_on == false)
	{
		password_on = true;
		webMI.gfx.setText("btn_mask_label_center", "T{텍스트 보이기}");
	}
	else
	{
		password_on = false;
		webMI.gfx.setText("btn_mask_label_center", "T{텍스트 숨기기}");
	}
	
	displayCurrentText();
});

/////////////////텍스트 초기화///////////////////////////////////////////

webMI.addEvent("btn_init", "click", function(e) {
	currentText = "";
	cho = null;
	jung = null;
	jong = null;
	displayCurrentText();
});

/////////////////버튼 클릭 효과//////////////////////////////////////////

webMI.addEvent("btn_back", "mousedown", function(e) { webMI.gfx.setFill("btn_backspace_back", color_Btn_Background_Down);});


webMI.addEvent("btn_back", ["mouseup","mouseout"], function(e) {webMI.gfx.setFill("btn_backspace_back", color_Btn_Background);});

webMI.addEvent(["btn_enter_click1", "btn_enter_click2"], ["mousedown","touchstart"], function(e) {webMI.gfx.setFill("btn_enter_back", color_Btn_Background_Down);});


webMI.addEvent(["btn_enter_click1", "btn_enter_click2"],["mouseup","mouseout", "touchend"], function(e) {webMI.gfx.setFill("btn_enter_back", color_Btn_Background);});

////////////////텍스트 입력 ////////////////////////////////////////////////

webMI.trigger.connect("Keyboard_Btn_Click", function(e) {
	var key = e.value;
	var Consonant = (CHOSEONG.indexOf(key) != -1) ? true : false;
    var Vowel = (JUNGSEONG.indexOf(key) != -1) ? true : false;
    
	if (timerId != null)
	{
		clearTimeout(timerId);
		timerId = null;
	}    
    
	if (Consonant == true)	//자음 입력일 때
	{
		if (cho == null)			///현재 입력된 초성이 없을 때
		{
			currentText  += key;
			cho = key;
		}
		else
		{
			if (jung == null)		//현재 초성은 입력되어있고 종성입력이 없을 때 다음 초성으로 넘어감
			{
				currentText  += key;
				cho = key;
				jung = null;
				jong = null;
			}
			else							//현재 초성과 중성이 입력되어있고 받침 입력 일 때
			{
				if (jong == null)	//현재 초성과 중성이 입력되어있고 받침이 입력이 된것이 없을 때
				{
					jong = key;
					var choIndex = CHOSEONG.indexOf(cho);
					var jungIndex = JUNGSEONG.indexOf(jung);
					var jongIndex = JONGSEONG.indexOf(jong);
					var hangulCode = 0xAC00 + (choIndex * 588) + (jungIndex * 28) + jongIndex;
					currentText = currentText.substr(0, currentText.length-1);
					currentText  += String.fromCharCode(hangulCode);
				}
				else	//현재 초성과 중성이 입력되어있고 받침이 입력이 된것이 있을 때
				{
					var temp_jong = DOUBLE_JONGSEONG[jong + key];
					var jongIndex = JONGSEONG.indexOf(temp_jong);
					if (jongIndex != -1) //현재 초성과 중성이 입력되어있고 받침이 입력이 되어 있던 것이 이번입력과 조합하여 이중 받침이 가능 할 때
					{
						var choIndex = CHOSEONG.indexOf(cho);
						var jungIndex = JUNGSEONG.indexOf(jung);
						jong = jong + key;
						var hangulCode = 0xAC00 + (choIndex * 588) + (jungIndex * 28) + jongIndex;
						currentText = currentText.substr(0, currentText.length-1);
						currentText  += String.fromCharCode(hangulCode);
					}
					else	//현재 초성과 중성이 입력되어있고 받침이 입력이 되어 있던 것이 이번입력과 조합하여 이중 받침이 불가능 할때 글자 추가
					{
						cho = key;
						jung = null;
						jong = null;
						currentText  += key;
					}
				}
			}
		}
	}
	else if (Vowel == true)	//모음 입력일 때
	{
		if (cho == null)			///현재 입력된 초성이 없을 때
		{
			currentText  += key;
			cho = null;
			jung = null;
			jong = null;
		}
		else	///현재 입력된 초성이 있을 때
		{
			if (jung == null)		//현재 초성은 입력되어있고 종성입력이 없을 때 글자 조합
			{
				jung = key;
				jong = null;
				var choIndex = CHOSEONG.indexOf(cho);
				var jungIndex = JUNGSEONG.indexOf(jung);
				var hangulCode = 0xAC00 + (choIndex * 588) + (jungIndex * 28);
				currentText = currentText.substr(0, currentText.length - 1);
				currentText  += String.fromCharCode(hangulCode);
			}
			else	//현재 초성과 종성이 입력되어 있을 때
			{
				if (jong == null)	//현재 초성과 종성이 입력되어 있는데 받침이 없으면 모음만 추가
				{
					if (jung != null && jong == null) 
					{
						var double_jung = DOUBLE_JUNGSEONG[jung + key];
						if (double_jung !== undefined) {
							// 이중 모음으로 결합 가능
							jung = double_jung;
							var choIndex = CHOSEONG.indexOf(cho);
							var jungIndex = JUNGSEONG.indexOf(jung);
							var hangulCode = 0xAC00 + (choIndex * 588) + (jungIndex * 28);
							currentText = currentText.substr(0, currentText.length - 1);
							currentText += String.fromCharCode(hangulCode);
						} else {
							// 결합 불가능: 기존 처리대로 다음 글자로 처리
							currentText += key;
							cho = null;
							jung = null;
							jong = null;
						}
					}
				}
				else	//현재 초성과 종성이 입력되어 있는데 받침이 있으면 받침을 초성으로 사용하여 다음 글자로 넘어감
				{
					if (jong.length == 1)	//이중 받침이 아닐 때
					{
						var choIndex = CHOSEONG.indexOf(cho);
						var jungIndex = JUNGSEONG.indexOf(jung);
						var hangulCode = 0xAC00 + (choIndex * 588) + (jungIndex * 28);
						currentText = currentText.substr(0, currentText.length -1);
						currentText  += String.fromCharCode(hangulCode);
						
						cho = jong;
						jung = key;
						jong = null;
						
						choIndex = CHOSEONG.indexOf(cho);
						jungIndex = JUNGSEONG.indexOf(jung);
						hangulCode = 0xAC00 + (choIndex * 588) + (jungIndex * 28);
						currentText  += String.fromCharCode(hangulCode);
					}
					else if (jong.length == 2)	//이중 받침일 때
					{
						var temp_cho = jong.substr(1, 1);
						jong =  jong.substr(0, 1);
						
						var choIndex = CHOSEONG.indexOf(cho);
						var jungIndex = JUNGSEONG.indexOf(jung);
						var jongIndex = JONGSEONG.indexOf(jong);
						var hangulCode = 0xAC00 + (choIndex * 588) + (jungIndex * 28) + jongIndex;
						currentText = currentText.substr(0, currentText.length-1);
						currentText  += String.fromCharCode(hangulCode);
						
						cho = temp_cho;
						jung = key;
						jong = null;
						
						choIndex = CHOSEONG.indexOf(cho);
						jungIndex = JUNGSEONG.indexOf(jung);
						jongIndex = JONGSEONG.indexOf(jong);
						hangulCode = 0xAC00 + (choIndex * 588) + (jungIndex * 28) + jongIndex;
						currentText  += String.fromCharCode(hangulCode);
					}
				}
			}
		}
	}
	else if (key == "BackSpace") //백스페이스
	{
		if (jong != null)
		{
			if (jong.length == 1)
			{
				var choIndex = CHOSEONG.indexOf(cho);
				var jungIndex = JUNGSEONG.indexOf(jung);
				jong = null;
				
				var hangulCode = 0xAC00 + (choIndex * 588) + (jungIndex * 28);
				currentText = currentText.substr(0, currentText.length-1);
				currentText  += String.fromCharCode(hangulCode);
			}
			else if (jong.length == 2)
			{
				jong =  jong.substr(0, 1);
				
				var choIndex = CHOSEONG.indexOf(cho);
				var jungIndex = JUNGSEONG.indexOf(jung);
				var jongIndex = JONGSEONG.indexOf(jong);
				var hangulCode = 0xAC00 + (choIndex * 588) + (jungIndex * 28) + jongIndex;
				currentText = currentText.substr(0, currentText.length-1);
				currentText  += String.fromCharCode(hangulCode);
			}
		}
		else if (jung != null)
		{	
			jung = null;
			jong = null;
			currentText = currentText.substr(0, currentText.length-1);
			currentText  += cho;
		}
		else if (cho != null)
		{
			currentText = currentText.substr(0, currentText.length-1);
			cho = null;
			jung = null;
			jong = null;
		}
		else
		{
			if (currentText.length > 0)
			{
				currentText = currentText.substr(0, currentText.length-1);
			}
		}
	}
	else if (key == "T{한글}") // 한글로 변경
	{
		if (language == "en")
		{
			webMI.trigger.fire("Keyboard_Capital_Small_Change", "Small");
			webMI.trigger.fire("Keyboard_en_ko_Change", "ko");
			once_Capital_shift = false;
			cpas_lock = false;
		}
		
		language = "ko";
	}
	else if (key == "T{영어}") // 영어로 변경
	{
		if (language == "ko")
		{
			webMI.trigger.fire("Keyboard_Capital_Small_Change", "Small");
			webMI.trigger.fire("Keyboard_en_ko_Change", "en");
			once_Capital_shift = false;
			cpas_lock = false;
		}
		
		language = "en";
	}
	else
	{
		cho = null;
		jung = null;
		jong = null;
		currentText  += key;
	}
	
	if (once_Capital_shift == true)
	{
		once_Capital_shift = false;
		webMI.trigger.fire("Keyboard_Capital_Small_Change", "Small");
	}	
	
	if (max_len < currentText.length)
	{
		currentText = currentText.slice(0, -1);
	}	
	
	displayCurrentText();	
	
	timerId = setTimeout(function() 
	{
		cho = null;
		jung = null;
		jong = null;
		timerId = null;
	}, 2500);
	
});
