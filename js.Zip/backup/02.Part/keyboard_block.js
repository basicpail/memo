var color = webMI.query["color"];
var en_Capital_Latter = webMI.query["en_Capital_Latter"];
var en_Small_Latter = webMI.query["en_Small_Latter"];
var ko_Capital_Latter = webMI.query["ko_Capital_Latter"];
var ko_Small_Latter = webMI.query["ko_Small_Latter"];
var start_langauge = webMI.query["start_langauge"];
var current_lanauge = start_langauge;
var current_value;

//////////색상 변수/////////////
var normal_back_color;
var active_back_color;

var color_Btn_Background_Down;
var color_Table_Cell_Background_Control;
var color_Font_Default;

/////////초기 Day/Night 색상 적용/////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	webMI.gfx.setFill("back_ground", color.Btn_Background[color_mode]);
	normal_back_color = color.Btn_Background[color_mode];
	
	webMI.gfx.setFill("text", color.Font_Default[color_mode]);
	
	active_back_color = color.Btn_Background_Down[color_mode];
};

///////////초기 글자 세팅//////////////////////////

if (start_langauge == "en")
{
	webMI.gfx.setText("text", en_Small_Latter);
	current_value = en_Small_Latter;
}
else if(start_langauge == "ko")
{
	webMI.gfx.setText("text", ko_Small_Latter);
	current_value = ko_Small_Latter;
}

//////////////////대소문자 바꾸기////////////////////////////////

webMI.trigger.connect("Keyboard_Capital_Small_Change", function(e)
{
	var val = e.value;
	
	if(val == "Capital")
	{
		if (current_lanauge == "en")
		{
			webMI.gfx.setText("text", en_Capital_Latter);
			current_value = en_Capital_Latter;
		}
		else if (current_lanauge == "ko")
		{	
			webMI.gfx.setText("text", ko_Capital_Latter);
			current_value = ko_Capital_Latter;
		}
	}
	else if(val == "Small")
	{
		if (current_lanauge == "en")
		{
			webMI.gfx.setText("text", en_Small_Latter);
			current_value = en_Small_Latter;
		}
		else if (current_lanauge == "ko")
		{
			webMI.gfx.setText("text", ko_Small_Latter);
			current_value = ko_Small_Latter;
		}
	}
});

//////////////한영 변경////////////////////////////////////////////////

webMI.trigger.connect("Keyboard_en_ko_Change", function(e)
{
	var val = e.value;
	
	if(val == "en")
	{
		webMI.gfx.setText("text", en_Small_Latter);
		current_value = en_Small_Latter;
		current_lanauge = "en";
	}
	else if(val == "ko")
	{
		webMI.gfx.setText("text", ko_Small_Latter);
		current_value = ko_Small_Latter;
		current_lanauge = "ko";
	}
});


////////////클릭 시 클릭 효과 ///////////////////////////////////////
webMI.addEvent("btn_click", ["mousedown","touchstart"], function(e) {
var id = "btn_click";
var value = true;
webMI.gfx.setFill("back_ground", active_back_color);
});


webMI.addEvent("btn_click", ["mouseup","mouseout", "touchend"], function(e) {
var id = "btn_click";
var value = true;
webMI.gfx.setFill("back_ground", normal_back_color);
});


webMI.addEvent("btn_click", "click", function(e) {
var id = "btn_click";
var value = true;
webMI.trigger.fire("Keyboard_Btn_Click", current_value);
});

