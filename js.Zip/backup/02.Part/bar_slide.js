///////////////////////////*  주/야간 색상 변경  *///////////////////////////
var color = webMI.query["color"];

var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	webMI.gfx.setFill("bar_back", color.Btn_Background[color_mode]);
	webMI.gfx.setStroke("bar_back", color.Main_Background[color_mode]);
	webMI.gfx.setFill("line_1", color.Table_Title[color_mode]);
	webMI.gfx.setFill("line_2", color.Table_Title[color_mode]);
	webMI.gfx.setFill("line_3", color.Table_Title[color_mode]);
	webMI.gfx.setFill("line_4", color.Table_Title[color_mode]);
	webMI.gfx.setFill("line_5", color.Table_Title[color_mode]);
	
	webMI.gfx.setStroke("line_6", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_7", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_8", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_9", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_10", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_11", color.Under_Line[color_mode]);
}