var color = webMI.query["color"];

var Probe_Feedback_Active;
var Probe_Correction_Active;
var Probe_CheckData_Active;

var btn_feedback_active_lamp = document.getElementById("btn_feedback_active_lamp");
var btn_feedback_inactive_lamp = document.getElementById("btn_feedback_inactive_lamp");
var btn_correction_active_lamp = document.getElementById("btn_correction_active_lamp");
var btn_correction_inactive_lamp = document.getElementById("btn_correction_inactive_lamp");
var btn_data_active_lamp = document.getElementById("btn_data_active_lamp");
var btn_data_inactive_lamp = document.getElementById("btn_data_inactive_lamp");

var apply_popup = false;
var select_probe_option;

var now_data_freq;

webMI.trigger.fire("btn_inactive_click", "1s");
webMI.trigger.fire("btn_inactive_click", "3s");
webMI.trigger.fire("btn_inactive_click", "5s");
webMI.trigger.fire("btn_inactive_click", "10s");

var iframe= webMI.rootWindow.document.querySelector("#page_main_myframe").contentWindow.document.body;

iframe.addEventListener("click", () => {
  localStorage.setItem("NoTouchCount",0);
});      

///////////////////////////*  주/야간 색상 변경 *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	webMI.gfx.setFill("background_display", color.Main_Background[color_mode]);
	webMI.gfx.setFill("bento_1", color.Bento[color_mode]);
	webMI.gfx.setFill("bento_2", color.Bento[color_mode]);
	webMI.gfx.setFill("bento_3", color.Bento[color_mode]);

	webMI.gfx.setFill("lbl_probe", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_network", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_data_freq", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_feedback", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_correction", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_data_check", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_net_work", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_ethernet", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_probe2", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_cpsu", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_data_freq", color.Font_Title[color_mode]);

	webMI.data.read("AGENT.OBJECTS.06_PROBE..Enable_Probe_Feedback", function(e)
	{
		Probe_Feedback_Active = e.value;
		Change_Probe_Feedback_Status(Probe_Feedback_Active);	
	});
	
	webMI.data.read("AGENT.OBJECTS.06_PROBE..Enable_Probe_Correction", function(e)
	{
		Probe_Correction_Active = e.value;
		Change_Probe_Correction_Status(Probe_Correction_Active);
	});
	
	webMI.data.read("AGENT.OBJECTS.06_PROBE..Enable_Probe_DataCheck", function(e)
	{
		Probe_CheckData_Active = e.value;
		Change_Probe_CheckData_Status(Probe_CheckData_Active);
	});
}


///////////////////////////*  데이터 전시 주기 읽어오기 *///////////////////////////
///////atvise builder 상단의 탭 중 View -> Nodbrowser 를 클릭하면 Navigator에 Nodebrowser탭이 생기고 Object -> AGENT ->DATASOURCES->PLC_DATA ->sampling_interval 경로에 값이 있음
webMI.data.read("AGENT.DATASOURCES.PLC_DATA.sampling_interval", function(e)
{
	now_data_freq = parseInt(e.value, 10) / 1000;
	
	Data_Freq(now_data_freq, "");
});

webMI.trigger.fire("btn_inactive_click", "btn_apply");	// 초기 설정 : 데이터 전시 주기 적용 버튼 클릭 효과 비활성화

/////////////권한 확인////////////////////////////////////////
function Prevention_Check(prevention_level, callback)
{
	///////////////// Default에 함수가 정의 되어있음/////////////////////////
	webMI.trigger.fire("Prevention_Check", {level : prevention_level, callback : function(access)
	{
		if (access == false)
		{
			webMI.trigger.fire("Info_Popup_Open", { title : "T{권한}", info : "T{해당 기능에 대한 권한이 없습니다.}" });
			return;
		}
		else
		{
			callback();
		}
	}});
}

///////////////////////////* 3축 자기센서 프로브 버튼 클릭 이벤트  *///////////////////////////
webMI.addEvent("btn_feedback_active", "click", function(e)		// 피드백 보상 활성화 버튼
{
	var prevention_level = 2;
	Prevention_Check(prevention_level, () => {
		select_probe_option = "피드백 보상 활성화";
		
		if (Probe_Feedback_Active == false)
		{
			Click_Prevention("open");
		
			Popup_Text("probe", "feedback_active");
			Apply_popup_Open("apply_popup", prevention_level);
		}
	});
});


webMI.addEvent("btn_feedback_inactive", "click", function(e)		// 피드백 보상 비활성화 버튼
{
	var prevention_level = 2;
	Prevention_Check(prevention_level, () => {
		select_probe_option = "피드백 보상 비활성화";
	
		if (Probe_Feedback_Active == true)
		{
			Click_Prevention("open");
			
			Popup_Text("probe", "feedback_inactive");
			Apply_popup_Open("apply_popup",prevention_level);
		}
	});
});


webMI.addEvent("btn_correction_active", "click", function(e)		// 보정 활성화 버튼
{
	var prevention_level = 2;
	Prevention_Check(prevention_level, () => {
		select_probe_option = "보정 활성화";
		
		if (Probe_Correction_Active == false)
		{
			Click_Prevention("open");
		
			Popup_Text("probe", "correction_active");
			Apply_popup_Open("apply_popup", prevention_level);
		}
	});
});


webMI.addEvent("btn_correction_inactive", "click", function(e)		// 보정 비활성화 버튼
{
	var prevention_level = 2;
	Prevention_Check(prevention_level, () => {
	
		select_probe_option = "보정 비활성화";
		
		if (Probe_Correction_Active == true)
		{
			Click_Prevention("open");
		
			Popup_Text("probe", "correction_inactive");
			Apply_popup_Open("apply_popup",prevention_level);
		}
	});
});


webMI.addEvent("btn_data_active", "click", function(e)		// 데이터 확인 활성화 버튼
{
	var prevention_level = 2;
	Prevention_Check(prevention_level, () => {
		select_probe_option = "데이터 확인 활성화";
		
		if (Probe_CheckData_Active == false)
		{
			Click_Prevention("open");
			
			Popup_Text("probe", "data_check_active");
			Apply_popup_Open("apply_popup", prevention_level);
		}
	});
});


webMI.addEvent("btn_data_inactive", "click", function(e)		// 데이터 확인 비활성화 버튼
{
	var prevention_level = 2;
	Prevention_Check(prevention_level, () => {
		select_probe_option = "데이터 확인 비활성화";
		
		if (Probe_CheckData_Active == true)
		{
			Click_Prevention("open");
			
			Popup_Text("probe", "data_check_inactive");
			Apply_popup_Open("apply_popup",prevention_level);
		}
	});
});


///////////////////////////*  3축 자기센서 프로브 상태 변화  *///////////////////////////

function Change_Probe_Feedback_Status(value)
{
	if (value == "true" || value == 1)
	{
		btn_feedback_active_lamp.setAttribute("fill", color.BtnLamp_On[color_mode]);
		btn_feedback_inactive_lamp.setAttribute("fill", color.BtnLamp_Off[color_mode]);

		Probe_Feedback_Active = true;
		webMI.trigger.fire("btn_inactive_click", "feedback_active");	// 버튼 클릭 효과 x
		webMI.trigger.fire("btn_active", "feedback_inactive");
		
		webMI.data.write("AGENT.OBJECTS.Control._Enable_Probe_Feedback", 1);
	}
	else
	{
		btn_feedback_active_lamp.setAttribute("fill", color.BtnLamp_Off[color_mode]);
		btn_feedback_inactive_lamp.setAttribute("fill", color.BtnLamp_On[color_mode]);

		Probe_Feedback_Active = false;
		webMI.trigger.fire("btn_inactive_click", "feedback_inactive");	// 버튼 클릭 효과 x
		webMI.trigger.fire("btn_active", "feedback_active");
		
		webMI.data.write("AGENT.OBJECTS.Control._Enable_Probe_Feedback", 0);
	}
}

function Change_Probe_Correction_Status(value)
{
	if (value == "true" || value == 1)
	{
		btn_correction_active_lamp.setAttribute("fill", color.BtnLamp_On[color_mode]);
		btn_correction_inactive_lamp.setAttribute("fill", color.BtnLamp_Off[color_mode]);

		Probe_Correction_Active = true;
		webMI.trigger.fire("btn_inactive_click", "correction_active");	// 버튼 클릭 효과 x
		webMI.trigger.fire("btn_active", "correction_inactive");
		
		webMI.data.write("AGENT.OBJECTS.Control._Enable_Probe_Correction", 1);
	}
	else
	{
		btn_correction_active_lamp.setAttribute("fill", color.BtnLamp_Off[color_mode]);
		btn_correction_inactive_lamp.setAttribute("fill", color.BtnLamp_On[color_mode]);

		Probe_Correction_Active = false;
		webMI.trigger.fire("btn_inactive_click", "correction_inactive");	// 버튼 클릭 효과 x
		webMI.trigger.fire("btn_active", "correction_active")
		
		webMI.data.write("AGENT.OBJECTS.Control._Enable_Probe_Correction", 0);
	}
}

function Change_Probe_CheckData_Status(value)
{
	if (value == "true" || value == 1)
	{
		btn_data_active_lamp.setAttribute("fill", color.BtnLamp_On[color_mode]);
		btn_data_inactive_lamp.setAttribute("fill", color.BtnLamp_Off[color_mode]);

		Probe_CheckData_Active = true;
		webMI.trigger.fire("btn_inactive_click", "datacheck_active");	// 버튼 클릭 효과 x
		webMI.trigger.fire("btn_active", "datacheck_inactive");	
		
		webMI.data.write("AGENT.OBJECTS.Control._Enable_Probe_DataCheck", 1);
	}
	else
	{
		btn_data_active_lamp.setAttribute("fill", color.BtnLamp_Off[color_mode]);
		btn_data_inactive_lamp.setAttribute("fill", color.BtnLamp_On[color_mode]);
		
		Probe_CheckData_Active = false;
		webMI.trigger.fire("btn_active", "datacheck_active");
		webMI.trigger.fire("btn_inactive_click", "datacheck_inactive");	// 버튼 클릭 효과 x
		
		webMI.data.write("AGENT.OBJECTS.Control._Enable_Probe_DataCheck", 0);
	}
}

///////////////////////////* 팝업 열림  *///////////////////////////

function Apply_popup_Open(option, prevention_level)
{
	if (option == "apply_popup")
	{
		let apply_popup = document.getElementById("apply_popup");  
		webMI.trigger.fire("Apply_Popup_prevention_level_Set",prevention_level);				///Apply 팝업창에 Apply 가능 권한 레벨 할당

		apply_popup.setAttribute("x", "600");
		apply_popup.setAttribute("y", "270");
		
	}
	else if (option == "inner_popup")
	{
		let inner_popup = document.getElementById("inner_popup");  

		inner_popup.setAttribute("x", "200");
		inner_popup.setAttribute("y", "80");
		
	}
	else if (option == "ethernet_popup")
	{
		let ethernet_popup = document.getElementById("ethernet_popup");  

		ethernet_popup.setAttribute("x", "500");
		ethernet_popup.setAttribute("y", "80");
		
	}
	else if (option == "probe_popup")
	{
		let probe_popup = document.getElementById("probe_popup");  

		probe_popup.setAttribute("x", "500");
		probe_popup.setAttribute("y", "80");
		

	}
	else if (option == "PSU_popup")
	{
		let psu_popup = document.getElementById("psu_popup");  

		psu_popup.setAttribute("x", "200");
		psu_popup.setAttribute("y", "60");
		
	}
}


///////////////////////////* 팝업 적용 버튼  *///////////////////////////

webMI.trigger.connect("Apply", function(e)
{
	// 3축 자기센서 프로브
	
	if (select_probe_option == "피드백 보상 활성화")
	{
		Change_Probe_Feedback_Status("true");
		webMI.trigger.fire("Event_Add", "Data Change : Feedback Comp. - Active");			/////Default에 정의되어있음
	}
	else if (select_probe_option == "피드백 보상 비활성화")
	{
		Change_Probe_Feedback_Status("false");
		webMI.trigger.fire("Event_Add", "Data Change : Feedback Comp. - Inactive");			/////Default에 정의되어있음
	}
	else if (select_probe_option == "보정 활성화")
	{
		Change_Probe_Correction_Status("true");
		webMI.trigger.fire("Event_Add", "Data Change : Correction - Active");			/////Default에 정의되어있음
	}
	else if (select_probe_option == "보정 비활성화")
	{
		Change_Probe_Correction_Status("false");
		webMI.trigger.fire("Event_Add", "Data Change : Correction - Inactive");			/////Default에 정의되어있음
	}
	else if (select_probe_option == "데이터 확인 활성화")
	{
		Change_Probe_CheckData_Status("true");
		webMI.trigger.fire("Event_Add", "Data Change : Data Check - Active");			/////Default에 정의되어있음
	}
	else if (select_probe_option == "데이터 확인 비활성화")
	{
		Change_Probe_CheckData_Status("false");
		webMI.trigger.fire("Event_Add", "Data Change : Data Check - Inactive");			/////Default에 정의되어있음
	}
	else if (window.data_freq && window.select_data_freq != now_data_freq)
	{
		now_data_freq = window.select_data_freq;
		Data_Freq(now_data_freq);
		
		///////atvise builder 상단의 탭 중 View -> Nodbrowser 를 클릭하면 Navigator에 Nodebrowser탭이 생기고 Object -> AGENT ->DATASOURCES->PLC_DATA ->sampling_interval 경로에 값이 있음
		webMI.data.write("AGENT.DATASOURCES.PLC_DATA.sampling_interval", window.select_data_freq + "000");
		webMI.data.write("AGENT.DATASOURCES.PLC_DATA.publishing_interval", window.select_data_freq + "000");
		
		webMI.trigger.fire("btn_inactive_click", "btn_apply");
		handleClickDataFreq(false);
		
		webMI.trigger.fire("Event_Add", "Data Change : Data Display Interval - " + now_data_freq + "s");			/////Default에 정의되어있음
	}
	
	webMI.trigger.fire("Apply_Popup_Cancel");
});


///////////////////////////*  선택된 데이터 소스 값 저장  *///////////////////////////

function handleClickSelectDataFreq(value)
{
    window.select_data_freq = value; // 최근 클릭된 값을 저장
}
function handleClickDataFreq(value)
{
    window.data_freq = value; // 최근 클릭된 값을 저장
}


///////////////////////////*  적용 팝업 취소 버튼  *///////////////////////////

webMI.trigger.connect("Apply_Popup_Cancel", function(e)
{
	let apply_popup = document.getElementById("apply_popup");  

	apply_popup.setAttribute("x", "0");
	apply_popup.setAttribute("y", "1000");
	
	Click_Prevention("close");
	
	if (window.data_freq)
	{
		window.select_data_freq = now_data_freq;
		Data_Freq(now_data_freq);
		window.data_freq = false;
		webMI.trigger.fire("btn_inactive_click", "btn_apply");
	}
});


///// 팝업 오픈 시 뒤에 클릭안되게 하는 화면 열기/닫기
function Click_Prevention(popup, paramter)
{
	if (popup == "open")
	{
		let shadow = document.getElementById("shadow");  
		if (paramter == undefined)
		{
			webMI.trigger.fire("Prevention_Open");	
		}
		else
		{
			webMI.trigger.fire("Prevention_Open",paramter);	
		}
		
		shadow.setAttribute("x", "0");
		shadow.setAttribute("y", "0");

	}
	else if (popup == "close")
	{
		let shadow = document.getElementById("shadow");  
		webMI.trigger.fire("Prevention_Close");
		
		shadow.setAttribute("x", "0");
		shadow.setAttribute("y", "-1000");	// 화면 밖으로

	}
}

//////현재 페이지 이외에서 팝업 요청 시 Shadow Visible, Invisible/////////////
webMI.trigger.connect("Prevention_req",function(e)
{
	let parameter = e.value.parameter;
	parameter = parameter == null ? undefined : parameter; 
	Click_Prevention(e.value.req, parameter);
});

///////////////////////////*  내부 네트워크 연동 확인 닫기 버튼  *///////////////////////////

webMI.trigger.connect("Inner_Popup_Close", function(e)
{
	let inner_popup = document.getElementById("inner_popup");  

	inner_popup.setAttribute("x", "0");
	inner_popup.setAttribute("y", "-1000");
	
	Click_Prevention("close");
});


///////////////////////////*  이더넷 연동 확인 닫기 버튼  *///////////////////////////

webMI.trigger.connect("Ethernet_Popup_Close", function(e)
{
	let ethernet_popup = document.getElementById("ethernet_popup");  

	ethernet_popup.setAttribute("x", "0");
	ethernet_popup.setAttribute("y", "1000");
	
	Click_Prevention("close");
});


///////////////////////////*  3축 자기센서 프로브 연동 확인 닫기 버튼  *///////////////////////////

webMI.trigger.connect("Probe_Popup_Close", function(e)
{
	let probe_popup = document.getElementById("probe_popup");  

	probe_popup.setAttribute("x", "0");
	probe_popup.setAttribute("y", "1000");
	
	Click_Prevention("close");
});


///////////////////////////*  코일 전원 공급기 연동 확인 닫기 버튼  *///////////////////////////

webMI.trigger.connect("PSU_Popup_Close", function(e)
{
	let psu_popup = document.getElementById("psu_popup");  

	psu_popup.setAttribute("x", "0");
	psu_popup.setAttribute("y", "1000");
	
	Click_Prevention("close");
});


///////////////////////////*  데이터 전시 주기 적용 버튼 클릭 이벤트  *///////////////////////////

webMI.addEvent("btn_data_freq", "click", function(e)
{
	var prevention_level = 3;
	Prevention_Check(prevention_level, () => {
		if (window.select_data_freq != undefined)
		{
			handleClickDataFreq(true);
		
			if (window.data_freq && (window.select_data_freq != now_data_freq))
			{
				Popup_Text("data_freq");
				Apply_popup_Open("apply_popup",prevention_level);
			}
		}
	});
});


///////////////////////////*  데이터 전시 주기 버튼 클릭 이벤트  *///////////////////////////

let freq_second = [1, 3, 5, 10];

freq_second.forEach(freq =>
{
    webMI.addEvent(`btn_data_freq_${freq}s`, "click", function (e)
    {
        handleClickSelectDataFreq(freq);

        if (window.select_data_freq == now_data_freq)
        {
            webMI.gfx.setFill(`btn_data_freq_${freq}s_background`, color.Btn_Background_DataFreq_Apply[color_mode]);
            webMI.trigger.fire("btn_inactive_click", `${freq}s`);
            webMI.trigger.fire("btn_inactive_click", "btn_apply");
        }
        else
        {
            Data_Freq(now_data_freq, window.select_data_freq);
            webMI.trigger.fire("btn_active", "btn_apply");
        }
    });
});


///////////////////////////*  데이터 주기 배경 색상  *///////////////////////////

function Data_Freq(now_data, select_data)
{
    let btns = ["btn_data_freq_1s_background", "btn_data_freq_3s_background", "btn_data_freq_5s_background", "btn_data_freq_10s_background"];

    btns.forEach(btn => webMI.gfx.setFill(btn, color.Btn_Background[color_mode]));	// 기본 배경색
	
	let values = [1, 3, 5, 10];
	
	let select_index = values.indexOf(select_data);
	let now_index = values.indexOf(now_data);
	
	let select_btn = btns[select_index];
	let now_btn = btns[now_index];
	
	webMI.gfx.setFill(now_btn, color.Btn_Background_DataFreq_Apply[color_mode]);	// 적용 후 선택(파랑)
	webMI.gfx.setFill(select_btn, color.Btn_Background_DataFreq_Selected[color_mode]);	// 적용 전 선택(회색)
}


///////////////////////////*  적용 팝업 텍스트 변경 함수  *///////////////////////////

function Popup_Text(option1, option2)
{
	if (option1 == "probe")	// 3축 자기센서 프로브
	{
		webMI.gfx.setText("apply_popup_lbl_title", "T{3축 자기센서 프로브}");
		
		webMI.gfx.setVisible("apply_popup_lbl_content", true);
		webMI.gfx.setVisible("apply_popup_lbl_content_line1", false);
		webMI.gfx.setVisible("apply_popup_lbl_content_line2", false);
		
		if (option2 == "feedback_active")
		{
			webMI.gfx.setText("apply_popup_lbl_content", "T{피드백 보상을 활성화하시겠습니까?}")
		}
		else if (option2 == "feedback_inactive")
		{
			webMI.gfx.setText("apply_popup_lbl_content", "T{피드백 보상을 비활성화하시겠습니까?}")
		}
		else if (option2 == "correction_active")
		{
			webMI.gfx.setText("apply_popup_lbl_content", "T{보정을 활성화하시겠습니까?}")
		}
		else if (option2 == "correction_inactive")
		{
			webMI.gfx.setText("apply_popup_lbl_content", "T{보정을 비활성화하시겠습니까?}")
		}
		else if (option2 == "data_check_active")
		{
			webMI.gfx.setText("apply_popup_lbl_content", "T{데이터 확인을 활성화하시겠습니까?}")
		}
		else if (option2 == "data_check_inactive")
		{
			webMI.gfx.setText("apply_popup_lbl_content", "T{데이터 확인을 비활성화하시겠습니까?}")
		}
	}
	else if (option1 == "data_freq")	// 데이터 전시 주기 변경
	{
		webMI.gfx.setText("apply_popup_lbl_title", "T{데이터 전시 주기 변경}");
		
		webMI.gfx.setVisible("apply_popup_lbl_content", true);
		webMI.gfx.setVisible("apply_popup_lbl_content_line1", false);
		webMI.gfx.setVisible("apply_popup_lbl_content_line2", false);
		
		//webMI.gfx.setText("apply_popup_lbl_content", window.select_data_freq + "초로 변경하시겠습니까?"); 영문 번역 때문에 나눔
		
		if (window.select_data_freq == 1)
		{
			webMI.gfx.setText("apply_popup_lbl_content", "T{1초로 변경하시겠습니까?}");
		}
		else if (window.select_data_freq == 3)
		{
			webMI.gfx.setText("apply_popup_lbl_content", "T{3초로 변경하시겠습니까?}");
		}
		else if (window.select_data_freq == 5)
		{
			webMI.gfx.setText("apply_popup_lbl_content", "T{5초로 변경하시겠습니까?}");
		}
		else if (window.select_data_freq == 10)
		{
			webMI.gfx.setText("apply_popup_lbl_content", "T{10초로 변경하시겠습니까?}");
		}
	}
}


///////////////////////////*  내부 네트워크 연동 확인 버튼 클릭 이벤트  *///////////////////////////

webMI.addEvent("btn_inner_network", "click", function(e)
{
	Click_Prevention("open");
	Apply_popup_Open("inner_popup");
});


///////////////////////////*  이더넷 연동 확인 버튼 클릭 이벤트  *///////////////////////////

webMI.addEvent("btn_ethernet", "click", function(e)
{
	Click_Prevention("open");
	Apply_popup_Open("ethernet_popup");
});


///////////////////////////*  3축 자기센서 프로브 연동 확인 버튼 클릭 이벤트  *///////////////////////////

webMI.addEvent("btn_probe", "click", function(e)
{
	Click_Prevention("open");
	Apply_popup_Open("probe_popup");
});


///////////////////////////*  코일 전원 공급기 연동 확인 버튼 클릭 이벤트  *///////////////////////////

webMI.addEvent("btn_psu", "click", function(e)
{
	Click_Prevention("open");
	Apply_popup_Open("PSU_popup");
});

///////////////////////////*  유저 매뉴얼 버튼 클릭 이벤트 *///////////////////////////

webMI.trigger.connect("UserManual_Open", function(e)
{
	
	Click_Prevention("open");
	let time_popup = document.getElementById("user_manual_popup");  

	time_popup.setAttribute("x", "603");		//960 -357 
	time_popup.setAttribute("y", "20");
	webMI.trigger.fire("UserManual_Move");
});

webMI.trigger.connect("UserManual_Close", function(e)
{
	Click_Prevention("close")
	let time_popup = document.getElementById("user_manual_popup");  
	time_popup.setAttribute("x", "0");
	time_popup.setAttribute("y", "1000");	// 화면 밖으로
	
});

//////////////////////////키패드 오픈//////////////////////////////////
webMI.trigger.connect("Keyboard_Open", function(e)
{
	var type = e.value.type;
	
	var options = {};	
	var max_len = 0;
	var password_on = false;
	
	if (e.value.type == "ID")
	{
		max_len =15;
		password_on =false;
	}
	else if(e.value.type == "PW")
	{
		max_len = 21;
		password_on = true;
	}	
	
	options["parameter"] = type;
	options["max_len"] = max_len;
	options["password_on"] = password_on;
	
	webMI.trigger.fire("keyboard_init", options);
	
	let popup = document.getElementById("popup_keyboard");  
	popup.setAttribute("x", "310");
	popup.setAttribute("y", "285");	
});
	
////////////////키보드 종료///////////////////////////
webMI.trigger.connect("Keyboard_Close", function(e)
{
	let popup = document.getElementById("popup_keyboard");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

//////////////////////////로그인 팝업창 오픈//////////////////////////////////
webMI.trigger.connect("Login_Open", function(e)
{
	Click_Prevention("open");
	webMI.trigger.fire("Login_Popup_init");
	
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("x", "602");
	popup.setAttribute("y", "213");	
});
	
////////////////로그인 팝업창 종료///////////////////////////
webMI.trigger.connect("Login_Close", function(e)
{
	Click_Prevention("close");
	
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

////////////////로그인 팝업창 올리기///////////////////////////
webMI.trigger.connect("Login_Popup_Up", function(e)
{
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("y", "20");	
});

////////////////로그인 팝업창 내리기///////////////////////////
webMI.trigger.connect("Login_Popup_Down", function(e)
{
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("y", "213");	
});

//////////////////////////정보 팝업창 오픈//////////////////////////////////
webMI.trigger.connect("Info_Popup_Open", function(e)
{
	Click_Prevention("open");
	webMI.trigger.fire("Info_Init",e.value);	
	
	let popup = document.getElementById("info_popup");  
	popup.setAttribute("x", "602");
	popup.setAttribute("y", "213");	
});
	
////////////////정보 팝업창 종료///////////////////////////
webMI.trigger.connect("Info_Popup_Close", function(e)
{
	Click_Prevention("close");
	
	let popup = document.getElementById("info_popup");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});