var color = webMI.query["color"];
var now_page = 1;
const PAGE_MAX = 11;

const textbox_data =
[
    "tb_IGRF_g_10", "tb_IGRF_h_10", "tb_SV_g_10", "tb_SV_h_10",
    "tb_IGRF_g_11", "tb_IGRF_h_11", "tb_SV_g_11", "tb_SV_h_11",
    "tb_IGRF_g_20", "tb_IGRF_h_20", "tb_SV_g_20", "tb_SV_h_20",
    "tb_IGRF_g_21", "tb_IGRF_h_21", "tb_SV_g_21", "tb_SV_h_21",
    "tb_IGRF_g_22", "tb_IGRF_h_22", "tb_SV_g_22", "tb_SV_h_22",
    "tb_IGRF_g_30", "tb_IGRF_h_30", "tb_SV_g_30", "tb_SV_h_30",
    "tb_IGRF_g_31", "tb_IGRF_h_31", "tb_SV_g_31", "tb_SV_h_31",
    "tb_IGRF_g_32", "tb_IGRF_h_32", "tb_SV_g_32", "tb_SV_h_32",
    "tb_IGRF_g_33", "tb_IGRF_h_33", "tb_SV_g_33", "tb_SV_h_33",
    "tb_IGRF_g_40", "tb_IGRF_h_40", "tb_SV_g_40", "tb_SV_h_40"
];

const textbox_row = 
[
	"tb_row1_n", "tb_row1_m", "tb_row2_n", "tb_row2_m",
	"tb_row3_n", "tb_row3_m", "tb_row4_n", "tb_row4_m",
	"tb_row5_n", "tb_row5_m", "tb_row6_n", "tb_row6_m",
	"tb_row7_n", "tb_row7_m", "tb_row8_n", "tb_row8_m",
	"tb_row9_n", "tb_row9_m", "tb_row10_n", "tb_row10_m",
];


webMI.trigger.fire("btn_inactive", "IGRF_pre_page");
webMI.trigger.fire("btn_inactive", "IGRF_pre_page_max");

var iframe= webMI.rootWindow.document.querySelector("#page_main_myframe").contentWindow.document.body;

iframe.addEventListener("click", () => {
  localStorage.setItem("NoTouchCount",0);
});   

///////////////////////////*  주/야간 색상 변경  *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	webMI.gfx.setFill("background_display", color.Main_Background[color_mode]);
		
	webMI.gfx.setFill("bento", color.Bento[color_mode]);
	
	webMI.gfx.setFill("text_page", color.Font_Default[color_mode]);
}


///////////////////////////*  테이블 정보 업데이트 함수 *///////////////////////////

function updateData(now_page)
{
	if (now_page == 1)
	{
		webMI.trigger.fire("btn_inactive", "IGRF_pre_page");		// 1 페이지 이전 버튼 비활성화
		webMI.trigger.fire("btn_inactive", "IGRF_pre_page_max");		// 1 페이지 이전 버튼 비활성화
	}
	else
	{
		webMI.trigger.fire("btn_active", "IGRF_pre_page");
		webMI.trigger.fire("btn_active", "IGRF_pre_page_max");		// 1 페이지 이전 버튼 비활성화
	}
	
	if (now_page == PAGE_MAX)
	{
		webMI.trigger.fire("btn_inactive", "IGRF_next_page");	// 마지막 페이지 다음 버튼 비활성화
		webMI.trigger.fire("btn_inactive", "IGRF_next_page_max");	// 마지막 페이지 다음 버튼 비활성화
	}
	else
	{
		webMI.trigger.fire("btn_active", "IGRF_next_page");
		webMI.trigger.fire("btn_active", "IGRF_next_page_max");
	}
	
    let data_addr = []; // 매번 초기화
    const start = (now_page - 1) * 10 + 1;	// 현재 페이지 숫자 = 첫번째 데이터 행
    const end = start + 9;							// 한 페이지에 10개 데이터 표시
	
	let row_addr = [];
	
	for (let i = start; i <= end; i++)
	{
		row_addr.push(`AGENT.OBJECTS.01_IGRF..row1_head[${i}]`);
		row_addr.push(`AGENT.OBJECTS.01_IGRF..row2_head[${i}]`);
    }
	
	webMI.data.read(row_addr, function(e)	// n, m 쓰기
	{
		if (Array.isArray(e))
		{
			for (let i = 0; i < textbox_row.length; i++)
			{
				let tb_row = `${textbox_row[i]}_text_center`;
				let value = e[i]?.value;

				if (value !== undefined)
				{
					webMI.gfx.setText(tb_row, value);
				}
			}
		}
	});
	
    for (let i = start; i <= end; i++)
    {
        for (let j = 1; j <= 4; j++)
        {
            data_addr.push(`AGENT.OBJECTS.01_IGRF..IGRF_data[${i},${j}]`);
        }
    }
	
    webMI.data.read(data_addr, function(e)	// 데이터 쓰기
	{
		if (Array.isArray(e))
		{
			for (let i = 0; i < textbox_data.length; i++)
			{
				let tb_data = `${textbox_data[i]}_text_center`;
				let value = e[i]?.value;
				
				if (value !== undefined)
				{
					value = parseFloat(value.toFixed(2)); // 소수점 2자리까지 표시
					webMI.gfx.setText(tb_data, value);
					webMI.gfx.setFill(tb_data, color.Font_Default[color_mode]);
				}
			}
		}
		
		if (now_page == PAGE_MAX)	// 마지막 페이지 데이터 없는 부분 지우기
		{
			for (i = 16; i <= textbox_data.length - 1; i++)
			{
				webMI.gfx.setText(`${textbox_data[i]}_text_center`, "");
			}
		}
	});	
}

updateData(now_page);


///////////////////////////*  버전 정보 쓰기 *///////////////////////////

webMI.data.read(`AGENT.OBJECTS.01_IGRF..IGRF_Year`, function(e)
{
	webMI.gfx.setText("tb_IGRF_year_text_center", e.value);
});

///////////////////////////*  IGRF 연도 정보 쓰기 *///////////////////////////

webMI.data.read(`AGENT.OBJECTS.01_IGRF..SV_Year`, function(e)
{
	webMI.gfx.setText("tb_SV_text_center", e.value);
});

///////////////////////////*  SV 정보 쓰기 *///////////////////////////

webMI.data.read(`AGENT.OBJECTS.01_IGRF..IGRF_File_Version`, function(e)
{
	webMI.gfx.setText("tb_version_text_center", e.value);
});

///////현재 페이지/최대 페이지 갯수 글자 업데이트////////////
function Page_Text_Update(pageNum, pageMax)
{
	webMI.gfx.setText("text_page", String(pageNum).padStart(2, '0') + " | " + String(pageMax).padStart(2, '0'));
}

///////////////////////////*  페이지 이전 버튼 클릭 이벤트 *///////////////////////////

webMI.addEvent("btn_pre_page", "click", function(e)
{
	if (now_page <= 1)
	{
		return;
	}
	
	now_page--;
		
	updateData(now_page);
	
	Page_Text_Update(now_page,PAGE_MAX);
});

///////////////////////////*  페이지 최대 이전 버튼 클릭 이벤트 *///////////////////////////
webMI.addEvent("btn_pre_page_max", "click", function(e)
{
	if (now_page <= 1)
	{
		return;
	}
	
	now_page = 1;	
	
	updateData(now_page);
	
	Page_Text_Update(now_page,PAGE_MAX);
});

///////////////////////////*  페이지 다음 버튼 클릭 이벤트 *///////////////////////////

webMI.addEvent("btn_next_page", "click", function(e)
{
	if (now_page >= PAGE_MAX)
	{
		return;
	}
	
	now_page++;
	
	updateData(now_page);
	
	Page_Text_Update(now_page,PAGE_MAX);
});

///////////////////////////*  페이지 다음 버튼 클릭 이벤트 *///////////////////////////

webMI.addEvent("btn_next_page_max", "click", function(e)
{
	if (now_page >= PAGE_MAX)
	{
		return;
	}
	
	now_page = PAGE_MAX;
	updateData(now_page);
	
	Page_Text_Update(now_page,PAGE_MAX);
});

///////////////////////////*  유저 매뉴얼 버튼 클릭 이벤트 *///////////////////////////

webMI.trigger.connect("UserManual_Open", function(e)
{
	
	Click_Prevention("open");
	let time_popup = document.getElementById("user_manual_popup");  

	time_popup.setAttribute("x", "603");		//960 -357 
	time_popup.setAttribute("y", "20");
	webMI.trigger.fire("UserManual_Move");
});

webMI.trigger.connect("UserManual_Close", function(e)
{
	Click_Prevention("close")
	let time_popup = document.getElementById("user_manual_popup");  
	time_popup.setAttribute("x", "0");
	time_popup.setAttribute("y", "1000");	// 화면 밖으로
	
});

///// 팝업 오픈 시 뒤에 클릭안되게 하는 화면 열기/닫기
function Click_Prevention(popup, paramter)
{
	if (popup == "open")
	{
		let shadow = document.getElementById("shadow");  
		if (paramter == undefined)
		{
			webMI.trigger.fire("Prevention_Open");	
		}
		else
		{
			webMI.trigger.fire("Prevention_Open",paramter);	
		}
		
		shadow.setAttribute("x", "0");
		shadow.setAttribute("y", "0");

	}
	else if (popup == "close")
	{
		let shadow = document.getElementById("shadow");  
		webMI.trigger.fire("Prevention_Close");
		
		shadow.setAttribute("x", "0");
		shadow.setAttribute("y", "-1000");	// 화면 밖으로

	}
}

/////////////권한 확인////////////////////////////////////////
function Prevention_Check(prevention_level, callback)
{
	webMI.trigger.fire("Prevention_Check", {level : prevention_level, callback : function(access)	
	{
		if (access == false)
		{
			webMI.trigger.fire("Info_Popup_Open", { title : "T{권한}", info : "T{해당 기능에 대한 권한이 없습니다.}" });
			return;
		}
		else
		{
			callback();
		}
	}});
}

//////현재 페이지 이외에서 팝업 요청 시 Shadow Visible, Invisible/////////////
webMI.trigger.connect("Prevention_req",function(e)
{
	let parameter = e.value.parameter;
	parameter = parameter == null ? undefined : parameter; 
	Click_Prevention(e.value.req, parameter);
});

//////////////////////////키패드 오픈//////////////////////////////////
webMI.trigger.connect("Keyboard_Open", function(e)
{
	var type = e.value.type;
	
	var options = {};	
	var max_len = 0;
	var password_on = false;
	
	if (e.value.type == "ID")
	{
		max_len =15;
		password_on =false;
	}
	else if(e.value.type == "PW")
	{
		max_len = 21;
		password_on = true;
	}	
	
	options["parameter"] = type;
	options["max_len"] = max_len;
	options["password_on"] = password_on;
	
	webMI.trigger.fire("keyboard_init", options);
	
	let popup = document.getElementById("popup_keyboard");  
	popup.setAttribute("x", "310");
	popup.setAttribute("y", "285");	
});
	
////////////////키보드 종료///////////////////////////
webMI.trigger.connect("Keyboard_Close", function(e)
{
	let popup = document.getElementById("popup_keyboard");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

//////////////////////////로그인 팝업창 오픈//////////////////////////////////
webMI.trigger.connect("Login_Open", function(e)
{
	Click_Prevention("open");
	webMI.trigger.fire("Login_Popup_init");
	
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("x", "602");
	popup.setAttribute("y", "213");	
});
	
////////////////로그인 팝업창 종료///////////////////////////
webMI.trigger.connect("Login_Close", function(e)
{
	Click_Prevention("close");
	
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

////////////////로그인 팝업창 올리기///////////////////////////
webMI.trigger.connect("Login_Popup_Up", function(e)
{
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("y", "20");	
});

////////////////로그인 팝업창 내리기///////////////////////////
webMI.trigger.connect("Login_Popup_Down", function(e)
{
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("y", "213");	
});

//////////////////////////정보 팝업창 오픈//////////////////////////////////
webMI.trigger.connect("Info_Popup_Open", function(e)
{
	Click_Prevention("open");
	webMI.trigger.fire("Info_Init",e.value);	
	
	let popup = document.getElementById("info_popup");  
	popup.setAttribute("x", "602");
	popup.setAttribute("y", "213");	
});
	
////////////////정보 팝업창 종료///////////////////////////
webMI.trigger.connect("Info_Popup_Close", function(e)
{
	Click_Prevention("close");
	
	let popup = document.getElementById("info_popup");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});


////////////// 데이터 불러오기 ////////////////////

webMI.addEvent("btn_data_read", "click", function(e) {
	var temp_prevention_level =2;
	Prevention_Check(temp_prevention_level, () => {
		updateData(now_page);
	});
});