var color = webMI.query["color"];
var dgs_mode;
var now_page = 1;
var apply_addr = "AGENT.OBJECTS.07_TEST..Apply_PSU_Test";

webMI.trigger.fire("btn_inactive", "apply");	// 적용 버튼 클릭 x -> 입력 값 생기는 경우 활성화
webMI.trigger.fire("btn_inactive", "pre_page");				// 페이지 이전 버튼 비활성화 -> 다음 버튼 누르는 경우 활성화
webMI.gfx.setText("apply_popup_lbl_title", "T{코일 전원 공급기 정격 전류 세팅 값 변경}");

///////////////////////////////////////////////////////////////////////////////
var check_value ={};
var previous_value = {};
var addr_list = {};
var apply_addr = "";

var rowMapping =
{
	1: "V1", 2: "V2", 3: "V3", 4: "V4", 5: "V5",
	6: "V6", 7: "V7", 8: "V8", 9: "A1",  10: "A2",
	11: "A3", 12: "A4", 13: "A5", 14: "L1", 15: "L2",
	16: "L3", 17: "L4", 18: "L5", 19: "L6", 20: "L7",
	21: "L8", 22: "L9", 23: "L10", 24: "L11", 25: "L12"
};

var colMapping =
{
	1: "Current_Rated", 2: "Current_Max", 3: "Current_Actual", 4: "Current_Diff", 5: "Voltage",
};

var maxMapping ={};

var digitMapping =
{
	1: 2, 
	2 : 4, 
	3 : 2, 
	4 : 3, 
	5 : 3
};

var dotMapping =
{
	1: 2, 
	2 : 3, 
	3 : 0, 
	4 : 1, 
	5 : 0
};

var signMapping =
{
	1: true, 
	2 : false, 
	3 : true, 
	4 : false, 
	5 : false
};

var click_cell = null;
var cell_id = [];

///////////////////////////*  주/야간 색상 변경  *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);
Probe_MF_Read();

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	webMI.gfx.setFill("background_display", color.Main_Background[color_mode]);
	
	webMI.gfx.setFill("bento_1", color.Bento[color_mode]);
	webMI.gfx.setFill("bento_2", color.Bento[color_mode]);
	webMI.gfx.setFill("bento_3", color.Bento[color_mode]);
	
	webMI.gfx.setFill("lbl_PSU", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl_probe", color.Font_Default[color_mode]);
	webMI.gfx.setFill("text_page", color.Font_Default[color_mode]);
}

///////////////////////////*  소자 모드 읽어오기  *///////////////////////////
//webMI.data.read("AGENT.OBJECTS.Control._DGM", function(e)
webMI.data.read("AGENT.OBJECTS.SIM_OBJECTS.02.Degaussing.Degaussing_Mode._DGM", function(e)	
{
	webMI.gfx.setVisible("shadow_footer", true);
	
	console.log(`_DGM: ${e.value}`);
	if (e.value == 1)
	{
		/*
		//셀 클릭 활성화를 위한 테스트
		dgs_mode = "비활성화";
		webMI.trigger.fire("btn_active", "all_0");
		webMI.trigger.fire("btn_active", "all_max");
		webMI.trigger.fire("btn_active","btn_test");
		*/

		dgs_mode = "수동";
		webMI.trigger.fire("btn_inactive", "all_0");
		webMI.trigger.fire("btn_inactive", "all_max");
		webMI.trigger.fire("btn_inactive","btn_test");
	}
	else if (e.value == 2)
	{
		dgs_mode = "자동";
		webMI.trigger.fire("btn_inactive", "all_0");
		webMI.trigger.fire("btn_inactive", "all_max");
		webMI.trigger.fire("btn_inactive","btn_test");
	}
	else if (e.value == 3)
	{
		dgs_mode = "비활성화";
		webMI.trigger.fire("btn_active", "all_0");
		webMI.trigger.fire("btn_active", "all_max");
		webMI.trigger.fire("btn_active","btn_test");
	}
	
	Init_Data();
});

//////////////초기 데이터 가져오기/////////////////////
function Init_Data()
{
	for (let row = 1; row <= 25; row++)
	{
		if (row <= 10)
		{
			cell_id.push(`row${row}_col1`);	
		}	
	
		for (let col = 1; col <= 5; col++)
		{
			let axis = rowMapping[row];
			let col_name = colMapping[col];
			let index = `row${row}_col${col}`;

			addr_list[index] = `AGENT.OBJECTS.07_TEST..PSU_${axis}.${col_name}`; // 데이터 주소 맵핑
			
			let addr = addr_list[index];
			
			if (col != 1)
			{
				webMI.data.subscribe(addr, function(e)
				{
					if(col == 2)
					{
						maxMapping[row] = e.value;
					}
					previous_value[index] = e.value;
				});
			}
			else
			{
				if (dgs_mode == "비활성화")
				{
					webMI.data.read(addr, function(e)
					{
						let preValue = e.value;
						previous_value[index] = preValue;
						webMI.data.write(addr + "_Temp", preValue);
					});
				}
				else
				{
					webMI.data.subscribe(addr, function(e)
					{
						previous_value[index] = e.value;
					});
				}
			}
		}
	}
	
	Cell_Click_Event(cell_id);
	setTimeout(() => {Table_Data();},300);
}

/////////////////////////*  3축 자기센서 프로브 테스트 값 읽어오기  *///////////////////////////

function Probe_MF_Read()
{
	webMI.data.subscribe("AGENT.OBJECTS.07_TEST..Probe1_V", function(e)
	{
		webMI.gfx.setText("tb_probe1_V_text_center", e.value.toFixed(1));
		webMI.gfx.setFill("tb_probe1_V_text_center", color.Font_Default[color_mode]);
	});
	
	webMI.data.subscribe("AGENT.OBJECTS.07_TEST..Probe1_A", function(e)
	{
		webMI.gfx.setText("tb_probe1_A_text_center", e.value.toFixed(1));
		webMI.gfx.setFill("tb_probe1_A_text_center", color.Font_Default[color_mode]);
	});
	
	webMI.data.subscribe("AGENT.OBJECTS.07_TEST..Probe1_L", function(e)
	{
		webMI.gfx.setText("tb_probe1_L_text_center", e.value.toFixed(1));
		webMI.gfx.setFill("tb_probe1_L_text_center", color.Font_Default[color_mode]);
	});
	
	webMI.data.subscribe("AGENT.OBJECTS.07_TEST..Probe2_V", function(e)
	{
		webMI.gfx.setText("tb_probe2_V_text_center", e.value.toFixed(1));
		webMI.gfx.setFill("tb_probe2_V_text_center", color.Font_Default[color_mode]);
	});
	
	webMI.data.subscribe("AGENT.OBJECTS.07_TEST..Probe2_A", function(e)
	{
		webMI.gfx.setText("tb_probe2_A_text_center", e.value.toFixed(1));
		webMI.gfx.setFill("tb_probe2_A_text_center", color.Font_Default[color_mode]);
	});
	
	webMI.data.subscribe("AGENT.OBJECTS.07_TEST..Probe2_L", function(e)
	{
		webMI.gfx.setText("tb_probe2_L_text_center", e.value.toFixed(1));
		webMI.gfx.setFill("tb_probe2_L_text_center", color.Font_Default[color_mode]);
	});
}

/////////////////////////////테스트 실행 버튼 ////////////////////////////////////
webMI.addEvent("btn_test", "click", function(e) {

	if (dgs_mode != "비활성화")
	{
		return;
	}
		
	webMI.data.write("AGENT.OBJECTS.07_TEST..Set_Probe",1);
});

////////////////테이블에 데이터 매핑/////////////////
function Table_Data()
{
	Change_Table_First_Col(now_page);	// 축 이름 변경

	for (let row = 1; row <= 10; row++)
	{
		for (let col = 1; col <= 5; col++)
		{
			let text = `row${row}_col${col}_text_center`;
			let background = `row${row}_col${col}_background`;
			let now_row = row + (now_page -1) * 10
			let index = `row${now_row}_col${col}`;
			webMI.gfx.setText(text, "");
			
			if (previous_value[index] != undefined)
			{
				if (col == 1 && dgs_mode == "비활성화")
				{
					webMI.gfx.setFill(background, color.Table_Cell_Background_Control[color_mode]);	// 제어(검은색)

				}
				else
				{
					webMI.gfx.setFill(background, color.Table_Cell_Background_Monitoring[color_mode]);	// 감시(회색)
				}
			}
			else
			{
				webMI.gfx.setFill(background, color.Table_Cell_Background_Control[color_mode]);	// 제어(검은색)
			}

			if (previous_value[index] != undefined)
			{
				if (check_value[index] != undefined)
				{
					webMI.gfx.setText(text, check_value[index]);
					webMI.gfx.setFill(text, color.Green_Active[color_mode]);
				}
				else
				{
					webMI.gfx.setText(text, previous_value[index]);
					
					if (col == 1 && dgs_mode == "비활성화")
					{
						webMI.gfx.setFill(text, color.Font_Table_Data[color_mode]);
					}
					else
					{
						webMI.gfx.setFill(text, color.Font_Default[color_mode]);
					}
				}
			}			
		}
	}
}

///////////////////////////*  테이블 첫 열(축) 텍스트 변경  *///////////////////////////

function Change_Table_First_Col(pageNum)
{
	for (let row = 1; row <= 10; row++)
	{
		let index = row + (pageNum -1) * 10;
		
		if (rowMapping[index] != undefined)
		{
			webMI.gfx.setText(`tb_row${row}_text_center`, rowMapping[index]);
		}
		else
		{
			webMI.gfx.setText(`tb_row${row}_text_center`, "");
		}		
	}
}


///////////////////////////*  페이지 버튼 클릭 이벤트 *///////////////////////////

webMI.addEvent("btn_pre_page", "click", function(e)
{
	if (now_page <= 1)
	{
		return;
	}	
		
	pre_click_cell = null;
	click_cell = null;
	now_page--;	
	
	webMI.gfx.setVisible("shadow_footer", true);
	Page_Text_Change();	
	Table_Data();
});


webMI.addEvent("btn_next_page", "click", function(e)
{
	if (now_page >= 3)
	{
		return;
	}	
		
	pre_click_cell = null;
	click_cell = null;
	now_page++;	
	
	webMI.gfx.setVisible("shadow_footer", true);
	Page_Text_Change();
	Table_Data();
});

function Page_Text_Change()
{
	if (now_page >= 3)
	{
		webMI.gfx.setText("text_page", "03 | 03");
		webMI.trigger.fire("btn_active", "pre_page");
		webMI.trigger.fire("btn_inactive", "next_page");
	}
	else if (now_page <= 1)
	{
		webMI.gfx.setText("text_page", "01 | 03");
		webMI.trigger.fire("btn_inactive", "pre_page");
		webMI.trigger.fire("btn_active", "next_page");
	}
	else
	{
		webMI.gfx.setText("text_page", "02 | 03");
		webMI.trigger.fire("btn_active", "pre_page");
		webMI.trigger.fire("btn_active", "next_page");
	}
}

/////////////전체 0 입력/////////////////////////
webMI.addEvent("btn_all_0", "click", function(e) {
	if (dgs_mode != "비활성화")
	{
		return;
	}
	
	check_value = {};	
	click_cell = null;
	webMI.gfx.setVisible("shadow_footer", true);
	
	for (let row = 1; row <= 25; row++)
	{
		let index = `row${row}_col1`;
		let addr = addr_list[index] + "_Temp";
		
		check_value[index] = 0;
		webMI.data.write(addr, 0);
	}
	
	Apply_active();
	Table_Data();
});

/////////////전체 최대값 입력/////////////////////////
webMI.addEvent("btn_all_max", "click", function(e) {
	if (dgs_mode != "비활성화")
	{
		return;
	}
	
	check_value = {};	
	click_cell = null;
	webMI.gfx.setVisible("shadow_footer", true);
	
	for (let row = 1; row <= 25; row++)
	{
		let index = `row${row}_col1`;
		let addr = addr_list[index] + "_Temp";
		let max_val  =maxMapping[row];
		
		check_value[index] = max_val;
		webMI.data.write(addr, max_val);
	}
	
	Apply_active();
	Table_Data();
});

///////////// 셀 클릭 /////////////////////////////
function Cell_Click_Event(buttonIds)
{
	buttonIds.forEach(buttonId =>
	{
		console.log(`셀 클릭: ${dgs_mode} buttonId: ${buttonId}`);
		webMI.addEvent(buttonId, "click", function(e)
		{
			if (dgs_mode != "비활성화")
			{
				return;
			}
				
			let temp_txt = webMI.gfx.getText(e.target.id.replace("_click_karea","_text_center"));
			
			if (temp_txt == "")
			{
				return;
			}					
			
			Table_Data();
			
			if(click_cell == buttonId)
			{
				Sing_Dot_Active(false,0);
				webMI.gfx.setVisible("shadow_footer", true);
				click_cell = null;
			}
			else
			{
				let col = Number(buttonId.slice(-1));
				let str = Digit_Count_to_Temp(digitMapping[col],dotMapping[col]);
				let text_id = buttonId + "_text_center";
				
				webMI.gfx.setText(text_id, str);
				webMI.gfx.setFill(text_id, color.Font_Selected_Data[color_mode]);
				
				Sing_Dot_Active(signMapping[col], dotMapping[col])		
				webMI.gfx.setVisible("shadow_footer", false);
				
				click_cell = buttonId;
			}
		});
	});
}

//////////////// +/-, dot 활성화/비활성화 ///////////////////
function Sing_Dot_Active(temp_sign, temp_dot)
{
	if (temp_sign)
	{
		webMI.trigger.fire("btn_active", "TEST_plus");
		webMI.trigger.fire("btn_active", "TEST_minus");
	}
	else
	{
		webMI.trigger.fire("btn_inactive", "TEST_plus");
		webMI.trigger.fire("btn_inactive", "TEST_minus");
	}				
	
	if (temp_dot != 0)
	{
		webMI.trigger.fire("btn_active", "TEST_dot");
	}
	else
	{
		webMI.trigger.fire("btn_inactive", "TEST_dot");
	}		
}

///////////////////////////*  글자수 리턴 함수  *///////////////////////////
function Digit_Count_to_Temp(digitNum, dotNum)
{
	let temp_text = "";
	
	for (let i = 0; i <digitNum; i++)
	{
		temp_text = temp_text + "_ ";
	}
	
	if (dotNum != 0)
	{
		temp_text = temp_text + ". ";
	}		
		
	for (let i = 0; i <dotNum; i++)
	{
		temp_text = temp_text + "_ ";
	}				
	
	return temp_text;
}

///////////////////////////*  숫자 버튼 클릭 이벤트 *///////////////////////////
function FooterNumber_Click(buttonIds)
{
	buttonIds.forEach(buttonId =>
	{
		webMI.addEvent(buttonId, "click", function(e)
		{
			if (click_cell == null)
			{
				return;
			}		
		
			let number = Number(buttonId.slice(-1));
			let minus = false;
			let cell_text_id = click_cell + "_text_center";
			let now_data_string = webMI.gfx.getText(cell_text_id);
			let col = Number(click_cell.slice(-1));
			let digit_num = digitMapping[col];
			let dot_num = dotMapping[col];		
			
			if (now_data_string.includes("_"))
			{
				now_data_string = "";
			}	
			
			if (now_data_string.charAt(0) == "-")
			{
				now_data_string = now_data_string.replace("-","");
				minus= true;
			}				
			
			let dot_none = !now_data_string.includes(".");
			let str_len = now_data_string.length;
			
			if (dot_none)
			{
				if (str_len < digit_num)
				{
					now_data_string = now_data_string + String(number);
				}
			}
			else
			{
				let temp_txt = now_data_string.split(".");
				temp_txt = temp_txt[temp_txt.length - 1];
				
				if (temp_txt.length < dot_num)
				{
					now_data_string = now_data_string + String(number);
				}		
			}
			
			now_data_string = minus ? "-" + now_data_string : now_data_string;
			webMI.gfx.setText(cell_text_id, now_data_string);
		});
	});
}

FooterNumber_Click(["btn_1","btn_2","btn_3","btn_4","btn_5","btn_6","btn_7","btn_8","btn_9","btn_0"]);

/////////////////////// + 버튼 클릭 ///////////////////////
webMI.addEvent("btn_plus", "click", function(e) {

	if (click_cell == null)
	{
		return;
	}
	
	let col = Number(click_cell.slice(-1));	
	let sign_active = signMapping[col];
	let cell_text_id = click_cell + "_text_center";
	let now_data_string = webMI.gfx.getText(cell_text_id);
			
	if (!sign_active)
	{
		return;
	}
	
	if (now_data_string.includes("_"))
	{
		return;
	}		
	
	if (now_data_string.charAt(0) == "-")
	{
		now_data_string = now_data_string.replace("-","");
	}
	
	webMI.gfx.setText(cell_text_id, now_data_string);
});

/////////////////////// - 버튼 클릭 ///////////////////////
webMI.addEvent("btn_minus", "click", function(e) {

	if (click_cell == null)
	{
		return;
	}
	
	let col = Number(click_cell.slice(-1));	
	let sign_active = signMapping[col];
	let cell_text_id = click_cell + "_text_center";
	let now_data_string = webMI.gfx.getText(cell_text_id);
	
	if (!sign_active)
	{
		return;
	}
	
	if (now_data_string.includes("_"))
	{
		now_data_string = "-";
	}	
		
	if (now_data_string.charAt(0) != "-")
	{
		now_data_string = "-" + now_data_string;
	}
	
	webMI.gfx.setText(cell_text_id, now_data_string);
});

///////////////////////// . 버튼 클릭 ///////////////////////
webMI.addEvent("btn_dot", "click", function(e) {

	if (click_cell == null)
	{
		return;
	}
	
	let col = Number(click_cell.slice(-1));	
	let dot_active = dotMapping[col];
	let cell_text_id = click_cell + "_text_center";
	let now_data_string = webMI.gfx.getText(cell_text_id);

	if (!dot_active)
	{
		return;
	}

	if (now_data_string.includes("_"))
	{
		now_data_string = "0.";
	}
	
	if (!now_data_string.includes("."))
	{
		now_data_string = now_data_string + ".";
	}	

	webMI.gfx.setText(cell_text_id, now_data_string);
});

////////////////////// 지우기 버튼 클릭 //////////////////////////
webMI.addEvent("btn_backspace", "click", function(e) {

	if (click_cell == null)
	{
		return;
	}

	let col = Number(click_cell.slice(-1));	
	let cell_text_id = click_cell + "_text_center";
	let now_data_string = webMI.gfx.getText(cell_text_id);

	if (now_data_string.includes("_"))
	{
		return;
	}
	
	if (now_data_string.length > 0)
	{
		now_data_string = now_data_string.slice(0, -1);
	}

	if (now_data_string.length == 0)
	{
		now_data_string = Digit_Count_to_Temp(digitMapping[col],dotMapping[col]);
	}
	
	webMI.gfx.setText(cell_text_id, now_data_string);
});

//////////////////////// 초기화 버튼 클릭	///////////////////////////
webMI.addEvent("btn_reset", "click", function(e) {

	if (click_cell == null)
	{
		return;
	}

	Cell_Init(click_cell);
	Apply_active();
});

/////////////////// 확인 버튼 클릭///////////////////////
webMI.addEvent("btn_check", "click", function(e) {

	if (click_cell == null)
	{
		return;
	}

	let col = Number(click_cell.slice(-1));	
	let cell_text_id = click_cell + "_text_center";
	let now_data_string = webMI.gfx.getText(cell_text_id);
	
	let data_index = Page_row_col_index_return(click_cell);

	if (now_data_string == "-" || now_data_string.includes("_"))
	{
		if (check_value[data_index] != null)
		{
			click_cell = null;

			webMI.gfx.setText(cell_text_id, check_value[data_index]);
			webMI.gfx.setFill(cell_text_id, color.Green_Active[color_mode]);
			Apply_active();
		}
		else
		{
			Cell_Init(click_cell);
		}
		
		return;
	}
	
	if (now_data_string.slice(-1) == ".")
	{
		now_data_string = now_data_string.slice(0, -1);
	}
	
	check_value[data_index] = Number(now_data_string);	
	webMI.data.write(addr_list[data_index] + "_Temp",check_value[data_index]);
	
	click_cell = null;
	
	webMI.gfx.setVisible("shadow_footer", true);
	webMI.gfx.setText(cell_text_id, now_data_string);
	webMI.gfx.setFill(cell_text_id, color.Green_Active[color_mode]);
	Apply_active();
});

/////////////현재 선택된 셀에서 페이지번호를 조합해서 Data index를 찾기 ///////////////////
function Page_row_col_index_return(cell_id)
{
	let temp_row = Number(cell_id.split("_")[0].replace("row",""));
	let temp_col = Number(cell_id.slice(-1));
	
	let data_index = "row" + String(temp_row + (now_page - 1) * 10) + "_col" + String(temp_col);
	
	return data_index;
}

////////////// 선택 초기화////////////////////////////
function Cell_Init(cell)
{
	let cell_text_id = cell + "_text_center";
	let data_index = Page_row_col_index_return(cell);
	
	delete check_value[data_index];
	webMI.data.write(addr_list[data_index] + "_Temp", previous_value[data_index]);
	click_cell = null;
	
	webMI.gfx.setText(cell_text_id, previous_value[data_index]);
	webMI.gfx.setFill(cell_text_id, color.Font_Default[color_mode]);
	
	Apply_active();
	webMI.gfx.setVisible("shadow_footer", true);
}

///////어플라이 버튼 활성화/비활성화///////////
function Apply_active()
{
	if (Object.keys(check_value).length > 0)	
	{
		webMI.trigger.fire("btn_active", "apply");
	}
	else
	{
		webMI.trigger.fire("btn_inactive", "apply");
	}	
}

////////////적용 버튼 클릭///////////////////////
webMI.addEvent("btn_apply", "click", function(e) {

	if (Object.keys(check_value).length == 0)	
	{
		return;
	}
	
	Click_Prevention("open")	
	
	let apply_popup = document.getElementById("apply_popup");  
	let prevention_level= 2;
	webMI.trigger.fire("Apply_Popup_prevention_level_Set",prevention_level);
	
	apply_popup.setAttribute("x", "700");
	apply_popup.setAttribute("y", "250");
});

///////////////////////////*  적용 확인 팝업 - 취소 버튼 클릭 이벤트  *///////////////////////////

webMI.trigger.connect("Apply_Popup_Cancel", function(e)
{
	Click_Prevention("close")
	
	let apply_popup = document.getElementById("apply_popup");  

	apply_popup.setAttribute("x", "0");
	apply_popup.setAttribute("y", "1000");	// 화면 밖으로
});

///////////////////////////*  적용 확인 팝업 - 적용 버튼 클릭 이벤트  *///////////////////////////

webMI.trigger.connect("Apply", function(e)
{
	for (let cell_id in check_value)	 // 확인 값 찾아오기
	{
		previous_value[cell_id] = check_value[cell_id];
	}

	webMI.data.write(apply_addr,1);	
	
	check_value = {};
	Apply_active();
	Table_Data();
});

/////////////권한 확인////////////////////////////////////////
function Prevention_Check(prevention_level, callback)
{
	webMI.trigger.fire("Prevention_Check", {level : prevention_level, callback : function(access)	
	{
		if (access == false)
		{
			webMI.trigger.fire("Info_Popup_Open", { title : "T{권한}", info : "T{해당 기능에 대한 권한이 없습니다.}" });
			return;
		}
		else
		{
			callback();
		}
	}});
}

///////////////////////////*  유저 매뉴얼 버튼 클릭 이벤트 *///////////////////////////

webMI.trigger.connect("UserManual_Open", function(e)
{
	
	Click_Prevention("open");
	let time_popup = document.getElementById("user_manual_popup");  

	time_popup.setAttribute("x", "603");		//960 -357 
	time_popup.setAttribute("y", "20");
	webMI.trigger.fire("UserManual_Move");
});

webMI.trigger.connect("UserManual_Close", function(e)
{
	Click_Prevention("close")
	let time_popup = document.getElementById("user_manual_popup");  
	time_popup.setAttribute("x", "0");
	time_popup.setAttribute("y", "1000");	// 화면 밖으로
});

///// 팝업 오픈 시 뒤에 클릭안되게 하는 화면 열기/닫기
function Click_Prevention(popup, paramter)
{
	if (popup == "open")
	{
		let shadow = document.getElementById("shadow");  
		if (paramter == undefined)
		{
			webMI.trigger.fire("Prevention_Open");	
		}
		else
		{
			webMI.trigger.fire("Prevention_Open",paramter);	
		}
		
		shadow.setAttribute("x", "0");
		shadow.setAttribute("y", "0");

	}
	else if (popup == "close")
	{
		let shadow = document.getElementById("shadow");  
		webMI.trigger.fire("Prevention_Close");
		
		shadow.setAttribute("x", "0");
		shadow.setAttribute("y", "-1000");	// 화면 밖으로

	}
}

//////현재 페이지 이외에서 팝업 요청 시 Shadow Visible, Invisible/////////////
webMI.trigger.connect("Prevention_req",function(e)
{
	let parameter = e.value.parameter;
	parameter = parameter == null ? undefined : parameter; 
	Click_Prevention(e.value.req, parameter);
});

//////////////////////////키패드 오픈//////////////////////////////////
webMI.trigger.connect("Keyboard_Open", function(e)
{
	var type = e.value.type;
	
	var options = {};	
	var max_len = 0;
	var password_on = false;
	
	if (e.value.type == "ID")
	{
		max_len =15;
		password_on =false;
	}
	else if(e.value.type == "PW")
	{
		max_len = 21;
		password_on = true;
	}	
	
	options["parameter"] = type;
	options["max_len"] = max_len;
	options["password_on"] = password_on;
	
	webMI.trigger.fire("keyboard_init", options);
	
	let popup = document.getElementById("popup_keyboard");  
	popup.setAttribute("x", "310");
	popup.setAttribute("y", "285");	
});
	
////////////////키보드 종료///////////////////////////
webMI.trigger.connect("Keyboard_Close", function(e)
{
	let popup = document.getElementById("popup_keyboard");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

//////////////////////////로그인 팝업창 오픈//////////////////////////////////
webMI.trigger.connect("Login_Open", function(e)
{
	Click_Prevention("open");
	webMI.trigger.fire("Login_Popup_init");
	
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("x", "602");
	popup.setAttribute("y", "213");	
});
	
////////////////로그인 팝업창 종료///////////////////////////
webMI.trigger.connect("Login_Close", function(e)
{
	Click_Prevention("close");
	
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

////////////////로그인 팝업창 올리기///////////////////////////
webMI.trigger.connect("Login_Popup_Up", function(e)
{
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("y", "20");	
});

////////////////로그인 팝업창 내리기///////////////////////////
webMI.trigger.connect("Login_Popup_Down", function(e)
{
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("y", "213");	
});

//////////////////////////정보 팝업창 오픈//////////////////////////////////
webMI.trigger.connect("Info_Popup_Open", function(e)
{
	Click_Prevention("open");
	webMI.trigger.fire("Info_Init",e.value);		
	
	let popup = document.getElementById("info_popup");  
	popup.setAttribute("x", "602");
	popup.setAttribute("y", "213");	
});
	
////////////////정보 팝업창 종료///////////////////////////
webMI.trigger.connect("Info_Popup_Close", function(e)
{
	Click_Prevention("close");
	
	let popup = document.getElementById("info_popup");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});	