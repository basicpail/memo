var color = webMI.query["color"];
let subscriptions = [];
var btn_data_location = webMI.gfx.getX("btn_data");
var btn_apply_location = webMI.gfx.getX("btn_apply");
var apply_addr = 
{
	1 : {
			"정렬" : "AGENT.OBJECTS.06_PROBE..Apply_Probe1_Alignment", 
			"테스트 트림" :  "AGENT.OBJECTS.06_PROBE..Apply_Probe1_TestTrim", 
			"피드백 보상인자" : "AGENT.OBJECTS.06_PROBE..Apply_Probe1_Feedback"
		},
	2 : {
			"정렬" : "AGENT.OBJECTS.06_PROBE..Apply_Probe2_Alignment", 
			"테스트 트림" :  "AGENT.OBJECTS.06_PROBE..Apply_Probe2_TestTrim", 
			"피드백 보상인자" : "AGENT.OBJECTS.06_PROBE..Apply_Probe2_Feedback"
		}
};

var probe_feedback_mode_addr = { 1 : "AGENT.OBJECTS.Control._Probe1_Feedback_Mode_DCU", 2 : "AGENT.OBJECTS.Control._Probe2_Feedback_Mode_DCU"};	
var probe_feedback_mode = {};

var probe1_fault;
var probe2_fault;

var dgs_mode;
var now_tab = "정렬";
var now_page;
var feedback_mode_manual = 0;		//// 0 : none, 1 : auto, 2 : manual

var isControllable;

var feedback_auto_popup_open = false;
var feedback_manual_popup_open = false;

let preClicked_cell = null;	// 이전 선택 셀
let nowClicked_cell = null; // 현재 선택 셀

let previousValues = {};  // 이전 값 저장
let checkValues = {};		// 확인 값 저장

var btn_dot_active = true;

var btn_feedback_auto_lamp = document.getElementById("btn_feedback_auto_lamp");
var btn_feedback_manual_lamp = document.getElementById("btn_feedback_manual_lamp");

var rowMapping =
{
	1: "V1", 2: "V2", 3: "V3", 4: "V4", 5: "V5",
	6: "V6", 7: "V7", 8: "V8", 9: "A1",  10: "A2",
	11: "A3", 12: "A4", 13: "A5", 14: "L1", 15: "L2",
	16: "L3", 17: "L4", 18: "L5", 19: "L6", 20: "L7",
	21: "L8", 22: "L9", 23: "L10", 24: "L11", 25: "L12"
};

var axis_Mapping =
{
	1: "V", 2: "A", 3: "L"
};

var iframe= webMI.rootWindow.document.querySelector("#page_main_myframe").contentWindow.document.body;

iframe.addEventListener("click", () => {
  localStorage.setItem("NoTouchCount",0);
});   

///////////////선택된 프로브 번호//////////////////////////////////////////
var select_Probe_num = 0;

//////////현재 페이지의 태그 주소//////////////
var data_addr_map = {};

/////////////////day, night 모드에 따른 색상 데이터////////////////////
var color_Line_Com_Normal;
var color_Purple;
var color_Font_Table_Data;
var color_BtnLamp_Off;
var color_Selected;
var color_Btn_Title_Down;
var color_Font_Selected_Title;
var color_Table_Title;
var color_Font_Default;
var color_Table_Cell_Background_Control;
var color_Table_Cell_Background_Monitoring;
var color_Main_Background;
var 	color_Bento;
var color_BtnLamp_On;
var color_Green_Active;
var color_Font_Selected_Data;

///////////////////////////*  주/야간 색상 변경 *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	color_Line_Com_Normal = color.Line_Com_Normal[color_mode];
	color_Purple = color.Purple[color_mode];
	color_Font_Table_Data = color.Font_Table_Data[color_mode];
	color_BtnLamp_Off = color.BtnLamp_Off[color_mode];
	color_Selected = color.Selected[color_mode];
	color_Btn_Title_Down = color.Btn_Title_Down[color_mode];
	color_Font_Selected_Title = color.Font_Selected_Title[color_mode];
	color_Table_Title = color.Table_Title[color_mode];
	color_Font_Default = color.Font_Default[color_mode];
	color_Table_Cell_Background_Control = color.Table_Cell_Background_Control[color_mode];
	color_Table_Cell_Background_Monitoring = color.Table_Cell_Background_Monitoring[color_mode];
	color_Main_Background = color.Main_Background[color_mode];
	color_Bento = color.Bento[color_mode];
	color_BtnLamp_On = color.BtnLamp_On[color_mode];
	color_Green_Active = color.Green_Active[color_mode];
	color_Font_Selected_Data = color.Font_Selected_Data[color_mode];
	
	webMI.gfx.setFill("background_display", color_Main_Background);
	
	webMI.gfx.setFill("bento_1", color_Bento);
	webMI.gfx.setFill("bento_2", color_Bento);
	webMI.gfx.setFill("bento_3", color_Bento);
	
	webMI.gfx.setFill("table_header", color_Table_Title);	
	webMI.gfx.setStroke("table_header", color.Table_Border[color_mode]);		
	
	webMI.gfx.setFill("lbl_probe", color_Font_Default);
	webMI.gfx.setFill("lbl_text1", color_Font_Default);
	webMI.gfx.setFill("lbl_text2", color_Font_Default);
	
	webMI.gfx.setFill("text_alignment", color_Font_Default);
	webMI.gfx.setFill("text_test_trim", color_Font_Default);
	webMI.gfx.setFill("text_feedback", color_Font_Default);
	webMI.gfx.setFill("text_page", color_Font_Default);
	
	webMI.gfx.setStroke("line_probe1", color_Line_Com_Normal);
	webMI.gfx.setStroke("line_probe2", color_Line_Com_Normal);
	webMI.gfx.setStroke("line_submarine1", color_Line_Com_Normal);
	webMI.gfx.setStroke("line_submarine2", color_Line_Com_Normal);
}

///////////////최초에 선택된 프로브가 없기에 우측 비활성화///////////////////
webMI.gfx.setX("no_select_shadow1", 818);
webMI.gfx.setX("no_select_shadow2", 818);
webMI.gfx.setX("btn_apply", 2000);
webMI.gfx.setX("btn_data",2000);

footer_shadow_visible();

/////////////정렬 탭 데이터 주소 초기 할당////////////////
for (let row = 1; row <= 3; row ++)
{
	let cell_id_page_col1_probe1 = `tb_row${row}_col1_` + "Align_1";
	let cell_id_page_col2_probe1 = `tb_row${row}_col2_` + "Align_1";
	let cell_id_page_col3_probe1 = `tb_row${row}_col3_` + "Align_1";
	
	let cell_id_page_col1_probe2 = `tb_row${row}_col1_` + "Align_2";
	let cell_id_page_col2_probe2 = `tb_row${row}_col2_` + "Align_2";
	let cell_id_page_col3_probe2 = `tb_row${row}_col3_` + "Align_2";
	
	data_addr_map[cell_id_page_col1_probe1] = "AGENT.OBJECTS.06_PROBE..Probe1.Permanent_"+ axis_Mapping[row];
	data_addr_map[cell_id_page_col2_probe1] = "AGENT.OBJECTS.06_PROBE..Probe1.Induced_"+ axis_Mapping[row];
	data_addr_map[cell_id_page_col3_probe1] = "AGENT.OBJECTS.06_PROBE..Probe1.Tilt_"+ axis_Mapping[row];
	
	data_addr_map[cell_id_page_col1_probe2] = "AGENT.OBJECTS.06_PROBE..Probe2.Permanent_"+ axis_Mapping[row];
	data_addr_map[cell_id_page_col2_probe2] = "AGENT.OBJECTS.06_PROBE..Probe2.Induced_"+ axis_Mapping[row];
	data_addr_map[cell_id_page_col3_probe2] = "AGENT.OBJECTS.06_PROBE..Probe2.Tilt_"+ axis_Mapping[row];
}

/////////////트림 탭 데이터 주소 초기 할당////////////////
for (let row = 1; row <= 3; row ++)
{
	let cell_id_page_col1_probe1 = `tb_row${row}_col1_` + "Trim_1";
	let cell_id_page_col2_probe1 = `tb_row${row}_col2_` + "Trim_1";
	
	let cell_id_page_col1_probe2 = `tb_row${row}_col1_` + "Trim_2";
	let cell_id_page_col2_probe2 = `tb_row${row}_col2_` + "Trim_2";

	data_addr_map[cell_id_page_col1_probe1] = "AGENT.OBJECTS.06_PROBE..Probe1.Internal_"+ axis_Mapping[row];
	data_addr_map[cell_id_page_col2_probe1] = "AGENT.OBJECTS.06_PROBE..Probe1.External_"+ axis_Mapping[row];
	
	data_addr_map[cell_id_page_col1_probe2] = "AGENT.OBJECTS.06_PROBE..Probe2.Internal_"+ axis_Mapping[row];
	data_addr_map[cell_id_page_col2_probe2] = "AGENT.OBJECTS.06_PROBE..Probe2.External_"+ axis_Mapping[row];
}

/////////////피드백 탭 데이터 주소 초기 할당////////////////
for (let row = 1; row <= 25; row ++)
{
	for (let col = 1; col <= 4; col++)
	{
		let axis = rowMapping[row];
		let sensor = axis_Mapping[col];
		let now_page_temp = Math.floor((row-1) / 10 + 1);
		let row_temp = row % 10;
		row_temp = row_temp == 0 ? 10 : row_temp;
		
		let cell_id_page_probe1 = `tb_row${row_temp}_col${col}` + "_Feedback_1_" + now_page_temp;
		
		let cell_id_page_probe2 = `tb_row${row_temp}_col${col}` + "_Feedback_2_" + now_page_temp;

		data_addr_map[cell_id_page_probe1] = (col != 4) ?
			`AGENT.OBJECTS.06_PROBE..Probe1_${axis}.${sensor}` :	// 데이터 주소 맵핑	
			`AGENT.OBJECTS.06_PROBE..Probe1_${axis}.Current`;			// 데이터 주소 맵핑	
		data_addr_map[cell_id_page_probe2] = (col != 4) ?
			`AGENT.OBJECTS.06_PROBE..Probe2_${axis}.${sensor}` :	// 데이터 주소 맵핑	
			`AGENT.OBJECTS.06_PROBE..Probe2_${axis}.Current`;			// 데이터 주소 맵핑	
	}
}

/////////////권한 확인////////////////////////////////////////
function Prevention_Check(prevention_level, callback)
{
	webMI.trigger.fire("Prevention_Check", {level : prevention_level, callback : function(access)	
	{
		if (access == false)
		{
			webMI.trigger.fire("Info_Popup_Open", { title : "T{권한}", info : "T{해당 기능에 대한 권한이 없습니다.}" });
			
			if (nowClicked_cell != null)
			{
				Cliked_Cell_Init();
			}			
			
			return;
		}
		else
		{
			callback();
		}
	}});
}

//////////////현재 클릭된 셀 초기화///////////////////////
function Cliked_Cell_Init()
{
	var nowClicked_cell_page = nowClicked_cell + '_' + now_page;
	var now_text = nowClicked_cell + "_text_center";
	
	if (checkValues[nowClicked_cell_page])	// 확인 값이 있는 경우
	{
		webMI.gfx.setText(now_text, checkValues[nowClicked_cell_page]);	// 다시 눌러도 확인 값 전시
		webMI.gfx.setFill(now_text, color_Green_Active);
	}
	else
	{
		webMI.gfx.setText(now_text, previousValues[nowClicked_cell_page]);
		
		if (dgs_mode == "비활성화" && (now_tab != "피드백 보상인자" || (now_tab == "피드백 보상인자" && feedback_mode_manual == 2)))
		{
			webMI.gfx.setFill(now_text, color_Font_Table_Data);				
		}
		else
		{
			webMI.gfx.setFill(now_text, color_Font_Default);				
		}		
	}
	
	nowClicked_cell = null;
	
	footer_shadow_visible();
}

///////////////////프로브1 연결 상태/////////////////////
webMI.data.subscribe("AGENT.OBJECTS.03_ALGOR..Probe1.Net_Total",function(e)
{
	probe1_connection = e.value;
	
	if (!probe1_connection)
	{
		webMI.gfx.setStroke("line_probe1", color_Line_Com_Normal);
		probe1_fault = false;
	}
	else
	{
		webMI.gfx.setStroke("line_probe1", color_Purple);
		probe1_fault = true;
	}
	
	if (probe1_fault && probe2_fault)
	{
		webMI.gfx.setStroke("line_submarine1", color_Purple);
		webMI.gfx.setStroke("line_submarine2", color_Purple);
	}
	else
	{
		webMI.gfx.setStroke("line_submarine1", color_Line_Com_Normal);
		webMI.gfx.setStroke("line_submarine2", color_Line_Com_Normal);
	}
});

///////////////프로브2 연결 상태/////////////////////
webMI.data.subscribe("AGENT.OBJECTS.03_ALGOR..Probe2.Net_Total",function(e)
{	
	probe2_connection = e.value;
	
	if (!probe2_connection)
	{
		webMI.gfx.setStroke("line_probe2", color_Line_Com_Normal);
		probe2_fault = false;
		
	}
	else
	{
		webMI.gfx.setStroke("line_probe2", color_Purple);
		
		probe2_fault = true;
	}
	
	if (probe1_fault && probe2_fault)
	{
		webMI.gfx.setStroke("line_submarine1", color_Purple);
		webMI.gfx.setStroke("line_submarine2", color_Purple);
	}
	else
	{
		webMI.gfx.setStroke("line_submarine1", color_Line_Com_Normal);
		webMI.gfx.setStroke("line_submarine2", color_Line_Com_Normal);
	}
});

///////////////////////////*  소자 모드 읽어오기  *///////////////////////////
// 소자 모드가 자동이거나 수동 -> 감시 모드
// 소자 모드가 비활성화 -> 제어 모드
webMI.data.read("AGENT.OBJECTS.SIM_OBJECTS.02.Degaussing.Degaussing_Mode._DGM",function(e)
//webMI.data.read("AGENT.OBJECTS.Control._DGM",function(e)
{
	if (e.value == 1)
	{
		dgs_mode = "수동";
		
		webMI.trigger.fire("btn_inactive", "Probe_auto");
		webMI.trigger.fire("btn_inactive", "Probe_manual");
		
		isControllable = false;
	}
	else if (e.value == 2)
	{
		dgs_mode = "자동";
		
		webMI.trigger.fire("btn_inactive", "Probe_auto");
		webMI.trigger.fire("btn_inactive", "Probe_manual");
		
		isControllable = false;
	}
	else if (e.value == 3)
	{
		dgs_mode = "비활성화";
		
		webMI.trigger.fire("btn_active", "Probe_auto");
		webMI.trigger.fire("btn_active", "Probe_manual");
		
		isControllable = true;
	}
	
	Change_Tab(1);
});

///////////////////////////*  탭 버튼 클릭 이벤트 *///////////////////////////

webMI.addEvent("btn_alignment", "click", function(e)
{
	previousValues = {};
	Change_Tab(1);
	Change_Table_First_Col();
	Tab_Alignment();
	Apply_Active();
});


webMI.addEvent("btn_test_trim", "click", function(e)
{
	previousValues = {};
	Change_Tab(2);
	Change_Table_First_Col();
	Tab_Testtrim();
	Apply_Active();
});


webMI.addEvent("btn_feedback", "click", function(e)
{
	previousValues = {};
	feedback_mode_manual = 0;
	Change_Tab(3);
	Change_Table_First_Col();
	Tab_Feedback();
	Apply_Active();
});


///////////////////////////*  탭 변경 함수 *///////////////////////////

function Change_Tab(tab)
{
	if (nowClicked_cell)	// 셀 선택된 채로 탭 이동 시 선택 취소
	{
		nowClicked_cell = null;
	}
	
	checkValues = {};	// 확인 값 초기화

	for (i = 1; i <= 10; i ++)
	{
		for (j = 1; j <= 4; j++)
		{
			if (dgs_mode == "비활성화" && (now_tab != "피드백 보상인자" || (now_tab == "피드백 보상인자" && feedback_mode_manual == 2)))
			{
				webMI.gfx.setFill(`tb_row${i}_col${j}_text_center`, color_Font_Table_Data);				
			}
			else
			{
				webMI.gfx.setFill(`tb_row${i}_col${j}_text_center`, color_Font_Default);					
			}					
		}
	}
	
	webMI.gfx.setFill(btn_feedback_auto_lamp, color_BtnLamp_Off);
	webMI.gfx.setFill(btn_feedback_manual_lamp, color_BtnLamp_Off);
	
	if (feedback_auto_popup_open)
	{
		Popup_Close("auto");
	}
	else if (feedback_manual_popup_open)
	{
		Popup_Close("manual");
	}
	
	// 버튼 상태 일괄 설정 함수
	let setButtonState = function(alignment, testTrim, feedback)
	{
		webMI.gfx.setStroke("btn_alignment_background", alignment.stroke);
		webMI.gfx.setFill("btn_alignment_background", alignment.fill);
		webMI.gfx.setFill("text_alignment", alignment.text);

		webMI.gfx.setStroke("btn_test_trim_background", testTrim.stroke);
		webMI.gfx.setFill("btn_test_trim_background", testTrim.fill);
		webMI.gfx.setFill("text_test_trim", testTrim.text);

		webMI.gfx.setStroke("btn_feedback_background", feedback.stroke);
		webMI.gfx.setFill("btn_feedback_background", feedback.fill);
		webMI.gfx.setFill("text_feedback_status", feedback.text);
	};
	
	switch(tab)
	{
		case 1:			
			setButtonState(
				{ stroke: color_Selected, fill: color_Btn_Title_Down, text: color_Font_Selected_Title },
				{ stroke: color_Table_Title, fill: color_Table_Title, text: color_Font_Default },
				{ stroke: color_Table_Title, fill: color_Table_Title, text: color_Font_Default }
			);
			
			header_alignment_visible();
			header_test_trim_hidden();
			header_feedback_hidden();
			
			footer_shadow_visible();
			page_hidden();
			feedback_mode_hidden();
			 
			if (dgs_mode == "비활성화")	// 소자 모드가 비활성화 : 제어 가능(검은색)
			{
				if (select_Probe_num > 0)
				{
					webMI.gfx.setX("btn_apply", btn_apply_location);
					webMI.gfx.setX("btn_data",btn_data_location);
				}
				
				for (let row = 1; row <= 10; row++)	// 모든 셀 배경 검은색
				{
					for (let col = 1; col <= 4; col++)
					{
						let background = document.getElementById(`tb_row${row}_col${col}_background`);
						webMI.gfx.setFill(background, color_Table_Cell_Background_Control);
					}
				}
			}
			else	// 소자 모드가 자동/수동 : 감시(회색)
			{
				webMI.gfx.setX("btn_apply", 2000);
				webMI.gfx.setX("btn_data",2000);
				webMI.trigger.fire("btn_inactive", "probe_data");
				webMI.trigger.fire("btn_inactive", "probe_apply");
				
				for (let row = 1; row <= 10; row++)
				{
					for (let col = 1; col <= 4; col++)
					{
						let background = document.getElementById(`tb_row${row}_col${col}_background`);
						
						if (background)
						{
							if (row <= 3 && col <= 3)
							{
								webMI.gfx.setFill(background, color_Table_Cell_Background_Monitoring);
							}
							else
							{
								webMI.gfx.setFill(background, color_Table_Cell_Background_Control);
							}
						}
					}
				}
			}

			now_tab = "정렬";
			now_page = "Align" + "_" + select_Probe_num;
			break;
		case 2:
			setButtonState(
				{ stroke: color_Table_Title, fill: color_Table_Title, text: color_Font_Default },
				{ stroke: color_Selected, fill: color_Btn_Title_Down, text: color_Font_Selected_Title },
				{ stroke: color_Table_Title, fill: color_Table_Title, text: color_Font_Default }
			);
			
			header_alignment_hidden();
			header_test_trim_visible();
			header_feedback_hidden();
			
			footer_shadow_visible();
			page_hidden();
			feedback_mode_hidden();
			
			if (dgs_mode == "비활성화")	// 제어 가능 검은색
			{
				if (select_Probe_num > 0)
				{
					webMI.gfx.setX("btn_apply", btn_apply_location);
					webMI.gfx.setX("btn_data",btn_data_location);
				}
			
				
				for (let row = 1; row <= 10; row++)
				{
					for (let col = 1; col <= 4; col++)
					{
						let background = document.getElementById(`tb_row${row}_col${col}_background`);
						webMI.gfx.setFill(background, color_Table_Cell_Background_Control);
					}
				}
			}
			else	// 감시 회색
			{
				webMI.gfx.setX("btn_apply", 2000);
				webMI.gfx.setX("btn_data",2000);
				webMI.trigger.fire("btn_inactive", "probe_data");
				webMI.trigger.fire("btn_inactive", "probe_apply");
				
				for (let row = 1; row <= 10; row++)
				{
					for (let col = 1; col <= 4; col++)
					{
						let background = document.getElementById(`tb_row${row}_col${col}_background`);
						
						if (background)
						{
							if (row <= 3 && col <= 2)
							{
								webMI.gfx.setFill(background, color_Table_Cell_Background_Monitoring);
							}
							else
							{
								webMI.gfx.setFill(background, color_Table_Cell_Background_Control);
							}
						}
					}
				}
			}
			
			now_tab = "테스트 트림";
			now_page = "Trim" + "_" + select_Probe_num;
			break;
		case 3:
			setButtonState(
				{ stroke: color_Table_Title, fill: color_Table_Title, text: color_Font_Default },
				{ stroke: color_Table_Title, fill: color_Table_Title, text: color_Font_Default },
				{ stroke: color_Selected, fill: color_Btn_Title_Down, text: color_Font_Selected_Title }
			);
			
			webMI.gfx.setFill("btn_next_page_label_center", "#ffffff");	// 페이지 로드 시 자동, 수동 버튼 램프 라벨, 페이지 라벨 깜빡이는 것 때문에 넣음
			webMI.gfx.setX("btn_apply", 2000);
			webMI.gfx.setX("btn_data",2000);

			if (dgs_mode == "비활성화")
			{
				webMI.trigger.fire("btn_active", "Probe_auto");
				webMI.trigger.fire("btn_active", "Probe_manual");
			}
			else
			{
				webMI.trigger.fire("btn_inactive", "Probe_auto");
				webMI.trigger.fire("btn_inactive", "Probe_manual");
			}

			header_alignment_hidden();
			header_test_trim_hidden();
			header_feedback_visible();
			
			if (select_Probe_num > 0)
			{
				page_visible();
				feedback_mode_visible();
			}
			else
			{
				feedback_mode_hidden();
			}
			
			if (feedback_mode_manual == 2)
			{
				webMI.gfx.setX("btn_data",btn_data_location);
			}			
			else
			{
				webMI.gfx.setX("btn_data",2000);
			}
			
			footer_shadow_visible();
			
			feedback_mode_manual = 0;			
			now_tab = "피드백 보상인자";	
			now_page = "Feedback_" + select_Probe_num +"_1"; 
			const text_page = document.getElementById("text_page");
			webMI.gfx.setText(text_page, "01 | 03");
			webMI.trigger.fire("btn_active", "next_page");
			webMI.trigger.fire("btn_inactive", "pre_page");
			
			break;
	}
}


///////////////////////////*  테이블 첫 열(축) 텍스트 변경  *///////////////////////////

function Change_Table_First_Col()
{
	if (now_tab == "피드백 보상인자")
	{
		let row_offset = (Number(now_page.slice(-1)) - 1) * 10;
		
		for (let row = 1; row <= 10; row++)
		{	
			if (rowMapping[row + row_offset] != undefined)
			{
				webMI.gfx.setText("tb_row" + row + "_text_center", rowMapping[row + row_offset]);
			}
			else
			{
				webMI.gfx.setText("tb_row" + row + "_text_center", "");
			}
		}
	}
	else	// 정렬 탭, 테스트 트림 탭
	{
		webMI.gfx.setText("tb_row1_text_center", "V");
		webMI.gfx.setText("tb_row2_text_center", "A");
		webMI.gfx.setText("tb_row3_text_center", "L");
		
		webMI.gfx.setText("tb_row4_text_center", "");
		webMI.gfx.setText("tb_row5_text_center", "");
		webMI.gfx.setText("tb_row6_text_center", "");
		webMI.gfx.setText("tb_row7_text_center", "");
		webMI.gfx.setText("tb_row8_text_center", "");
		webMI.gfx.setText("tb_row9_text_center", "");
		webMI.gfx.setText("tb_row10_text_center", "");
	}
}

///////////////////////////*  페이지 Next 버튼 클릭 이벤트 *///////////////////////////

webMI.addEvent("btn_next_page", "click", function(e)
{
	let page_num = Number(now_page.slice(-1));
	
	if (now_tab != "피드백 보상인자" || page_num == 3)
	{
		return;
	}

	if (nowClicked_cell != null)	// 셀 선택된 채로 페이지 이동 시 선택 취소
	{
		nowClicked_cell = null;
	}

	const text_page = document.getElementById("text_page");

	if (page_num == 1)
	{
		now_page = "Feedback_" +select_Probe_num+ "_2";
		webMI.gfx.setText(text_page, "02 | 03");
		webMI.trigger.fire("btn_active", "pre_page");
		webMI.trigger.fire("btn_active", "next_page");
	}
	else if (page_num == 2)
	{
		now_page = "Feedback_" +select_Probe_num+ "_3";
		webMI.gfx.setText(text_page, "03 | 03");
		webMI.trigger.fire("btn_active", "pre_page");
		webMI.trigger.fire("btn_inactive", "next_page");
	}
	
	nowClicked_cell = null;
	footer_shadow_visible();	
	
	Tab_Feedback();
});

///////////////////////////*  페이지 Pre 버튼 클릭 이벤트 *///////////////////////////
webMI.addEvent("btn_pre_page", "click", function(e)
{
	let page_num = Number(now_page.slice(-1));
	
	if (now_tab != "피드백 보상인자" || page_num == 1)
	{
		return;
	}
		
	if (nowClicked_cell != null)	// 셀 선택된 채로 페이지 이동 시 선택 취소
	{
		nowClicked_cell = null;
	}
	
	const text_page = document.getElementById("text_page");
	
	if (page_num == 2)
	{
		now_page = "Feedback_" +select_Probe_num+ "_1";
		webMI.gfx.setText(text_page, "01 | 03");
		webMI.trigger.fire("btn_inactive", "pre_page");
		webMI.trigger.fire("btn_active", "next_page");
	}
	else if (page_num == 3)
	{
		now_page = "Feedback_" +select_Probe_num+ "_2";
		webMI.gfx.setText(text_page, "02 | 03");
		webMI.trigger.fire("btn_active", "pre_page");
		webMI.trigger.fire("btn_active", "next_page");
	}
	
	nowClicked_cell = null;
	footer_shadow_visible();		
	
	Tab_Feedback();
});


///////////////////////////*  정렬 탭  *///////////////////////////

function Tab_Alignment()
{
	if (subscriptions.length != 0)
	{
		subscriptions.forEach(id => webMI.data.unsubscribe(id));
		subscriptions = []; // 구독 취소
	}

	for (let row = 1; row <= 10; row++)
	{
		for (let col = 1; col <= 4; col++)
		{
			(function(row, col)
			{
				let cell_id = `tb_row${row}_col${col}`;
				let cell_id_page = cell_id + "_" + now_page;
				let text = `tb_row${row}_col${col}_text_center`;
				let data_addr = data_addr_map[cell_id_page];
				let dot_num = (col == 1 || col == 2) ? 2 : 1;					// 소수점 자리수 계산	
								
				if (data_addr != undefined)
				{
					if (dgs_mode == "비활성화")
					{
						webMI.gfx.setFill(text, color_Font_Table_Data);	
						webMI.data.read(data_addr, function(e)
						{
							AlingData(dot_num, e.value, text, cell_id_page, data_addr);
						});
					}
					else
					{
						webMI.gfx.setFill(text, color_Font_Default);					
						let subId = webMI.data.subscribe(data_addr, function(e)
						{
							AlingData(dot_num, e.value, text, cell_id_page, data_addr);
						});
						
						subscriptions.push(subId); // 구독 ID 저장
					}
				}
				else
				{
					webMI.gfx.setText(text, "");	// 나머지 셀은 공백 처리
				}
			})(row, col);
		}
	}
	webMI.trigger.fire("btn_active", "dot");
	btn_dot_active = true;
}

function AlingData(dot_num, val, text, cell_id_page, data_addr)
{
	preValue = parseFloat(val.toFixed(dot_num));
	
	previousValues[cell_id_page] = Number(preValue);     // 처음 읽어온 값을 이전 값으로 저장(탭/페이지 번호 포함)

	if (checkValues[cell_id_page] != undefined)
	{
		webMI.gfx.setText(text, checkValues[cell_id_page]);	// 확인 값 있는 경우 확인 값 전시
		webMI.data.write(data_addr + "_Temp", Number(checkValues[cell_id_page]));
		webMI.gfx.setFill(text, color_Green_Active);
	}
	else
	{
		webMI.gfx.setText(text, preValue);
		webMI.data.write(data_addr + "_Temp", preValue);				//수정필	
	}
}

///////////////////////////*  테스트 트림 탭  *///////////////////////////

function Tab_Testtrim()
{
	if (subscriptions.length != 0)
	{
		subscriptions.forEach(id => webMI.data.unsubscribe(id));
		subscriptions = []; // 구독 취소
	}

	for (let row = 1; row <= 10; row++)
	{
		for (let col = 1; col <= 4; col++)
		{
			(function(row, col)
			{
				let cell_id = `tb_row${row}_col${col}`;
				let text = `tb_row${row}_col${col}_text_center`;
				let cell_id_page = cell_id + '_' + now_page;		// 현재 페이지 포함 셀 아이디
				let data_addr = data_addr_map[cell_id_page];
				let dot_num = (col == 1) ? 2 : 1;					// 소수점 자리수 계산	
				
				if (data_addr != undefined)
				{
					if (dgs_mode == "비활성화")
					{
						webMI.gfx.setFill(text, color_Font_Table_Data);				
						webMI.data.read(data_addr, function(e)
						{
							TesttrimData(dot_num, e.value, text, cell_id_page, data_addr);
						});
					}
					else
					{
						webMI.gfx.setFill(text, color_Font_Default);	
						let subId = webMI.data.subscribe(data_addr, function(e)
						{
							TesttrimData(dot_num, e.value, text, cell_id_page, data_addr);
						});
						
						subscriptions.push(subId); // 구독 ID 저장
					}
				}
				else
				{
					webMI.gfx.setText(text, "");	// 나머지 셀은 공백 처리
				}
			})(row, col);
		}
	}
	webMI.trigger.fire("btn_active", "dot");
	btn_dot_active = true;
}

function TesttrimData(dot_num, val, text, cell_id_page, data_addr)
{
	let preValue = parseFloat(val.toFixed(dot_num));
	
	previousValues[cell_id_page] = Number(preValue);     // 처음 읽어온 값을 이전 값으로 저장(탭/페이지 번호 포함)

	if (checkValues[cell_id_page] != undefined)
	{
		webMI.gfx.setText(text, checkValues[cell_id_page]);	// 확인 값 있는 경우 확인 값 전시
		webMI.data.write(data_addr + "_Temp", Number(checkValues[cell_id_page]));
		webMI.gfx.setFill(text, color_Green_Active);
	}
	else
	{
		webMI.gfx.setText(text, preValue);
		webMI.data.write(data_addr + "_Temp", preValue);				//수정필	
	}
}

///////////////////////////*  피드백 보상인자 탭  *///////////////////////////

function Tab_Feedback()
{
	if (subscriptions.length != 0)
	{
		subscriptions.forEach(id => webMI.data.unsubscribe(id));
		subscriptions = []; // 구독 취소
	}

	Change_Table_First_Col();		// 테이블 첫 열 텍스트

	let page_num = Number(now_page.slice(-1));
		
	for (let row = 1; row <= 25; row++)
	{			
		for (let col = 1; col <= 4; col++)
		{
			//////////////배경색 및 글자 색 지정///////////////////////
			if (row <= 10)
			{
				if (dgs_mode == "비활성화" && feedback_mode_manual == 2)
				{
					webMI.gfx.setFill(`tb_row${i}_col${j}_text_center`, color_Font_Table_Data);				
				}
				else
				{
					webMI.gfx.setFill(`tb_row${i}_col${j}_text_center`, color_Font_Default);				
				}		
				
				webMI.gfx.setText(`tb_row${row}_col${col}_text_center`, "");
				
				//수동모드 여부에 따라 배경색 변경
				if (feedback_mode_manual == 2)
				{
					webMI.gfx.setFill(`tb_row${row}_col${col}_background`, color_Table_Cell_Background_Control);
				}
				else
				{
					webMI.gfx.setFill(`tb_row${row}_col${col}_background`, color_Table_Cell_Background_Monitoring);
				}
				
				// 행에 따라 축 설정
				if ((page_num == 3) && ((row >= 6) && (row <= 10)))
				{
					webMI.gfx.setFill(`tb_row${row}_col${col}_background`, color_Table_Cell_Background_Control);
				}	
			}

			let row_offset = (page_num - 1) * 10; 
			let text = `tb_row${row - row_offset}_col${col}_text_center`;
			let background = `tb_row${row - row_offset}_col${col}_background`;	
						
			let now_page_temp = Math.floor((row-1) / 10 + 1);
			let row_temp = row % 10;
			row_temp = row_temp == 0 ? 10 : row_temp;		
				
			let cell_id_page = `tb_row${row_temp}_col${col}` + "_" + "Feedback_" + select_Probe_num +"_" +  now_page_temp;	 
				
			let data_addr = data_addr_map[cell_id_page];
			
			if (data_addr != undefined)
			{
				if (dgs_mode != "비활성화" || feedback_mode_manual != 2)
				{	
					let subId = webMI.data.subscribe(data_addr, function(e)
					{
						FeedbackData(e.value, text, cell_id_page, data_addr);
					});
					
					subscriptions.push(subId); // 구독 ID 저장
				}
				else
				{
					webMI.data.read(data_addr, function(e)
					{
						FeedbackData(e.value, text, cell_id_page, data_addr);
					});
				}	
			}
		}
	}
	
	webMI.trigger.fire("btn_inactive", "dot");
	btn_dot_active = false;
}

function FeedbackData(value, text, cell_id_page, data_addr)
{
	if (previousValues[cell_id_page] == undefined)
	{
		previousValues[cell_id_page] = Number(value);     // 처음 읽어온 값을 이전 값으로 저장(탭/페이지 번호 포함)
	}
	else
	{
		if (dgs_mode == "비활성화" && feedback_mode_manual == 2)
		{
			value = previousValues[cell_id_page];
		}	
	}

	///////////////////////체크 값이 있는지 확인 ////////////////////////
	if (checkValues[cell_id_page] != undefined)
	{
		webMI.gfx.setText(text, checkValues[cell_id_page]);	// 확인 값 있는 경우 확인 값 전시
		webMI.gfx.setFill(text, color_Green_Active);
		webMI.data.write(data_addr + "_Temp", Number(checkValues[cell_id_page]));
	}
	else
	{
		webMI.gfx.setText(text, value);	// 확인 값 없는 경우 읽어온 값 전시
		
		webMI.data.write(data_addr + "_Temp", value);

		if (dgs_mode == "비활성화" && feedback_mode_manual == 2)
		{
			webMI.gfx.setFill(text, color_Font_Table_Data);				
		}
		else
		{
			webMI.gfx.setFill(text, color_Font_Default);				
		}		
	}
}


/////////////////// 데이터가 있는 모든 셀의 색상을 노말 색으로 변경
function Cell_Font_Color_Init()
{
	//////////// 셀 색상 초기화 ///////////////////////
	for (let row = 1; row <= 10; row++)	// 데이터 셀 제어 색상
	{
		for (let col = 1; col <= 4; col++)
		{
			let cell_text = `tb_row${row}_col${col}_text_center`;
			
			if (dgs_mode == "비활성화" && (now_tab != "피드백 보상인자" || (now_tab == "피드백 보상인자" && feedback_mode_manual == 2)))
			{
				webMI.gfx.setFill(cell_text, color_Font_Table_Data);				
			}
			else
			{
				webMI.gfx.setFill(cell_text, color_Font_Default);				
			}					
		}
	}	
}

///////////////////////////*  피드백 보상모드 자동 클릭 이벤트  *///////////////////////////

webMI.addEvent("btn_feedback_auto", "click", function(e)
{
	if (dgs_mode == "비활성화")
	{
		if (feedback_mode_manual != 1)
		{
			webMI.gfx.setX("btn_data",2000);
			webMI.gfx.setX("btn_apply",2000);
			feedback_mode_manual = 1;
			webMI.gfx.setFill(btn_feedback_manual_lamp, color_BtnLamp_Off);	// 수동 버튼 램프 off
			
			if (feedback_manual_popup_open)
			{
				Popup_Close("manual");	// 수동 팝업 열려있는 경우 수동 팝업 닫기
			}
			
			webMI.gfx.setFill(btn_feedback_auto_lamp, color_BtnLamp_On);	// 자동 버튼 램프 on
			
			checkValues = {};	// 확인 값 초기화				
			
			Tab_Feedback();

			feedback_auto_popup_open = true;
			
			///////글자 색 기본값으로 변경///////////
			Cell_Font_Color_Init();
			
			// 자동 팝업 열기
			Popup_Open("auto");	
		}
		else	// 자동 모드 켜진 상태에서 한 번 더 누르는 경우 꺼짐
		{
			webMI.gfx.setX("btn_data",2000);
			feedback_mode_manual = 0;
			webMI.gfx.setFill(btn_feedback_auto_lamp, color_BtnLamp_Off);	// 자동 버튼 램프 on
			Popup_Close("auto");	// 자동 팝업 닫기
		}
	}
	
	Apply_Active();
});

/////////////////Apply 버튼 활성화 비활성화//////////////
function Apply_Active()
{
	if (Object.keys(checkValues).length > 0)	
	{
		webMI.trigger.fire("btn_active", "probe_apply");
	}
	else
	{
		webMI.trigger.fire("btn_inactive", "probe_apply");
	}
}

///////////////////////////*  피드백 보상모드 수동 클릭 이벤트  *///////////////////////////

webMI.addEvent("btn_feedback_manual", "click", function(e)
{
	if (dgs_mode == "비활성화")
	{
		webMI.gfx.setX("btn_apply",btn_apply_location);
		////////////////////////////
		if (feedback_mode_manual != 2)
		{
			previousValues = {};
			
			webMI.gfx.setX("btn_data",btn_data_location);
			feedback_mode_manual = 2;
			webMI.gfx.setFill(btn_feedback_auto_lamp, color_BtnLamp_Off);	// 자동 버튼 램프 off

			if (feedback_auto_popup_open)
			{
				Popup_Close("auto");	// 자동 팝업 열려있는 경우 자동 팝업 닫기
			}
			
			Popup_Open("manual");	// 수동 팝업 열기
		
			webMI.gfx.setFill(btn_feedback_manual_lamp, color_BtnLamp_On);	// 수동 버튼 램프 on
			
			Tab_Feedback();
			
			/////////글자색 기본 값으로 변경/////////////////////
			Cell_Font_Color_Init();
		}
		else	// 수동 모드 켜진 상태에서 한 번 더 누르는 경우 꺼짐
		{
			feedback_mode_manual = 0;
			webMI.gfx.setFill(btn_feedback_manual_lamp, color_BtnLamp_Off);	// 수동 버튼 램프 off
			Popup_Close("manual");
			webMI.gfx.setX("btn_apply", 2000);
			webMI.gfx.setX("btn_data",2000);
			
			Tab_Feedback();
			
			checkValues = {};	// 확인 값 초기화
			
			/////////글자색 기본 값으로 변경/////////////////////
			Cell_Font_Color_Init();
		}
	}
	
	Apply_Active();
});


///////////////////////////*  피드백 보상모드 자동/수동 팝업 열림  *///////////////////////////

function Popup_Open(option)
{
	if (option == "auto")
	{
		let feedback_auto_popup = document.getElementById("feedback_auto_popup");  
		webMI.trigger.fire("Probe_Feedback_Auto_Init",{probe_num : select_Probe_num});
		feedback_auto_popup.setAttribute("x", "10.837");
		feedback_auto_popup.setAttribute("y", "624.197");
		
		feedback_auto_popup_open = true;
	}
	else if (option == "manual")
	{
		let feedback_manual_popup = document.getElementById("feedback_manual_popup");  
		
		feedback_manual_popup.setAttribute("x", "12.1034");
		feedback_manual_popup.setAttribute("y", "625.372");
		
		feedback_manual_popup_open = true;
		
		webMI.trigger.fire("Probe_Feedback_Manual_Init", {probe_num : select_Probe_num});
	}
	else if (option == "apply")	// 확인 팝업 텍스트 변경
	{
		if (now_tab == "정렬")
		{
			webMI.gfx.setText("apply_popup_lbl_title", "T{3축 자기센서 프로브} T{정렬}");
		}
		else if (now_tab == "테스트 트림")
		{
			webMI.gfx.setText("apply_popup_lbl_title", "T{3축 자기센서 프로브} T{테스트 트림}");
		}
		else if (now_tab == "피드백 보상인자")
		{
			webMI.gfx.setText("apply_popup_lbl_title", "T{3축 자기센서 프로브} T{피드백 보상인자}");
		}
		
		Click_Prevention("open");	// 팝업 열릴 때 뒤에 클릭 방지
	
		let apply_popup = document.getElementById("apply_popup");  
		let prevention_level= 2;
		webMI.trigger.fire("Apply_Popup_prevention_level_Set",prevention_level);				///Apply 팝업창에 Apply 가능 권한 레벨 할당
		
		apply_popup.setAttribute("x", "700");
		apply_popup.setAttribute("y", "250");
		
	}
}


///////////////////////////*  피드백 보상모드 자동/수동 팝업 닫힘  *///////////////////////////

function Popup_Close(option)
{
	if (option == "auto")
	{
		let feedback_auto_popup = document.getElementById("feedback_auto_popup");  
		
		feedback_auto_popup.setAttribute("x", "-1000");
		feedback_auto_popup.setAttribute("y", "-1000");
		
		feedback_auto_popup_open = false;
		
		webMI.trigger.fire("Probe_Feedback_Auto_Unsubscribe");
	}
	else if (option == "manual")
	{
		let feedback_manual_popup = document.getElementById("feedback_manual_popup");  
		
		feedback_manual_popup.setAttribute("x", "-1000");
		feedback_manual_popup.setAttribute("y", "-1000");

		feedback_manual_popup_open = false;
		
		webMI.trigger.fire("Probe_Feedback_Manual_Unsubscribe");
	}
}

///////////////////////////*  footer 버튼 클릭 이벤트 *///////////////////////////

function FooterButtonClickEvents_coeff(buttonIds)
{
	buttonIds.forEach(buttonId =>
	{
		webMI.addEvent(buttonId, "click", function(e)
		{
			let clickedButton = e.target.id.replace('btn_', '').replace('_btn_click', '');
			let now_content = webMI.gfx.getText(nowClicked_cell + "_text_center");
			let now_text = nowClicked_cell + "_text_center";
			
			nowClicked_cell_page = nowClicked_cell +"_" + now_page;

			if (nowClicked_cell != null)	// 클릭된 셀이 있는 경우
			{
				if (clickedButton >= 0) // 숫자 버튼
				{
					if (now_content == "0")	// 05 -> 5
					{
						now_content = clickedButton;
					}
					else if (/\d/.test(now_content) || now_content[0] == '-')	// 숫자가 있거나 마이너스 부호가 있는 경우
					{
						now_content += clickedButton;
					}
					else
					{
						now_content = clickedButton; // 숫자 아니면 초기화 후 입력
					}
				
					// 자리수 포맷에 따라 조건 설정
					var split_str = now_content.split('.');
					var max_integer_length = 0;
					var max_decimal_length = 0;
					var max_length = 0;
				
					var digitPattern = Digit_Count(nowClicked_cell_page);
				
					if (digitPattern == '_ _ _ . _ _')
					{
						max_integer_length = 3;
						max_decimal_length = 2;
					}
					else if (digitPattern == '_ _ _ . _')		// 정렬 - 기울기
					{
						max_integer_length = 3;
						max_decimal_length = 1;
					}
					else if (digitPattern == '_ _ _ . _ _ _')	// 테스트 트림 - 외부
					{
						max_integer_length = 3;
						max_decimal_length = 3;
					}
					else if (digitPattern == '_ _ _ _')	// 피드백 보상인자
					{
						max_length = 4;
					}
					
					if (max_length > 0)	// 피드백 보상인자(정수 4자리)
					{
						let number = now_content.replace(/[^0-9\-]/g, '');
						
						if (number.startsWith("-"))
						{
							number = number.slice(0, max_length + 1);
						}
						else
						{
							number = number.slice(0, max_length);
						}
						now_content = number;
					}
					else
					{
						if (split_str[0][0] == '-')
						{
							split_str[0] = split_str[0].slice(0, max_integer_length + 1);
						}
						else
						{
							split_str[0] = split_str[0].slice(0, max_integer_length);
						}
				
						if (split_str.length == 2)
						{
							split_str[1] = split_str[1].slice(0, max_decimal_length);
							now_content = split_str[0] + '.' + split_str[1];
						}
						else
						{
							now_content = split_str[0];
						}
					}
					
					webMI.gfx.setText(now_text, now_content);
				}


				else if (clickedButton == "plus")	// + 버튼
				{
					if (now_content[0] == '-')
					{
						now_content = now_content.substring(1);		// 첫 글자 제거 후 다시 저장
						webMI.gfx.setText(now_text, now_content);  // 업데이트된 값 설정
						
						if (now_content.length === 0)
						{
							webMI.gfx.setText(now_text, Digit_Count(nowClicked_cell_page));
						}
					}
				}
				else if (clickedButton == "minus")	// - 버튼
				{
					if (now_content[0] != '-')
					{
						if (!/\d/.test(now_content))	// 선택된 텍스트에 숫자 포함 x
						{
							now_content = '';
							webMI.gfx.setText(now_text, now_content);
						}
						webMI.gfx.setText(now_text, '-' + now_content);
					}
				}
				else if (clickedButton == "dot")	// . 버튼
				{
					if (btn_dot_active == true)	// 피드백 보상인자 탭에서는 정수만 입력
					{
						if (!/\d/.test(now_content))	// 선택된 텍스트에 숫자 포함 x
						{
							now_content = '0';
						}
						else if (!now_content.includes('.'))
						{
							if(now_content == '-')
							{
								now_content = '-0';
							}
						}
						webMI.gfx.setText(now_text, now_content + '.');
					}
				}
				else if (clickedButton == "backspace")		// 백스페이스 버튼
				{
					if (/\d/.test(now_content) || now_content == '-')
					{
						now_content = now_content.slice(0, -1);
						webMI.gfx.setText(now_text, now_content);
					}
					if (now_content == '')
					{
						webMI.gfx.setText(now_text, Digit_Count(nowClicked_cell_page));
					}
				}
				else if (clickedButton == "reset")		// 초기화 버튼
				{
					var temp_prevention_level = 2;
					Prevention_Check(temp_prevention_level, () => {
						webMI.gfx.setText(now_text, previousValues[nowClicked_cell_page]);	// 이전 값으로 변경
						webMI.gfx.setFill(now_text, color_Font_Table_Data);	// 텍스트 색상 원래대로
						nowClicked_cell = null;
						preClicked_cell = null;
						footer_shadow_visible();
						
						delete checkValues[nowClicked_cell_page];
						
						webMI.data.write(data_addr_map[nowClicked_cell_page] + "_Temp", previousValues[nowClicked_cell_page]);	
					});	
					
					Apply_Active();
				}
				else if (clickedButton == "check")	// 확인 버튼
				{
					var temp_prevention_level = 2;
					Prevention_Check(temp_prevention_level, () => {
						if (!/\d/.test(now_content))		// 아무것도 쓰지 않고 확인 버튼 누르는 경우 이전 값
						{
							now_content = previousValues[nowClicked_cell_page];
						}
						else if (now_content.slice(-1) == '.')
						{
							now_content = now_content.slice(0, -1);
						}
						
						 // 소수점 뒤 0 제거 처리
						let value = parseFloat(now_content); // 숫자 형태로 변환
						now_content = value.toString(); // 불필요한 0을 제거한 문자열로 변환
						
						webMI.gfx.setText(now_text, now_content);
						checkValues[nowClicked_cell_page] = Number(now_content);	// 확인 값 저장
						webMI.gfx.setText(now_text, checkValues[nowClicked_cell_page]);	// 텍스트 = 확인 값
						
						webMI.gfx.setFill(now_text, color_Green_Active);	// 텍스트 색상 원래대로
						
						webMI.data.write(data_addr_map[nowClicked_cell_page] + "_Temp", Number(now_content));
						
						nowClicked_cell = null;
						preClicked_cell = null;
						footer_shadow_visible();
						
						webMI.trigger.fire("btn_active", "probe_apply");
					});
				 }
				 
				 Apply_Active();
			}
			
			if (clickedButton == "data")
			{
				var temp_prevention_level = 2;
				Prevention_Check(temp_prevention_level, () => {			
			
					if (now_tab == "정렬")
					{
						webMI.trigger.fire("File_Popup_Open", {"data_title" : "T{정렬}", "data_name" : `Probe${select_Probe_num}_Align`});
					}
					else if (now_tab == "테스트 트림")
					{
						webMI.trigger.fire("File_Popup_Open", {"data_title" : "T{테스트 트림}", "data_name" : `Probe${select_Probe_num}_Trim`});
					}
					else if (now_tab == "피드백 보상인자")
					{
						webMI.trigger.fire("File_Popup_Open", {"data_title" : "T{피드백 보상인자}", "data_name" : `Probe${select_Probe_num}_Feedback`});
					}
				});
				
				Apply_Active();
			}
		});
	});
}

webMI.trigger.connect("File_Select_Done", function(e){

	let options = {};
	options["path"] = e.value.path;	
	
	if (e.value.title == "정렬")
	{
		options["row_header"] = axis_Mapping;
		options["col_header"] = { 1: "Perm_ offset", 2: "Inducation Coeff", 3: "Slope"};
		options["name"] = `Probe${select_Probe_num}_Align`;
		options["type"] = "Align" + "_" + select_Probe_num;
		
		//Library -> ATVISE -> Resources -> index.htm 파일에 함수 있음
		webMI.rootWindow.CSV_Data_Load(options,function(error, data_list)		
		{
			if (error)
			{
				webMI.trigger.fire("Info_Popup_Open", { title : "T{오류}", info : "T{잘못된 파일입니다.}" });
			}
			else
			{
				checkValues = data_list;
				nowClicked_cell = null;
				preClicked_cell = null;
				Tab_Alignment();
				footer_shadow_visible();
				webMI.trigger.fire("Event_Add", "Data File Read : Probe" + select_Probe_num + " Alignment");			/////Default에 정의되어있음
			}
		});
		
	}
	else if (e.value.title == "테스트 트림")
	{
		options["row_header"] = axis_Mapping;
		options["col_header"] = { 1: "Internal", 2: "External"};
		options["name"] = `Probe${select_Probe_num}_Trim`;
		options["type"] = "Trim" + "_" + select_Probe_num;
		
		//Library -> ATVISE -> Resources -> index.htm 파일에 함수 있음
		webMI.rootWindow.CSV_Data_Load(options,function(error, data_list)		
		{
			if (error)
			{
				webMI.trigger.fire("Info_Popup_Open", { title : "T{오류}", info : "T{잘못된 파일입니다.}" });
			}
			else
			{
				checkValues = data_list;
				nowClicked_cell = null;
				preClicked_cell = null;
				Tab_Testtrim();
				footer_shadow_visible();
				webMI.trigger.fire("Event_Add", "Data File Read : Probe" + select_Probe_num + " Test Trim");			/////Default에 정의되어있음
			}
		});
	}
	else if (e.value.title == "피드백 보상인자")
	{
		options["row_header"] = rowMapping;
		options["col_header"] = { 1: "V_Sensor", 2: "A_Sensor", 3: "L_Sensor", 4 : "Current"};
		options["name"] = `Probe${select_Probe_num}_Feedback`;
		options["type"] = "Feedback_" + select_Probe_num;
		
		//Library -> ATVISE -> Resources -> index.htm 파일에 함수 있음
		webMI.rootWindow.CSV_Data_Load(options,function(error, data_list)		
		{
			if (error)
			{
				webMI.trigger.fire("Info_Popup_Open", { title : "T{오류}", info : "T{잘못된 파일입니다.}" });
			}
			else
			{
				checkValues = data_list;
				nowClicked_cell = null;
				preClicked_cell = null;
				Tab_Feedback();
				footer_shadow_visible();
				webMI.trigger.fire("Event_Add", "Data File Read : Probe" + select_Probe_num + " Feedback Comp. Factor");			/////Default에 정의되어있음
			}
		});
	}
});

FooterButtonClickEvents_coeff(["btn_1", "btn_2", "btn_3", "btn_4", "btn_5", "btn_6", "btn_7", "btn_8", "btn_9", "btn_0", "btn_plus", "btn_minus", "btn_dot", "btn_backspace", "btn_reset", "btn_check", "btn_data"]);



function Digit_Count(nowClicked_cell)		// 데이터 별 가능한 자리수
{
	if (now_tab == "피드백 보상인자")
	{
		digit_count = '_ _ _ _';
	}
	else if (nowClicked_cell == "tb_row1_col3_정렬" || nowClicked_cell == "tb_row2_col3_정렬" || nowClicked_cell == "tb_row3_col3_정렬")
	{
		digit_count = '_ _ _ . _';
	}
	else if (nowClicked_cell == "tb_row1_col2_테스트 트림" || nowClicked_cell == "tb_row2_col2_테스트 트림" || nowClicked_cell == "tb_row3_col2_테스트 트림")
	{
		digit_count = '_ _ _ . _ _ _';
	}
	else
	{
		digit_count = '_ _ _ . _ _';
	}
	
	return digit_count;
}

/*
webMI.trigger.connect("content", function(e)
{
	var now_content = e.value;
});
*/
///////////////////////////*  셀 클릭 이벤트  *///////////////////////////

function CellClickEvents(cell_ids)
{
	cell_ids.forEach(cell_id =>
	{
		webMI.addEvent(cell_id, "click", function(e)
		{
			let target = e.target;	// 현재 선택 셀
			
			let now_content = webMI.gfx.getText(extractBaseId(target.id)  + "_text_center" );
			let now_background_color = webMI.gfx.getFill(extractBaseId(target.id) + "_background");
			
			if (now_content == "" || now_background_color != color_Table_Cell_Background_Control )
			{
				return;
			}						
			
			var temp_prevention_level =2;
			
			Prevention_Check(temp_prevention_level, () => {
				nowClicked_cell = extractBaseId(target.id);  // 현재 선택된 셀(tb) 이름

				let now_text = nowClicked_cell + "_text_center";
				let pre_text;
				
				if (preClicked_cell != null)	// 이전값이 null이 아닐 때 pre_text 추출
				{
					pre_text = preClicked_cell + "_text_center";
				}
				
				let nowClicked_cell_page;
				let preClicked_cell_page;
				
				nowClicked_cell_page = nowClicked_cell + "_" + now_page;
				preClicked_cell_page = preClicked_cell + "_" +now_page;

				if (preClicked_cell == nowClicked_cell)	// 이전에 클릭한 셀을 다시 클릭하는 경우
				{
					if (checkValues[nowClicked_cell_page])	// 확인 값이 있는 경우
					{
						webMI.gfx.setText(now_text, checkValues[nowClicked_cell_page]);	// 다시 눌러도 확인 값 전시
						webMI.gfx.setFill(now_text, color_Green_Active);	// 폰트 선택 색상
					}
					else
					{
						webMI.gfx.setText(now_text, previousValues[nowClicked_cell_page]);
						webMI.gfx.setFill(now_text, color_Font_Table_Data);	
					}
					
					nowClicked_cell = null;
					footer_shadow_visible();
				}
				else	// 이전에 클릭한 셀과 다른 셀을 클릭하는 경우
				{
					if (checkValues[preClicked_cell_page] != undefined)
					{
						webMI.gfx.setText(pre_text, checkValues[preClicked_cell_page]);		// 확인 값으로
						webMI.gfx.setFill(pre_text, color_Green_Active);			
					}
					else
					{
						webMI.gfx.setText(pre_text, previousValues[preClicked_cell_page]);	// 이전 값으로
						webMI.gfx.setFill(pre_text, color_Font_Table_Data);			
					}
					
					webMI.gfx.setFill(now_text, color_Font_Selected_Data);						// 폰트 색 파랑
					webMI.gfx.setText(now_text, Digit_Count(nowClicked_cell_page));				// 선택 시 텍스트

					footer_shadow_hidden();
				}
				
				preClicked_cell = nowClicked_cell;  // 마지막 클릭 셀 업데이트
            });
		});
	});
}

function extractBaseId(id)	// 셀 id 자르기
{
    const match = id.match(/(tb_row\d+_col\d+)/);
    return match ? match[1] : null;
}

const cell_ids = [];	// 버튼 id 생성

for (let row = 1; row <= 10; row++)
{
    for (let col = 1; col <= 4; col++)
    {
        cell_ids.push(`tb_row${row}_col${col}`);
    }
}

CellClickEvents(cell_ids);


///////////////////////////*  적용 버튼 클릭 이벤트  *///////////////////////////

webMI.addEvent("btn_apply", "click", function(e)
{
	if (Object.keys(checkValues).length > 0)	 // 확인한 값이 하나 이상 있을 경우만 적용 확인 팝업 띄우기
	{
		var temp_prevention_level = 2;
		Prevention_Check(temp_prevention_level, () => {
			Popup_Open("apply");
		});
	}
});


///////////////////////////*  적용 확인 팝업 - 적용 버튼 클릭 이벤트  *///////////////////////////

webMI.trigger.connect("Apply", function(e)
{
	preClicked_cell = null;
	
	for (let cell_id_page in checkValues)  // 확인 값 찾아오기
	{
		let value = checkValues[cell_id_page];
		previousValues[cell_id_page] = Number(value);
    }
    
	//////////// 적용된 셀 색상 초기화 ///////////////////////
	for (let row = 1; row <= 10; row++)	// 데이터 셀 제어 색상
	{
		for (let col = 1; col <= 4; col++)
		{
			let pre_text = `tb_row${row}_col${col}_text_center`;
			
			webMI.gfx.setFill(pre_text, color_Font_Table_Data);
		}
	}		    
    
	let temp_row_header;
	let temp_col_header;
	let temp_name;
	
	if (now_tab == "정렬")
	{
		temp_col_header = { 1: "Perm_ offset", 2: "Inducation Coeff", 3: "Slope"};
		temp_row_header = axis_Mapping;
		temp_name = `Probe${select_Probe_num}_Align`;
		
		webMI.trigger.fire("Event_Add", "Data Change: Probe" + select_Probe_num + " Alignment");			/////Default에 정의되어있음
	}
	else if (now_tab == "테스트 트림")
	{
		temp_col_header = { 1: "Internal", 2: "External"};
		temp_row_header = axis_Mapping;
		temp_name =`Probe${select_Probe_num}_Trim`;
		
		webMI.trigger.fire("Event_Add", "Data Change: Probe" + select_Probe_num + " Test Trim");			/////Default에 정의되어있음
	}
	else if (now_tab == "피드백 보상인자")
	{
		temp_col_header = { 1: "V_Sensor", 2: "A_Sensor", 3: "L_Sensor", 4 : "Current"};
		temp_row_header = rowMapping;
		temp_name = `Probe${select_Probe_num}_Feedback`;
		
		webMI.trigger.fire("Event_Add", "Data Change: Probe" + select_Probe_num + " Feedback Comp. Factor");			/////Default에 정의되어있음
	}	
	
	webMI.data.write(apply_addr[select_Probe_num][now_tab], 1);	// 데이터 쓰기	
	
	webMI.rootWindow.Save_Settings_to_Excel(temp_row_header, temp_col_header, previousValues,temp_name);	    

    checkValues = {}; // 확인 값 초기화
    webMI.trigger.fire("btn_inactive", "probe_apply");
	webMI.trigger.fire("Apply_Popup_Cancel");
});


///////////////////////////*  적용 확인 팝업 - 취소 버튼 클릭 이벤트  *///////////////////////////

webMI.trigger.connect("Apply_Popup_Cancel", function(e)
{
	Click_Prevention("close")
	
	let apply_popup = document.getElementById("apply_popup");  

	apply_popup.setAttribute("x", "0");
	apply_popup.setAttribute("y", "1000");	// 화면 밖으로

});

///// 팝업 오픈 시 뒤에 클릭안되게 하는 화면 열기/닫기
function Click_Prevention(popup, paramter)
{
	if (popup == "open")
	{
		let shadow = document.getElementById("shadow");  
		if (paramter == undefined)
		{
			webMI.trigger.fire("Prevention_Open");	
		}
		else
		{
			webMI.trigger.fire("Prevention_Open",paramter);	
		}
		
		shadow.setAttribute("x", "0");
		shadow.setAttribute("y", "0");

	}
	else if (popup == "close")
	{
		let shadow = document.getElementById("shadow");  
		webMI.trigger.fire("Prevention_Close");
		
		shadow.setAttribute("x", "0");
		shadow.setAttribute("y", "-1000");	// 화면 밖으로

	}
}

//////현재 페이지 이외에서 팝업 요청 시 Shadow Visible, Invisible/////////////
webMI.trigger.connect("Prevention_req",function(e)
{
	let parameter = e.value.parameter;
	parameter = parameter == null ? undefined : parameter; 
	Click_Prevention(e.value.req, parameter);
});

function footer_shadow_hidden() {
	webMI.gfx.setVisible("footer_shadow", false);
	
	const footer_shadow_element_h = document.getElementById("footer_shadow");
	
	if (footer_shadow_element_h) {
		const children8 = footer_shadow_element_h.querySelectorAll("*");
		children8.forEach(child8 => {
			child8.style.visibility = "hidden";
			child8.style.display = "none";
		});
	}
}

function footer_shadow_visible() {
	webMI.gfx.setVisible("footer_shadow", true);
	
	const  footer_shadow_element_v = document.getElementById("footer_shadow");
	
	if (footer_shadow_element_v) {
		const children7 = footer_shadow_element_v.querySelectorAll("*");
		children7.forEach(child7 => {
			child7.style.visibility = "visible";
			child7.style.display = "block";
		});
	}
}

function header_alignment_hidden() {
	webMI.gfx.setVisible("header_alignment", false);
	
	const current_element_h = document.getElementById("header_alignment");	
	
	if (current_element_h) {
		const children3 = current_element_h.querySelectorAll("*");
		children3.forEach(child3 => {
			child3.style.visibility = "hidden";
			child3.style.display = "none";
		});
	}
}

function header_alignment_visible() {
	webMI.gfx.setVisible("header_alignment", true);
	
	const current_element_v = document.getElementById("header_alignment");		
	
	if (current_element_v) {
		const children4 = current_element_v.querySelectorAll("*");
		children4.forEach(child4 => {
			child4.style.visibility = "visible";
			child4.style.display = "block";
		});
	}
}

function header_test_trim_hidden() {
	webMI.gfx.setVisible("header_test_trim", false);
	
	const current_element_h = document.getElementById("header_test_trim");	
	
	if (current_element_h) {
		const children3 = current_element_h.querySelectorAll("*");
		children3.forEach(child3 => {
			child3.style.visibility = "hidden";
			child3.style.display = "none";
		});
	}
}

function header_test_trim_visible() {
	webMI.gfx.setVisible("header_test_trim", true);
	
	const current_element_v = document.getElementById("header_test_trim");		
	
	if (current_element_v) {
		const children4 = current_element_v.querySelectorAll("*");
		children4.forEach(child4 => {
			child4.style.visibility = "visible";
			child4.style.display = "block";
		});
	}
}

function header_feedback_hidden() {
	webMI.gfx.setVisible("header_feedback", false);
	
	const current_element_h = document.getElementById("header_feedback");	
	
	if (current_element_h) {
		const children3 = current_element_h.querySelectorAll("*");
		children3.forEach(child3 => {
			child3.style.visibility = "hidden";
			child3.style.display = "none";
		});
	}
}

function header_feedback_visible() {
	webMI.gfx.setVisible("header_feedback", true);
	
	const current_element_v = document.getElementById("header_feedback");		
	
	if (current_element_v) {
		const children4 = current_element_v.querySelectorAll("*");
		children4.forEach(child4 => {
			child4.style.visibility = "visible";
			child4.style.display = "block";
		});
	}
}

function page_visible() {
	webMI.gfx.setVisible("page", true);
	
	const current_element_v = document.getElementById("page");		
	
	if (current_element_v) {
		const children4 = current_element_v.querySelectorAll("*");
		children4.forEach(child4 => {
			child4.style.visibility = "visible";
			child4.style.display = "block";
		});
	}
}

function page_hidden() {
	webMI.gfx.setVisible("page", false);
	webMI.gfx.setVisible("btn_pre_page_label_center", false);
	webMI.gfx.setVisible("btn_next_page_label_center", false);
	
	const current_element_h = document.getElementById("page");	
	
	if (current_element_h) {
		const children3 = current_element_h.querySelectorAll("*");
		children3.forEach(child3 => {
			child3.style.visibility = "hidden";
			child3.style.display = "none";
		});
	}
}

function feedback_mode_visible() {
	webMI.gfx.setVisible("feedback_mode", true);
	webMI.gfx.setVisible("btn_pre_page_label_center", true);
	webMI.gfx.setVisible("btn_next_page_label_center", true);
	
	const current_element_v = document.getElementById("feedback_mode");		
	
	if (current_element_v) {
		const children4 = current_element_v.querySelectorAll("*");
		children4.forEach(child4 => {
			child4.style.visibility = "visible";
			child4.style.display = "block";
		});
	}
}

function feedback_mode_hidden() {
	webMI.gfx.setVisible("feedback_mode", false);
	webMI.gfx.setVisible("btn_pre_page_label_center", false);
	webMI.gfx.setVisible("btn_next_page_label_center", false);
	
	const current_element_h = document.getElementById("feedback_mode");	
	
	if (current_element_h) {
		const children3 = current_element_h.querySelectorAll("*");
		children3.forEach(child3 => {
			child3.style.visibility = "hidden";
			child3.style.display = "none";
		});
	}
}

///////////////////////////*  유저 매뉴얼 버튼 클릭 이벤트 *///////////////////////////

webMI.trigger.connect("UserManual_Open", function(e)
{
	
	Click_Prevention("open");
	let time_popup = document.getElementById("user_manual_popup");  

	time_popup.setAttribute("x", "603");		//960 -357 
	time_popup.setAttribute("y", "20");
	webMI.trigger.fire("UserManual_Move");
});

webMI.trigger.connect("UserManual_Close", function(e)
{
	Click_Prevention("close")
	let time_popup = document.getElementById("user_manual_popup");  
	time_popup.setAttribute("x", "0");
	time_popup.setAttribute("y", "1000");	// 화면 밖으로
	
});

/////프로브1 선택///////////////
webMI.addEvent("img_probe1", "click", function(e) {

	if (select_Probe_num != 1)
	{
		select_Probe_num = 1;
		webMI.gfx.setX("no_select_shadow1", 2000);
		webMI.gfx.setX("no_select_shadow2", 2000);
		webMI.trigger.fire("Probe_Body_Active_" + "Probe1");
		webMI.trigger.fire("Probe_Body_Deactive_" + "Probe2");
		webMI.gfx.setX("btn_data",btn_data_location);
		previousValues = {};
	}
	else
	{
		if (subscriptions.length != 0)
		{
			subscriptions.forEach(id => webMI.data.unsubscribe(id));
			subscriptions = []; // 구독 취소
		}	
	
		select_Probe_num = 0;
		webMI.gfx.setX("no_select_shadow1", 818);
		webMI.gfx.setX("no_select_shadow2", 818);
		webMI.trigger.fire("Probe_Body_Deactive_" + "Probe1");
		webMI.trigger.fire("Probe_Body_Deactive_" + "Probe2");
		webMI.gfx.setX("btn_data",2000);
		webMI.gfx.setX("btn_apply",2000);
		previousValues = {};
		page_hidden();
	}

	if (now_tab == "정렬")
	{
		Change_Tab(1);
		Change_Table_First_Col();
		Tab_Alignment();
	}
	else if (now_tab == "테스트 트림")
	{
		Change_Tab(2);
		Change_Table_First_Col();
		Tab_Testtrim();
	}
	else if (now_tab == "피드백 보상인자")
	{
		feedback_mode_manual = 0;
		Change_Tab(3);
		Change_Table_First_Col();
		Tab_Feedback();
	}
	
	Apply_Active();
});

/////프로브2 선택///////////////
webMI.addEvent("img_probe2", "click", function(e) {

	if (select_Probe_num != 2)
	{
		select_Probe_num = 2;
		webMI.gfx.setX("no_select_shadow1", 2000);
		webMI.gfx.setX("no_select_shadow2", 2000);
		webMI.trigger.fire("Probe_Body_Deactive_" + "Probe1");
		webMI.trigger.fire("Probe_Body_Active_" + "Probe2");
		webMI.gfx.setX("btn_data",btn_data_location);
		previousValues = {};
	}
	else
	{
		if (subscriptions.length != 0)
		{
			subscriptions.forEach(id => webMI.data.unsubscribe(id));
			subscriptions = []; // 구독 취소
		}	
	
		select_Probe_num = 0;
		webMI.gfx.setX("no_select_shadow1", 818);
		webMI.gfx.setX("no_select_shadow2", 818);
		webMI.trigger.fire("Probe_Body_Deactive_" + "Probe1");
		webMI.trigger.fire("Probe_Body_Deactive_" + "Probe2");
		webMI.gfx.setX("btn_data",2000);
		webMI.gfx.setX("btn_apply",2000);
		previousValues = {};
		page_hidden();
	}
	
	if (now_tab == "정렬")
	{
		Change_Tab(1);
		Change_Table_First_Col();
		Tab_Alignment();
	}
	else if (now_tab == "테스트 트림")
	{
		Change_Tab(2);
		Change_Table_First_Col();
		Tab_Testtrim();
	}
	else if (now_tab == "피드백 보상인자")
	{
		feedback_mode_manual =0;
		Change_Tab(3);
		Change_Table_First_Col();
		Tab_Feedback();
	}
	
	Apply_Active();
});

//////////////////////////키패드 오픈//////////////////////////////////
webMI.trigger.connect("Keyboard_Open", function(e)
{
	var type = e.value.type;
	
	var options = {};	
	var max_len = 0;
	var password_on = false;
	
	if (e.value.type == "ID")
	{
		max_len =15;
		password_on =false;
	}
	else if(e.value.type == "PW")
	{
		max_len = 21;
		password_on = true;
	}	
	
	options["parameter"] = type;
	options["max_len"] = max_len;
	options["password_on"] = password_on;
	
	webMI.trigger.fire("keyboard_init", options);
	
	let popup = document.getElementById("popup_keyboard");  
	popup.setAttribute("x", "310");
	popup.setAttribute("y", "285");	
});
	
////////////////키보드 종료///////////////////////////
webMI.trigger.connect("Keyboard_Close", function(e)
{
	let popup = document.getElementById("popup_keyboard");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

//////////////////////////로그인 팝업창 오픈//////////////////////////////////
webMI.trigger.connect("Login_Open", function(e)
{
	Click_Prevention("open");
	webMI.trigger.fire("Login_Popup_init");
	
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("x", "602");
	popup.setAttribute("y", "213");	
});
	
////////////////로그인 팝업창 종료///////////////////////////
webMI.trigger.connect("Login_Close", function(e)
{
	Click_Prevention("close");
	
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

////////////////로그인 팝업창 올리기///////////////////////////
webMI.trigger.connect("Login_Popup_Up", function(e)
{
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("y", "20");	
});

////////////////로그인 팝업창 내리기///////////////////////////
webMI.trigger.connect("Login_Popup_Down", function(e)
{
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("y", "213");	
});

//////////////////////////정보 팝업창 오픈//////////////////////////////////
webMI.trigger.connect("Info_Popup_Open", function(e)
{
	Click_Prevention("open");
	webMI.trigger.fire("Info_Init", e.value);	
	
	let popup = document.getElementById("info_popup");  
	popup.setAttribute("x", "602");
	popup.setAttribute("y", "213");	
});
	
////////////////정보 팝업창 종료///////////////////////////
webMI.trigger.connect("Info_Popup_Close", function(e)
{
	Click_Prevention("close");
	
	let popup = document.getElementById("info_popup");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

//////////////////////////파일 선택 팝업창 오픈//////////////////////////////////
webMI.trigger.connect("File_Popup_Open", function(e)
{
	Click_Prevention("open");
	webMI.trigger.fire("File_Popup_Init", e.value );	
	
	let popup = document.getElementById("file_popup");  
	popup.setAttribute("x", "660");
	popup.setAttribute("y", "34");	
});

////////////////파일 선택 팝업창 종료///////////////////////////
webMI.trigger.connect("File_Popup_Close", function(e)
{
	Click_Prevention("close");
	
	let popup = document.getElementById("file_popup");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});