var color = webMI.query["color"];

var dgs_mode = 0;				//1 : 수동, 2 : 자동, 3: 비활성화
var dgs_datasource;

var iframe= webMI.rootWindow.document.querySelector("#page_main_myframe").contentWindow.document.body;

iframe.addEventListener("click", () => {
  localStorage.setItem("NoTouchCount",0);
});   

///////////////////////////*  주/야간 색상 변경 *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	webMI.gfx.setFill("background_dispaly", color.Main_Background[color_mode]);
	
	webMI.gfx.setFill("arrow_1", color.Magnetic_Table_Normal_Line[color_mode]);			// 편차 오른쪽 라인
	webMI.gfx.setStroke("line_1", color.Magnetic_Table_Normal_Line[color_mode]);					// 편차 왼쪽 라인
	webMI.gfx.setStroke("line_2", color.Magnetic_Table_Normal_Line[color_mode]);		// 자기처리소 라인
	webMI.gfx.setStroke("line_3", color.Magnetic_Table_Normal_Line[color_mode]);		// 자기처리소 화살표
}


///////////////////////////*  자기장 값 뒤에 단위  *///////////////////////////

const setTextFromData = (objectPath, textId, unit) => {
    webMI.data.read(objectPath, function(e) {
        webMI.gfx.setText(textId, e.value.toFixed(1) + " " + unit);
    });
};

const Axis = ["L", "A", "V"];

////////////////////////////// V,A,L 축에 관련한 자기장 값 맵핑//////////////
Axis.forEach(axis =>
{
	/////////////////프로브 측정 함정 성분 자기장//////////
    setTextFromData(`AGENT.OBJECTS.03_ALGOR..Probe.${axis}`, 
		`tb_probe_${axis}_text_center`, "nT");
	////////////////지구자기장 맵 성분 자기장/////////////////
    setTextFromData(`AGENT.OBJECTS.03_ALGOR..Map.${axis}`, 
		`tb_map_${axis}_text_center`, "nT");
	//////////////노출 자기장 유도 + 와전류///////////
    setTextFromData(`AGENT.OBJECTS.03_ALGOR..Exposure.${axis}`, 
		`tb_exp_${axis}_text_center`, "nT");
	//////////////노출 자기장 영구 자기장//////////////
    setTextFromData(`AGENT.OBJECTS.03_ALGOR..Permanent.${axis}`, 
		`tb_exp_perm_${axis}_text_center`, "nT");
	/////////////노출 유도 + 와전류 + 영구 //////////////
	setTextFromData(`AGENT.OBJECTS.03_ALGOR..Exposure_All.${axis}`, 
		`tb_exp_all_${axis}_text_center`, "nT");
});

/////////////////편차/////////
setTextFromData("AGENT.OBJECTS.03_ALGOR..Deviation", 
	"tb_deviation_value_text_center", "nT");

/////////////////프로브 측정 함정 성분 자기장 통합//////////
setTextFromData(`AGENT.OBJECTS.03_ALGOR..Probe.Magnitude`, 
	"tb_map_Mag_text_center", "nT");
////////////////지구자기장 맵 성분 자기장 통합/////////////////
setTextFromData("AGENT.OBJECTS.03_ALGOR..Map.Magnitude", 
	"tb_exp_Mag_text_center", "nT");
//////////////노출 자기장 유도 + 와전류 통합///////////
setTextFromData("AGENT.OBJECTS.03_ALGOR..Exposure.Magnitude", 
	"tb_probe_Mag_text_center", "nT");
/////////////노출 유도 + 와전류 + 영구  통합//////////////
setTextFromData("AGENT.OBJECTS.03_ALGOR..Exposure_All.Magnitude", 
	"tb_exp_all_Mag_text_center", "nT");

///////////////////////////*  소자 모드 데이터 읽어오기 *///////////////////////////
webMI.data.subscribe("AGENT.OBJECTS.SIM_OBJECTS.02.Degaussing.Degaussing_Mode._DGM", function(e)	
//webMI.data.subscribe("AGENT.OBJECTS.Control._DGM", function(e)	
{	
	dgs_mode = e.value;
	
	if (dgs_mode == 3)
	{
		webMI.gfx.setFill("tb_exp_perm_V_text_center", color.Font_Table_Data[color_mode]);
		webMI.gfx.setFill("tb_exp_perm_A_text_center", color.Font_Table_Data[color_mode]);
		webMI.gfx.setFill("tb_exp_perm_L_text_center", color.Font_Table_Data[color_mode]);
		
		webMI.trigger.fire("background_edit", "tb_exp_perm_V");
		webMI.trigger.fire("background_edit", "tb_exp_perm_A");
		webMI.trigger.fire("background_edit", "tb_exp_perm_L");
	}
	else
	{
		webMI.gfx.setFill("tb_exp_perm_V_text_center", color.Font_Default[color_mode]);
		webMI.gfx.setFill("tb_exp_perm_A_text_center", color.Font_Default[color_mode]);
		webMI.gfx.setFill("tb_exp_perm_L_text_center", color.Font_Default[color_mode]);	
	
		webMI.trigger.fire("background_normal", "tb_exp_perm_V");
		webMI.trigger.fire("background_normal", "tb_exp_perm_A");
		webMI.trigger.fire("background_normal", "tb_exp_perm_L");
	}

});

///////////////////////////*  데이터 소스 데이터 읽어오기 *///////////////////////////
webMI.data.read("AGENT.OBJECTS.Control._DATA_Source", function(e)	
{
	if (e.value == 1 || e.value == 3)
	{
		if (dgs_mode == 2)
		{
			///////////////////////////*  프로브 선택 색상  *///////////////////////////
			
			webMI.trigger.fire("mag_selected_title", "mag_probe_header");		// 프로브 헤더
			webMI.trigger.fire("mag_selected_data", "mag_probe_data");		// 프로브 데이터
			
			webMI.trigger.fire("mag_selected_title", "mag_deviation_header");	// 편차 헤더
			webMI.trigger.fire("mag_selected_data", "mag_deviation_data");	// 편차 데이터
			
			webMI.trigger.fire("mag_selected_title_f", "mag_facility");				// 자기처리소
			
			
			webMI.gfx.setStroke("line_probe", color.Selected_Magnetic_Table_Stroke[color_mode]);	// 프로브 라인
			
			Arrow_Color("on")
			
			///////////////////////////*  나머지 기본 색상  *///////////////////////////
			
			webMI.trigger.fire("mag_normal_title", "mag_map_header");			// 맵 헤더
			webMI.trigger.fire("mag_normal_data", "mag_map_data");			// 맵 데이터

			webMI.gfx.setStroke("line_map", color.TextBox_Stroke[color_mode]);		// 맵 라인
		}
		else
		{
			///////////////////////////*  기본 색상  *///////////////////////////
		
			webMI.trigger.fire("mag_normal_title", "mag_probe_header");		// 프로브 헤더
			webMI.trigger.fire("mag_normal_data", "mag_probe_data");			// 프로브 데이터
	
			webMI.gfx.setStroke("line_probe", color.TextBox_Stroke[color_mode]);	// 프로브 라인
			
			webMI.trigger.fire("mag_normal_title", "mag_map_header");			// 맵 헤더
			webMI.trigger.fire("mag_normal_data", "mag_map_data");			// 맵 데이터
	
			webMI.gfx.setStroke("line_map", color.TextBox_Stroke[color_mode]);		// 맵 라인
			
			webMI.trigger.fire("mag_normal_title", "mag_deviation_header");	// 편차 헤더
			webMI.trigger.fire("mag_normal_data", "mag_deviation_data");		// 편차 데이터
			
			Arrow_Color("off")
		}
	}
	else if (e.value == 2 || e.value == 4)
	{
		if (dgs_mode == 2)
		{
			///////////////////////////*  지구 자기장 맵 선택 색상  *///////////////////////////

			webMI.trigger.fire("mag_selected_title", "mag_map_header");		// 맵 헤더
			webMI.trigger.fire("mag_selected_data", "mag_map_data");			// 맵 데이터
						
			webMI.trigger.fire("mag_selected_title", "mag_deviation_header");	// 편차 헤더
			webMI.trigger.fire("mag_selected_data", "mag_deviation_data");	// 편차 데이터
			
			webMI.trigger.fire("mag_selected_title_f", "mag_facility");				// 자기처리소
			
			webMI.gfx.setStroke("line_map", color.Selected_Magnetic_Table_Stroke[color_mode]);		// 맵 라인
			
			Arrow_Color("on")
			
			///////////////////////////*  나머지 기본 색상  *///////////////////////////
			
			webMI.trigger.fire("mag_normal_title", "mag_probe_header");		// 프로브 헤더
			webMI.trigger.fire("mag_normal_data", "mag_probe_data");			// 프로브 데이터

			webMI.gfx.setStroke("line_probe", color.TextBox_Stroke[color_mode]);	// 프로브 라인
		}
		else
		{
			///////////////////////////*  기본 색상  *///////////////////////////
		
			webMI.trigger.fire("mag_normal_title", "mag_probe_header");		// 프로브 헤더
			webMI.trigger.fire("mag_normal_data", "mag_probe_data");			// 프로브 데이터
	
			webMI.gfx.setStroke("line_probe", color.TextBox_Stroke[color_mode]);	// 프로브 라인
			
			webMI.trigger.fire("mag_normal_title", "mag_map_header");			// 맵 헤더
			webMI.trigger.fire("mag_normal_data", "mag_map_data");				// 맵 데이터
	
			webMI.gfx.setStroke("line_map", color.TextBox_Stroke[color_mode]);		// 맵 라인
			
			webMI.trigger.fire("mag_normal_title", "mag_deviation_header");	// 편차 헤더
			webMI.trigger.fire("mag_normal_data", "mag_deviation_data");		// 편차 데이터
			
			Arrow_Color("off")
		}
	}
	
	if (dgs_mode != 2)
	{
		webMI.trigger.fire("mag_selected_title_f", "mag_facility");				// 자기처리소
		webMI.gfx.setStroke("arrow_dgs_facility_line", color.Selected_Magnetic_Table_Stroke[color_mode]);	// 자기처리소 라인
		webMI.gfx.setFill("arrow_dgs_facility_head", color.Selected_Magnetic_Table_Stroke[color_mode]);	// 자기처리소 화살표
	}
});


///////////////////////////*  색상 변경  *///////////////////////////

function Arrow_Color(on_off)
{
	if (on_off == "on")
	{
		webMI.gfx.setFill("arrow_deviation_head", color.Selected_Magnetic_Table_Stroke[color_mode]);		// 편차 화살표
		webMI.gfx.setStroke("arrow_deviation_line", color.Selected_Magnetic_Table_Stroke[color_mode]);		// 편차 오른쪽 라인
		webMI.gfx.setStroke("line_deviation", color.Selected_Magnetic_Table_Stroke[color_mode]);				// 편차 왼쪽 라인
		webMI.gfx.setStroke("arrow_dgs_facility_line", color.Selected_Magnetic_Table_Stroke[color_mode]);	// 자기처리소 라인
		webMI.gfx.setFill("arrow_dgs_facility_head", color.Selected_Magnetic_Table_Stroke[color_mode]);	// 자기처리소 화살표
		
	}
	else if (on_off == "off")
	{
		webMI.gfx.setFill("arrow_deviation_head", color.Magnetic_Table_Normal_Line[color_mode]);			// 편차 화살표
		webMI.gfx.setFill("arrow_dgs_facility_head", color.Magnetic_Table_Normal_Line[color_mode]);			// 편차 오른쪽 라인
		webMI.gfx.setStroke("line_deviation", color.Magnetic_Table_Normal_Line[color_mode]);					// 편차 왼쪽 라인
		webMI.gfx.setStroke("arrow_deviation_line", color.Magnetic_Table_Normal_Line[color_mode]);		// 자기처리소 라인
		webMI.gfx.setStroke("arrow_dgs_facility_line", color.Magnetic_Table_Normal_Line[color_mode]);		// 자기처리소 화살표
	}
}

///////////////////////////*  유저 매뉴얼 버튼 클릭 이벤트 *///////////////////////////

webMI.trigger.connect("UserManual_Open", function(e)
{
	
	Click_Prevention("open");
	let time_popup = document.getElementById("user_manual_popup");  

	time_popup.setAttribute("x", "603");		//960 -357 
	time_popup.setAttribute("y", "20");
	webMI.trigger.fire("UserManual_Move");
});

webMI.trigger.connect("UserManual_Close", function(e)
{
	Click_Prevention("close")
	let time_popup = document.getElementById("user_manual_popup");  
	time_popup.setAttribute("x", "0");
	time_popup.setAttribute("y", "1000");	// 화면 밖으로
	
});

///// 팝업 오픈 시 뒤에 클릭안되게 하는 화면 열기/닫기
function Click_Prevention(popup)
{
	if (popup == "open")
	{
		let shadow = document.getElementById("shadow");  
		webMI.trigger.fire("Prevention_Open");	
		
		shadow.setAttribute("x", "0");
		shadow.setAttribute("y", "0");

	}
	else if (popup == "close")
	{
		let shadow = document.getElementById("shadow");  
		webMI.trigger.fire("Prevention_Close");
		
		shadow.setAttribute("x", "0");
		shadow.setAttribute("y", "-1000");	// 화면 밖으로

	}
}

//////////////////////////키패드 오픈//////////////////////////////////
webMI.trigger.connect("Keyboard_Open", function(e)
{
	var type = e.value.type;
	
	var options = {};	
	var max_len = 0;
	var password_on = false;
	
	if (e.value.type == "ID")
	{
		max_len =15;
		password_on =false;
	}
	else if(e.value.type == "PW")
	{
		max_len = 21;
		password_on = true;
	}	
	
	options["parameter"] = type;
	options["max_len"] = max_len;
	options["password_on"] = password_on;
	
	webMI.trigger.fire("keyboard_init", options);
	
	let popup = document.getElementById("popup_keyboard");  
	popup.setAttribute("x", "310");
	popup.setAttribute("y", "285");	
});
	
////////////////키보드 종료///////////////////////////
webMI.trigger.connect("Keyboard_Close", function(e)
{
	let popup = document.getElementById("popup_keyboard");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

//////////////////////////로그인 팝업창 오픈//////////////////////////////////
webMI.trigger.connect("Login_Open", function(e)
{
	Click_Prevention("open");
	webMI.trigger.fire("Login_Popup_init");
	
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("x", "602");
	popup.setAttribute("y", "213");	
});
	
////////////////로그인 팝업창 종료///////////////////////////
webMI.trigger.connect("Login_Close", function(e)
{
	Click_Prevention("close");
	
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

////////////////로그인 팝업창 올리기///////////////////////////
webMI.trigger.connect("Login_Popup_Up", function(e)
{
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("y", "20");	
});

////////////////로그인 팝업창 내리기///////////////////////////
webMI.trigger.connect("Login_Popup_Down", function(e)
{
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("y", "213");	
});

//////////////////////////정보 팝업창 오픈//////////////////////////////////
webMI.trigger.connect("Info_Popup_Open", function(e)
{
	Click_Prevention("open");
	webMI.trigger.fire("Info_Init",e.value);	
	
	let popup = document.getElementById("permission_popup");  
	popup.setAttribute("x", "602");
	popup.setAttribute("y", "213");	
});
	
////////////////정보 팝업창 종료///////////////////////////
webMI.trigger.connect("Info_Popup_Close", function(e)
{
	Click_Prevention("close");
	
	let popup = document.getElementById("permission_popup");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
	
	let popup2 = document.getElementById("numberPad_popup");  
	popup2.setAttribute("x", "2000");
	popup2.setAttribute("y", "2000");	
});

//////////////////////////자기장 데이터 팝업창 오픈//////////////////////////////////
webMI.trigger.connect("MF_Data_Popup_Open", function(e)
{
	Click_Prevention("open");
	webMI.trigger.fire("MF_Data_Popup_Init",e.value);	
	
	let popup = document.getElementById("MF_data_popup");  
	popup.setAttribute("x", "511");
	popup.setAttribute("y", "109.5");	
});
	
////////////////자기장 데이터 팝업창 종료///////////////////////////
webMI.trigger.connect("MF_Data_Popup_Close", function(e)
{
	Click_Prevention("close");
	
	let popup = document.getElementById("MF_data_popup");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

////////////////자기장 데이터 팝업창 수신///////////////////////////
webMI.trigger.connect("MF_Data_Popup_Done", function(e)
{
	if (e.value.V != undefined)
	{
		webMI.gfx.setText("tb_exp_perm_V_text_center", e.value.V + " nT");
		webMI.trigger.fire("Event_Add", "Data Change : Exposure Magnetic Field - Perm. Magnetic Field V Axis");			/////Default에 정의되어있음
	}
	
	if (e.value.A != undefined)
	{
		webMI.gfx.setText("tb_exp_perm_A_text_center", e.value.A + " nT");
		webMI.trigger.fire("Event_Add", "Data Change : Exposure Magnetic Field - Perm. Magnetic Field A  Axis");			/////Default에 정의되어있음
	}
	
	if (e.value.L != undefined)
	{
		webMI.gfx.setText("tb_exp_perm_L_text_center", e.value.L + " nT");
		webMI.trigger.fire("Event_Add", "Data Change : Exposure Magnetic Field - Perm. Magnetic Field L Axis");			/////Default에 정의되어있음
	}
});

/////////////권한 확인////////////////////////////////////////
function Prevention_Check(prevention_level, callback)
{
	webMI.trigger.fire("Prevention_Check", {level : prevention_level, callback : function(access)	
	{
		if (access == false)
		{
			webMI.trigger.fire("Info_Popup_Open", { title : "T{권한}", info : "T{해당 기능에 대한 권한이 없습니다.}" });
			return;
		}
		else
		{
			callback();
		}
	}});
}

////////////////영구 자기장 클릭 이벤트///////////////
function Exp_perm_Click(buttonIds)
{
	buttonIds.forEach(buttonId =>
	{
		webMI.addEvent(buttonId, "click", function(e) {
			
			if (dgs_mode != 3)
			{
				return;			
			}			
			
			let temp_prevention_level = 3;
	
			Prevention_Check(temp_prevention_level, () => {
				let temp_axis = buttonId.slice(-1);
				
				let options = {};

				options["axis"] = temp_axis;
				options["data"] = {
					V : webMI.gfx.getText("tb_exp_perm_V_text_center").replace("nT","").trim(),
					A : webMI.gfx.getText("tb_exp_perm_A_text_center").replace("nT","").trim(),
					L : webMI.gfx.getText("tb_exp_perm_L_text_center").replace("nT","").trim()};
					 
				webMI.trigger.fire("MF_Data_Popup_Open", options);
			});
		});
	});
}

Exp_perm_Click(["tb_exp_perm_V","tb_exp_perm_A","tb_exp_perm_L"]);

//////////////////////적용 팝업 오픈//////////////////////
webMI.trigger.connect("Apply_Popup_Open", function(e)
{
	Click_Prevention("open");	// 팝업 열릴 때 뒤에 클릭 방지

	let apply_popup = document.getElementById("apply_popup");  
	let prevention_level= 2;
	webMI.trigger.fire("Apply_Popup_prevention_level_Set",prevention_level);				///Apply 팝업창에 Apply 가능 권한 레벨 할당
	
	apply_popup.setAttribute("x", "700");
	apply_popup.setAttribute("y", "250");
});

//////////////////적용 확인//////////////////////	
webMI.trigger.connect("Apply", function(e)
{
	webMI.trigger.fire("Apply_Popup_Cancel");
});


///////////////////////////*  적용 확인 팝업 - 취소 버튼 클릭 이벤트  *///////////////////////////

webMI.trigger.connect("Apply_Popup_Cancel", function(e)
{	
	let apply_popup = document.getElementById("apply_popup");  

	apply_popup.setAttribute("x", "0");
	apply_popup.setAttribute("y", "1000");	// 화면 밖으로
});