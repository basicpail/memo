var color = webMI.query["color"];

var chartname_search = "trend1";
var startTime;
var endTime;
var previous_start_time;
var previous_end_time;
var previous_series_name = [];
var search_block = false;
var dt_start = new Date();
dt_start.setMinutes(dt_start.getMinutes() - 5);

var dt_end = new Date();

var group_select, equipment_select, etc_select;
var menu_group_list = [];
var x_number = 15;
var color_mode;
var chart_init = false;
var previous_x_location = webMI.gfx.getX("HighChart");
const THREE_HOURS = 3 * 60 * 60 * 1000;

var iframe= webMI.rootWindow.document.querySelector("#page_main_myframe").contentWindow.document.body;

iframe.addEventListener("click", () => {
  localStorage.setItem("NoTouchCount",0);
});   

Date_init();

///////////////////////////*  주/야간 색상 변경  *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	webMI.gfx.setFill("background_display", color.Main_Background[color_mode]);
		
	webMI.gfx.setFill("bento_1", color.Bento[color_mode]);
	webMI.gfx.setFill("bento_2", color.Bento[color_mode]);
	
	webMI.gfx.setFill("lbl_StartTime", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl_Start_Date", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl_EndTime", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl_End_Date", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl_wave", color.Font_Default[color_mode]);
	webMI.gfx.setStroke("line_1", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_2", color.Under_Line[color_mode]);
}

////////Time Stamp -> Date String//////////////////
function Timstamp_to_DateString(timestamp)
{
	date = new Date(timestamp);
	var hours = ("0" + date.getHours()).slice(-2);
	var minutes = ("0" + date.getMinutes()).slice(-2);
	var seconds = ("0" + date.getSeconds()).slice(-2);
	var day = ("0" + date.getDate()).slice(-2);
	var month = ("0" + (date.getMonth() + 1)).slice(-2);
	var YEAR = (date.getFullYear()); //.slice(-2);
	
	var timeString = "%Y/%M/%D %H:%m:%s";
	timeString = timeString.replace(/%H/, hours);
	timeString = timeString.replace(/%m/, minutes);
	timeString = timeString.replace(/%s/, seconds);
	timeString = timeString.replace(/%Y/, YEAR);
	timeString = timeString.replace(/%M/, month);
	timeString = timeString.replace(/%D/, day);
	
	return timeString;
}

///////////////////////////////시작 날짜 종료 날짜에 대한 라벨 초기값 설정////////////////////////
function Date_init()
{
	var dt_end = new Date();
	var dt_start = new Date(dt_end.getTime() - THREE_HOURS);
	
	startTime = dt_start.getTime();
	endTime = dt_end.getTime();
	
	webMI.gfx.setText("lbl_Start_Date",Timstamp_to_DateString(startTime));
	webMI.gfx.setText("lbl_End_Date",Timstamp_to_DateString(endTime));
}

///////////////////////////////시작 또는 날짜 변경, Time stamp 값/////////////////////
webMI.trigger.connect("Period_Date_Value",function (e) {
	startTime = e.value.start_date;
	endTime = e.value.end_date;
	
	webMI.gfx.setText("lbl_Start_Date",Timstamp_to_DateString(startTime));
	webMI.gfx.setText("lbl_End_Date",Timstamp_to_DateString(endTime));
});


//////////////////////////////////날짜 검색//////////////////////////////////////////////////////////////////
webMI.addEvent("btn_Search", "click", function(e) {
		
		//// 트렌드 객체 가져오기
		var chart_search = webMI.trendFactory.getTrendByName("trend1");
		
		//// 현재 추가되어 있는 채널이 있는지 확인
		if (chart_search.chart.series.length < 1)
		{
			//없으면 리턴
			console.log("no added");
			return;
		}		
		
		let sub_time = endTime - startTime;		
		
		if (sub_time > THREE_HOURS)
		{
			webMI.trigger.fire("Info_Popup_Open", { title : "T{오류}", info : "T{검색 기간이 3시간을 초과하였습니다.}" });
			return;
		}
		
		let series_name	= [];
		for (let i = 0; i < chart_search.chart.series.length; i++ )
		{
			series_name.push(chart_search.chart.series[i].name);
		}
		
		if (search_block == true)
		{
			if(series_name.length != previous_series_name.length)
			{
				search_block = false;
			}
			else
			{
				for (let i = 0; i < series_name.length; i++)
				{
					if (series_name[i] != previous_series_name[i])
					{
						search_block = false;
					}
				}
			}
		}
		
		var chart_live_bl = chart_search.control.isLiveModeRunning();
		if ((chart_live_bl == true) || (search_block == false))
		{
			previous_start_time = 0;
			previous_end_time = 0;
			search_block = false;
		}
		
		if ((previous_start_time != startTime) || (previous_end_time != endTime))
		{
			search_block = false;
		}		
		
		if ((search_block == true) || (startTime > endTime))	{
			webMI.trigger.fire("Info_Popup_Open", { title : "T{오류}", info : "T{잘못된 기간입니다.}" });
			
			return;
		}
		
		if (chart_search.control.isLiveModeRunning()) 
		{
			let _seriesVisible = {};
			for (var key in chart_search.chart.series) {
				_seriesVisible[key] = chart_search.chart.series[key].visible;
				chart_search.chart.series[key].hide();
			}

			chart_search.control.stopLiveMode(function () {
				webMI.gfx.setVisible("btn_start", true);
				webMI.gfx.setVisible("btn_stop", false);
				var min = startTime;
				var max = endTime;
	
				chart_search.chart.xAxis["0"].setExtremes(min, max);
				var configHandler = new webMI.rootWindow.ConfigHandler();
				var optionsObj = configHandler.createConfigObject("min", min);
				chart_search.chart.xAxis["0"].update(optionsObj);
	
				for (var key in chart_search.chart.series) {
					if (_seriesVisible[key])
						chart_search.chart.series[key].show();
				}
				
				previous_start_time = startTime;
				previous_end_time = endTime;
				search_block = true;
				previous_series_name = series_name;
				
			});
		} 
		
		chart_search.chart.xAxis["0"].userOptions.timeSlotStart = startTime;
		chart_search.chart.xAxis["0"].userOptions.timeSlotEnd =endTime;
		chart_search.chart.xAxis["0"].userOptions.min = startTime;
		chart_search.chart.xAxis["0"].userOptions.max =endTime;
		
		chart_search.chart.xAxis["0"].setExtremes(startTime, endTime);
		chart_search.chart.xAxis["0"].options.min = startTime;
		chart_search.chart.xAxis["0"].options.max = endTime;
		chart_search.chart.xAxis["0"].update({min: startTime, max: endTime});

		//var oldMode = chart_search.chart.options.atviseOptions.mode;
		webMI.gfx.setVisible("btn_start", true);
		webMI.gfx.setVisible("btn_stop", false);
		chart_search.control.loadHistory();	
		Chart_X_Number();
		setTimeout(Chart_check,500);
		
		//chart_search.control.setMode(oldMode);
		previous_start_time = startTime;
		previous_end_time = endTime;
		search_block = true;
		previous_series_name = series_name;

});

function Chart_check()
{
	var chart = webMI.trendFactory.getTrendByName("trend1");
	//Chart_X_Number();

	for (let j = 0; j < chart.chart.series.length; j++)
	{
		if (chart.chart.series[j].processedXData.length <= 0 && chart.chart.series[j].xData.length > 0)
		{
			chart.control.loadHistory();
			/*
			var min_index,max_index;
			for (let i = 0; i < chart.chart.series[j].xData.length; i++)
			{
				if (min_index == undefined && chart.chart.series[j].xData[i] >=  startTime && chart.chart.series[j].xData[i] > 1700000000000)
				{
					min_index = i;
				}
					
				if (max_index == undefined && chart.chart.series[j].xData[chart.chart.series[j].xData.length - (i + 1)] <=  endTime && chart.chart.series[j].xData[chart.chart.series[j].xData.length - (i + 1)] > 1700000000000)
				{
					max_index = chart.chart.series[j].xData.length - (i + 1);
				}
			}
				
			if (min_index != undefined && max_index != undefined)
			{
				chart.chart.series[j].processedXData = chart.chart.series[j].xData.slice(min_index, max_index - min_index + 1);
				chart.chart.series[j].processedYData = chart.chart.series[j].yData.slice(min_index, max_index - min_index + 1);
				
			}*/
		}
	}
}

/////    X -> 시간 축 개수 지정
function Chart_X_Number()
{

	var chart = webMI.trendFactory.getTrendByName("trend1");
	chart.chart.xAxis[0].tickInterval = (chart.chart.xAxis[0].userMax - chart.chart.xAxis[0].userMin) / x_number;	
	chart.chart.xAxis[0].options.tickInterval = (chart.chart.xAxis[0].userMax - chart.chart.xAxis[0].userMin) / x_number;	
	if (chart.chart.xAxis[0].tickPositions.length > x_number)
	{
		chart.chart.xAxis[0].tickPositions = [];
		chart.chart.xAxis[0].paddedTicks = [];
		for(let i = 0; i < x_number + 1; i++)
		{
			chart.chart.xAxis[0].tickPositions.push(chart.chart.xAxis[0].userMin + chart.chart.xAxis[0].tickInterval * i);
			chart.chart.xAxis[0].paddedTicks.push(chart.chart.xAxis[0].userMin + chart.chart.xAxis[0].tickInterval * i);
		}
	}
}

/////////////권한 확인////////////////////////////////////////
function Prevention_Check(prevention_level, callback)
{
	webMI.trigger.fire("Prevention_Check", {level : prevention_level, callback : function(access)	
	{
		if (access == false)
		{
			webMI.trigger.fire("Info_Popup_Open", { title : "T{권한}", info : "T{해당 기능에 대한 권한이 없습니다.}" });
			return;
		}
		else
		{
			callback();
		}
	}});
}

////////////////// Export ///////////////////////////////////////
webMI.addEvent("btn_export", "click", function(e) {
	let temp_prevention_level = 3;
	
	var chart = webMI.trendFactory.getTrendByName("trend1");
	
	//// 현재 추가되어 있는 채널이 4개 초과이면 리턴
	if (chart.chart.series.length == 0)
	{
		return;
	}		
	
	Prevention_Check(temp_prevention_level, () => {
		webMI.rootWindow.startLoading(0,0,1920,1080);	// 로딩 오버레이
		
		var chart = webMI.trendFactory.getTrendByName("trend1");
		
		//////////////차트가 Run 중이면 정지
		if (chart.control.isLiveModeRunning())
		{
			chart.control.stopLiveMode();
				
			webMI.gfx.setVisible("btn_start", true);
			webMI.gfx.setVisible("btn_stop", false);
		}
		
		var chart_export = webMI.trendFactory.getTrendByName("trend1");
		//chart_export.chart.options.exporting.menuItemDefinitions.downloadPNG.onclick;
		setTimeout(() => {webMI.rootWindow.Chart_Export(chart_export.chart.series);}, 5);
	});
});

///채널 추가 버튼
webMI.addEvent("btn_add", "click", function(e) {

	var chart = webMI.trendFactory.getTrendByName("trend1");
	
	//// 현재 추가되어 있는 채널이 4개 초과이면 리턴
	if (chart.chart.series.length > 4)
	{
		console.log("no added");
		return;
	}
	
	Chart_start_stop();

	Click_Prevention("open");
	webMI.gfx.setMoveX("HighChart",3000);
	webMI.trigger.fire("Channel_Popup_Init",e.value);	
	
	let popup = document.getElementById("channel_add_popup");  
	popup.setAttribute("x", "432.5");
	popup.setAttribute("y", "25");	
	
});

////////////////채널 추가 팝업창 팝업창 종료///////////////////////////
webMI.trigger.connect("Channel_Close", function(e)
{
	Click_Prevention("close");
	webMI.gfx.setMoveX("HighChart",previous_x_location);
	
	let popup = document.getElementById("channel_add_popup");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

////////////차트에 채널 추가
webMI.trigger.connect("Channel_Select_Done",function(e)
{
	var chart = webMI.trendFactory.getTrendByName("trend1");
	localStorage.setItem("Chart_Display",true);			//// 캡쳐시 차트를 표시할지 안할지
	
	webMI.trigger.fire("chart_view_on","on");	
	
	options = {};
	options.events = 
	{
			afterGeneratePoints: function () 
			{
				this.cleanUpIndices();
			}
	};
	
	if (chart_init == false)
	{
		chart_init = true;
		chart.chart.options.chart.backgroundColor = "";
		
		color_str = color.Font_Default[color_mode];
		chart.chart.axes[1].stacking.axis.options.gridLineColor = color_str;
		chart.chart.axes[1].stacking.axis.options.lineColor = color_str;
		chart.chart.axes[1].stacking.axis.options.labels.style.color = color_str;
		chart.chart.axes[1].stacking.axis.options.stackLabels.style.color = color_str;
		chart.chart.axes[1].stacking.axis.options.tickColor = color_str;

		/*chart.chart.axes[0].userOptions.gridLineColor = "#ff0000";
		chart.chart.axes[0].userOptions.lineColor = "#ff0000";
		chart.chart.axes[1].userOptions.gridLineColor = "#ff0000";
		chart.chart.axes[1].userOptions.lineColor = "#ff0000";
		chart.chart.legend.options.itemHiddenStyle.color = "#ff0000";
		chart.chart.caption.styles.color = "#ff0000";
		chart.chart.title.styles.color = "#ff0000";		
		chart.chart.legend.itemHiddenStyle.color = "#ff0000";		
		chart.chart.legend.itemStyle.color = "#ff0000";		
		
		
		chart.chart.options.navigation.activeColor = "#00ff00";
		chart.chart.options.navigation.inactiveColor = "#00ff00";
		chart.chart.options.chart.plotBorderColor = "#0000ff";
		chart.chart.options.chart.xAxis[0].minorTickColor = "#ff0000";
		chart.chart.options.chart.xAxis[0].minorGridLineColor = "#00ff00";
		chart.chart.options.chart.xAxis[0].tickColor = "#0000ff";*/
	}

	options.tooltipOptions = {valueDecimals: 2};
	options.tooltip = {valueDecimals: '2'};
	options.marker = {enabled: false};
	options.dataArchive = "";
	var date = new Date();
	options.id = "series-" + date.getTime();
	options.index = chart.chart.series.length + 1;
	options.name = e.value.name;																		//이름
	options.pointStart = undefined;
	options.address = e.value.addr;		//주소
	options.aggregate = {
		aggregate : 'Sampled',
		interval : 1,
		unit : 's',
		address : 'AGENT.HISTORY.AGGREGATETEMPLATES.Magnetic_Field.sampling'
	}
	
	/** add new series **/
	chart.chart.addSeries(options);
	
	chart.chart.series[0].area = undefined;
	chart.chart.series[0].basePointRange = 1000;
	chart.chart.series[0].baseSeries = undefined;
	chart.chart.series[0].buildingKdTree = false;
	chart.chart.series[0].clips = undefined;
	chart.chart.series[0].closestPointRange = 1000;
	chart.chart.series[0].closestPointRangePx = 28.1666666;
	chart.chart.series[0].dataMax = 0;
	chart.chart.series[0].dataMin = 0;
	chart.chart.series[0].finishedAnimating = true;
	chart.chart.series[0].initialType = "line";
	
	chart.chart.zooming.type = '';	
	chart.control.showMeasuringCursor1();
	chart.chart.series[0].xAxis.plotLinesAndBands[0].options.color = "#ffffff";		///마커 색상 변경
	chart.control.hideMeasuringCursor1();
	
	if (chart.chart.series.length == 1)
	{
		chart.control.stopLiveMode();
	
		setTimeout(function (ex){
			chart.control.startLiveMode();
			webMI.gfx.setVisible("btn_start", false);
			webMI.gfx.setVisible("btn_stop", true);
		},300);
	}
	else
	{
		chart.control.loadHistory();
		setTimeout(Chart_check,500);
	}
});

/////차트 시작 버튼/////////
webMI.addEvent("btn_start", "click", function(e) { Chart_start_stop(); });

/////////차트 정지 버튼//////////
webMI.addEvent("btn_stop", "click", function(e) { Chart_start_stop(); });

////// 차트 시작/정지 함수, 현재 차트의 상태에 따라 시작/정지///////////////
function Chart_start_stop() {
	var chart = webMI.trendFactory.getTrendByName("trend1");

	//////////////차트가 Run 중이면 정지
	if (chart.control.isLiveModeRunning())
	{
		chart.control.stopLiveMode();
			
		webMI.gfx.setVisible("btn_start", true);
		webMI.gfx.setVisible("btn_stop", false);
	}
	///////////차트가 정지 중이면 시작
	else
	{
		////////차트에 채널이 없으면 리턴/////////////
		if (chart.chart.series.length < 1)
		{
			console.log("no added");
			return;
		}
			
		chart.control.setMode("mixed");
		chart.control.startLiveMode();
		webMI.gfx.setVisible("btn_start", false);
		webMI.gfx.setVisible("btn_stop", true);
		chart.chart.xAxis[0].tickInterval = 10000;	
		chart.chart.xAxis[0].options.tickInterval = 10000;
	
		chart.chart.xAxis[0].tickPositions = [];
		chart.chart.xAxis[0].paddedTicks = [];
		
		var x_count_max = (chart.chart.xAxis[0].userMax - chart.chart.xAxis[0].userMin) / 10000;	
		
		for(let i = 0; i < x_count_max + 1; i++)
		{
			chart.chart.xAxis[0].tickPositions.push(chart.chart.xAxis[0].userMin + chart.chart.xAxis[0].tickInterval * i);
			chart.chart.xAxis[0].paddedTicks.push(chart.chart.xAxis[0].userMin + chart.chart.xAxis[0].tickInterval * i);
		}
		
		if (chart.control.isMeasuringCursor1Visible())
			chart.control.hideMeasuringCursor1();
			
		if (chart.control.isMeasuringCursor2Visible())
			chart.control.hideMeasuringCursor2();
	}

};

//////차트 시작/정지 버튼 업데이트////////////////////
webMI.trigger.connect("Chart_Start_Stop_btn_update",function (e) {
if (e.value == "start")
{
		webMI.gfx.setVisible("btn_start", false);
		webMI.gfx.setVisible("btn_stop", true);
}
else if (e.value == "stop")
{
		webMI.gfx.setVisible("btn_start", true);
		webMI.gfx.setVisible("btn_stop", false);
}
});

// Marker1 활성화/비활성화 버튼
webMI.addEvent("btn_marker", "click", function(e) {
	var chart = webMI.trendFactory.getTrendByName("trend1");
	if (!chart.control.isMeasuringCursor1Visible())
	{
		chart.control.showMeasuringCursor1();
	}
	else
	{		
		chart.control.hideMeasuringCursor1();
	}
});

///////////////////////////*  시간 설정 버튼 클릭 이벤트 *///////////////////////////

webMI.addEvent(["lbl_End_Date","lbl_Start_Date"], "click", function(e)
{

	var chart = webMI.trendFactory.getTrendByName("trend1");
	
	if (chart.control.isLiveModeRunning()) 
	{
			chart.control.stopLiveMode();
			chart.control.setMode("history");
			chart.control.loadHistory();
			webMI.gfx.setVisible("btn_start", true);
			webMI.gfx.setVisible("btn_stop", false);
	}

	Click_Prevention("open");
	webMI.gfx.setMoveX("HighChart",3000);
	webMI.trigger.fire("Real_Time_Popup_Settings", { start_date : startTime, end_date : endTime});
	let time_popup = document.getElementById("time_popup");  

	time_popup.setAttribute("x", "357");
	time_popup.setAttribute("y", "92");
});

webMI.trigger.connect("Cloese_Time_Popup", function(e)
{
	Click_Prevention("close")

	let time_popup = document.getElementById("time_popup");  
	webMI.gfx.setMoveX("HighChart",previous_x_location);
	time_popup.setAttribute("x", "0");
	time_popup.setAttribute("y", "1000");	// 화면 밖으로
	
});

///// 팝업 오픈 시 뒤에 클릭안되게 하는 화면 열기/닫기
function Click_Prevention(popup, paramter)
{
	if (popup == "open")
	{
		let shadow = document.getElementById("shadow");  
		if (paramter == undefined)
		{
			webMI.trigger.fire("Prevention_Open");	
		}
		else
		{
			webMI.trigger.fire("Prevention_Open",paramter);	
			webMI.gfx.setMoveX("HighChart",3000);
		}
		
		shadow.setAttribute("x", "0");
		shadow.setAttribute("y", "0");

	}
	else if (popup == "close")
	{
		let shadow = document.getElementById("shadow");  
		webMI.trigger.fire("Prevention_Close");
		
		shadow.setAttribute("x", "0");
		shadow.setAttribute("y", "-1000");	// 화면 밖으로
		webMI.gfx.setMoveX("HighChart",previous_x_location);
	}
}

//////현재 페이지 이외에서 팝업 요청 시 Shadow Visible, Invisible/////////////
webMI.trigger.connect("Prevention_req",function(e)
{
	let parameter = e.value.parameter;
	parameter = parameter == null ? undefined : parameter; 
	Click_Prevention(e.value.req, parameter);
});

///////////////////////////*  유저 매뉴얼 버튼 클릭 이벤트 *///////////////////////////

webMI.trigger.connect("UserManual_Open", function(e)
{
	
	Click_Prevention("open");
	let popup = document.getElementById("user_manual_popup");  
	webMI.gfx.setMoveX("HighChart",3000);
	
	popup.setAttribute("x", "603");		//960 -357 
	popup.setAttribute("y", "20");
	webMI.trigger.fire("UserManual_Move");
});

webMI.trigger.connect("UserManual_Close", function(e)
{
	Click_Prevention("close")
	let popup = document.getElementById("user_manual_popup");  
	webMI.gfx.setMoveX("HighChart",previous_x_location);
	popup.setAttribute("x", "0");
	popup.setAttribute("y", "1000");	// 화면 밖으로
	
});

//////////////////////////키패드 오픈//////////////////////////////////
webMI.trigger.connect("Keyboard_Open", function(e)
{
	var type = e.value.type;
	
	var options = {};	
	var max_len = 0;
	var password_on = false;
	
	if (e.value.type == "ID")
	{
		max_len =15;
		password_on =false;
	}
	else if(e.value.type == "PW")
	{
		max_len = 21;
		password_on = true;
	}
	else if (e.value.type == "Channel_search")
	{
		max_len =50;
		password_on =false;
		options["language"] = e.value.language;
	}
	
	options["parameter"] = type;
	options["max_len"] = max_len;
	options["password_on"] = password_on;
	
	webMI.trigger.fire("keyboard_init", options);
	
	let popup = document.getElementById("popup_keyboard");  
	popup.setAttribute("x", "310");
	popup.setAttribute("y", "285");	
});
	
////////////////키보드 종료///////////////////////////
webMI.trigger.connect("Keyboard_Close", function(e)
{
	let popup = document.getElementById("popup_keyboard");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

//////////////////////////로그인 팝업창 오픈//////////////////////////////////
webMI.trigger.connect("Login_Open", function(e)
{
	Click_Prevention("open");
	webMI.trigger.fire("Login_Popup_init");
	webMI.gfx.setMoveX("HighChart",3000);
	
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("x", "602");
	popup.setAttribute("y", "213");	
});
	
////////////////로그인 팝업창 종료///////////////////////////
webMI.trigger.connect("Login_Close", function(e)
{
	Click_Prevention("close");
	webMI.gfx.setMoveX("HighChart",previous_x_location);
	
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

////////////////로그인 팝업창 올리기///////////////////////////
webMI.trigger.connect("Login_Popup_Up", function(e)
{
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("y", "20");	
});

////////////////로그인 팝업창 내리기///////////////////////////
webMI.trigger.connect("Login_Popup_Down", function(e)
{
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("y", "213");	
});

//////////////////////////정보 팝업창 오픈//////////////////////////////////
webMI.trigger.connect("Info_Popup_Open", function(e)
{
	Click_Prevention("open");
	webMI.gfx.setMoveX("HighChart",3000);
	webMI.trigger.fire("Info_Init",e.value);	
	
	let popup = document.getElementById("info_popup");  
	popup.setAttribute("x", "602");
	popup.setAttribute("y", "213");	
});
	
////////////////정보 팝업창 팝업창 종료///////////////////////////
webMI.trigger.connect("Info_Popup_Close", function(e)
{
	Click_Prevention("close");
	webMI.gfx.setMoveX("HighChart",previous_x_location);
	
	let popup = document.getElementById("info_popup");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

////////////////채널 추가 팝업창 종료///////////////////////////
webMI.trigger.connect("Channel_Popup_Close", function(e)
{
	Click_Prevention("close");
	webMI.gfx.setMoveX("HighChart",previous_x_location);
	
	let popup = document.getElementById("channel_add_popup");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

//////////////////////////Export Done 팝업창오픈//////////////////////////////////
webMI.trigger.connect("Info_Popup_Open_Export_Done", function(e)
{
	Click_Prevention("open");
	webMI.rootWindow.stopLoading();
	webMI.trigger.fire("Info_Popup_Open", { title : "T{추출}", info : "T{추출이 완료되었습니다.}" });
	webMI.trigger.fire("Event_Add", "Export : Chart");			/////Default에 정의되어있음
	let popup = document.getElementById("info_popup");  
	popup.setAttribute("x", "602");
	popup.setAttribute("y", "213");	
});