var color = webMI.query["color"];

var btn_mode_auto_lamp = document.getElementById("btn_mode_auto_lamp");
var btn_mode_manual_lamp = document.getElementById("btn_mode_manual_lamp");
var btn_mode_inactive_lamp = document.getElementById("btn_mode_inactive_lamp");

var select_mode;
var now_mode;

var dgs_mode;
var datasource;
var select_datasource;

var dgm_addr = "AGENT.OBJECTS.SIM_OBJECTS.02.Degaussing.Degaussing_Mode._DGM"
//var dgm_addr = "AGENT.OBJECTS.Control._DGM";
var data_source_addr = "AGENT.OBJECTS.Control._DATA_Source";
var ship_data_change_addr = "AGENT.OBJECTS.03_ALGOR..Apply_Ship_Position";

var mode_popup_open = false;
var manual_popup_open = false;
var datasource_combobox_open = false;

var submarine_info_change_data = {};

var count_PSU_active = 0;
var count_PSU_all = 0;

/////////////////////피드백 보상 상태 //////////////
webMI.data.read("AGENT.OBJECTS.Control._Enable_Probe_Feedback", function(e)
{
	if (e.value == 1)
	{
		webMI.gfx.setText("tb_probe_feedback", "T{활성화}");
	}
	else
	{
		webMI.gfx.setText("tb_probe_feedback", "T{비활성화}");
	}
});

///////////보정 상태///////////////////////
webMI.data.read("AGENT.OBJECTS.Control._Enable_Probe_Correction", function(e)
{
	if (e.value == 1)
	{
		webMI.gfx.setText("tb_probe_correction", "T{활성화}");
	}
	else
	{
		webMI.gfx.setText("tb_probe_correction", "T{비활성화}");
	}
});

///////////데이터 체크 상태/////////////////
webMI.data.read("AGENT.OBJECTS.Control._Enable_Probe_DataCheck", function(e)
{
	if (e.value == 1)
	{
		webMI.gfx.setText("tb_probe_data", "T{활성화}");
	}
	else
	{
		webMI.gfx.setText("tb_probe_data", "T{비활성화}");
	}
});

var iframe= webMI.rootWindow.document.querySelector("#page_main_myframe").contentWindow.document.body;

iframe.addEventListener("click", () => {
  localStorage.setItem("NoTouchCount",0);
});      

webMI.trigger.fire("DataSource_Collapse");
webMI.trigger.fire("Submarine_Info_Data_Read");

///////////////////*  Day Night 컬러 색상 변경 *////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{	
	webMI.gfx.setFill("background_display", color.Main_Background[color_mode]);
	webMI.gfx.setFill("bento_1", color.Bento[color_mode]);
	webMI.gfx.setFill("bento_2", color.Bento[color_mode]);
	webMI.gfx.setFill("bento_3", color.Bento[color_mode]);
	webMI.gfx.setFill("bento_4", color.Bento[color_mode]);      
	webMI.gfx.setFill("bento_5", color.Bento[color_mode]);      
	
	webMI.gfx.setFill("lbl_dgs_mode",color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_datasource",color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_probe",color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_PSU",color.Font_Title[color_mode]);
	
	webMI.gfx.setFill("lbl_probe_feedback",color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_probe_alignment",color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_probe_data",color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_PSU_num",color.Font_Title[color_mode]);
	
	webMI.gfx.setFill("tb_probe_feedback",color.Font_Default[color_mode]);
	webMI.gfx.setFill("tb_probe_correction",color.Font_Default[color_mode]);
	webMI.gfx.setFill("tb_probe_data",color.Font_Default[color_mode]);
	webMI.gfx.setFill("tb_PSU_active",color.Font_Default[color_mode]);
	webMI.gfx.setFill("pic_arrow_close",color.Font_Default[color_mode]);
	webMI.gfx.setFill("pic_arrow_open",color.Font_Default[color_mode]);
	
	webMI.gfx.setFill("rect_datasource",color.Btn_Background[color_mode]);
	webMI.gfx.setFill("rect_datasource2",color.Btn_Background[color_mode]);
	
	webMI.gfx.setFill("bento_datasource1",color.Selected[color_mode]);
	webMI.gfx.setFill("bento_datasource2",color.Selected[color_mode]);
	webMI.gfx.setFill("bento_datasource3",color.Selected[color_mode]);	
	webMI.gfx.setFill("bento_datasource4",color.Selected[color_mode]);
	
	webMI.gfx.setVisible("bento_datasource1",false);
	webMI.gfx.setVisible("bento_datasource2",false);
	webMI.gfx.setVisible("bento_datasource3",false);	
	webMI.gfx.setVisible("bento_datasource4",false);
	
	webMI.gfx.setStroke("underline_1",color.Under_Line[color_mode]);
	webMI.gfx.setStroke("underline_2",color.Under_Line[color_mode]);	
	webMI.gfx.setStroke("underline_3",color.Under_Line[color_mode]);	
	webMI.gfx.setStroke("underline_4",color.Under_Line[color_mode]);	
	
	let control1 = document.getElementById("pic_arrow_open");
    control1.href.baseVal = '../../Icon/arrow_Down_' + color_mode + '.png';	
	
	let control2 = document.getElementById("pic_arrow_close");
    control2.href.baseVal = '../../Icon/arrow_Up_' + color_mode + '.png';		
	
	let combo_labels =
    [
        "lbl_master1", "lbl_master1_probe", "lbl_slave1", "lbl_slave1_map",
        "lbl_master2", "lbl_master2_map", "lbl_slave2", "lbl_slave2_probe",
        "lbl_master3", "lbl_master3_probe", "lbl_slave3", "lbl_slave3_",
        "lbl_master4", "lbl_master4_map", "lbl_slave4", "lbl_slave4_"
    ];

    combo_labels.forEach(label => webMI.gfx.setFill(label, color.Font_Combobox_Select[color_mode]));	// 기본 글자색 회색
}


///////////////////////////*  소자 모드 읽어오기  *///////////////////////////

webMI.data.read(dgm_addr, function(e)	
{
	if (e.value == 1)
	{
		dgs_mode = "수동";
	}
	else if (e.value == 2)
	{
		dgs_mode = "자동";
	}
	else if (e.value == 3)
	{
		dgs_mode = "비활성화";
	}
		
	now_mode = dgs_mode;
	Change_Mode(dgs_mode);
});


///////////////////////////*  데이터 소스 읽어오기  *///////////////////////////

webMI.data.read(data_source_addr, function(e)	
{
	if (e.value == 1)
	{
		datasource = 1;
	}
	else if (e.value == 2)
	{
		datasource = 2;
	}
	else if (e.value == 3)
	{
		datasource = 3;
	}
	else if (e.value == 4)
	{
		datasource = 4;
	}
	else
	{
		datasource = 0;
	}
	
	Datasource_Label(datasource);
});

/////////////권한 확인////////////////////////////////////////
function Prevention_Check(prevention_level, callback)
{
	webMI.trigger.fire("Prevention_Check", {level : prevention_level, callback : function(access)	
	{
		if (access == false)
		{
			webMI.trigger.fire("Info_Popup_Open", { title : "T{권한}", info : "T{해당 기능에 대한 권한이 없습니다.}" });
			return;
		}
		else
		{
			callback();
		}
	}});
}

///////////////////////////*  소자 모드 자동 버튼 클릭 이벤트  *///////////////////////////

webMI.addEvent("btn_mode_auto", "click", function(e)
{
	var temp_prevention_level =2;
	Prevention_Check(temp_prevention_level, () => {
		select_mode = "자동";
		
		if (now_mode != "자동")
		{
			Popup_Text("mode")
			Popup_Open("mode_popup",temp_prevention_level)
		}	
	});
});


///////////////////////////*  소자 모드 수동 버튼 클릭 이벤트  *///////////////////////////

webMI.addEvent("btn_mode_manual", "click", function(e)
{
	var temp_prevention_level =2;
	
	Prevention_Check(temp_prevention_level, () => {
		select_mode = "수동";
		
		if (now_mode != "수동")
		{
			Click_Prevention("open")
			Popup_Text("mode")
			Popup_Open("mode_popup",temp_prevention_level)
		}
		else
		{
			Popup_Text("mode")
			webMI.trigger.fire("Submarine_Info_Data_Read")
			webMI.gfx.setVisible("manual_popup_shadow", true);
			Popup_Open("manual_popup")
		}
		
		if (datasource_combobox_open == true)
		{
			webMI.trigger.fire("DataSource_Collapse");
		}
	});
});


///////////////////////////*  소자 모드 비활성화 버튼 클릭 이벤트  *///////////////////////////

webMI.addEvent("btn_mode_inactive", "click", function(e)
{
	let temp_prevention_level = 2;

	Prevention_Check(temp_prevention_level, () => {
		select_mode = "비활성화";
		
		if (now_mode != "비활성화")
		{
			Popup_Text("mode")
			Popup_Open("mode_popup",temp_prevention_level)
		}
		
		if (datasource_combobox_open == true)
		{
			webMI.trigger.fire("DataSource_Collapse");
		}
	});
});


///////////////////////////*  소자 모드 변경 함수  *///////////////////////////

function Change_Mode(mode)
{
	if (mode == "자동")
	{
		btn_mode_auto_lamp.setAttribute("fill", color.BtnLamp_On[color_mode]);
		btn_mode_manual_lamp.setAttribute("fill", color.BtnLamp_Off[color_mode]);
		btn_mode_inactive_lamp.setAttribute("fill", color.BtnLamp_Off[color_mode]);

		webMI.data.write(dgm_addr, 2); // 데이터 쓰기 (2 : 자동)
		
		Datsaource_Default_Label("자동");
		
		webMI.trigger.fire("btn_click", "mode_auto");
		webMI.trigger.fire("btn_active", "mode_manual");
		webMI.trigger.fire("btn_active", "mode_inactive");
	}
	else if (mode == "수동")
	{
		btn_mode_auto_lamp.setAttribute("fill", color.BtnLamp_Off[color_mode]);
		btn_mode_manual_lamp.setAttribute("fill", color.BtnLamp_On[color_mode]);
		btn_mode_inactive_lamp.setAttribute("fill", color.BtnLamp_Off[color_mode]);

		webMI.data.write(dgm_addr, 1); // 데이터 쓰기 (1 : 수동)
		
		Datsaource_Default_Label("수동");
		
		webMI.trigger.fire("btn_active", "mode_auto");
		webMI.trigger.fire("btn_active", "mode_manual");
		webMI.trigger.fire("btn_active", "mode_inactive");
	}
	else if (mode == "비활성화")
	{
		btn_mode_auto_lamp.setAttribute("fill", color.BtnLamp_Off[color_mode]);
		btn_mode_manual_lamp.setAttribute("fill", color.BtnLamp_Off[color_mode]);
		btn_mode_inactive_lamp.setAttribute("fill", color.BtnLamp_On[color_mode]);

		webMI.data.write(dgm_addr, 3); // 데이터 쓰기 (3 : 비활성화)
		
		Datsaource_Default_Label("비활성화");
		
		webMI.trigger.fire("btn_active", "mode_auto");
		webMI.trigger.fire("btn_active", "mode_manual");
		webMI.trigger.fire("btn_inactive_click", "mode_inactive");
	}
}

///////////////////////////*  코일 전원 공급기 활성화 개수 *///////////////////////////

webMI.data.subscribe("AGENT.OBJECTS.03_ALGOR..PSU_Count_Actual",function(e)
{
	count_PSU_active = e.value;

	webMI.gfx.setText("tb_PSU_active", String(count_PSU_active).padStart(2, '0') + " / " + String(count_PSU_all).padStart(2, '0'));
});

webMI.data.subscribe("AGENT.OBJECTS.03_ALGOR..PSU_Count_Sum",function(e)
{
	count_PSU_all = e.value;
	
	webMI.gfx.setText("tb_PSU_active", String(count_PSU_active).padStart(2, '0') + " / " + String(count_PSU_all).padStart(2, '0'));
});


///////////////////////////*  적용 확인 팝업 열림  *///////////////////////////

function Popup_Open(option, prevention_level)
{
	Click_Prevention("open");
	
	if (option == "mode_popup")
	{
		let mode_popup = document.getElementById("mode_popup");  
		webMI.trigger.fire("Apply_Popup_prevention_level_Set",prevention_level);				///Apply 팝업창에 Apply 가능 권한 레벨 할당
		
		mode_popup.setAttribute("x", "600");
		mode_popup.setAttribute("y", "270");

		mode_popup_open = true;
	}
	else if (option == "manual_popup")
	{
		setTimeout(() =>
		{
			manual_popup_open = true;
			let manual_popup = document.getElementById("manual_popup");  

			manual_popup.setAttribute("x", "430");
			manual_popup.setAttribute("y", "150");

		}, 50);
	}
}


///////////////////////////*  적용 확인 팝업 적용 버튼   *///////////////////////////

webMI.trigger.connect("Apply", function(e)
{
	if (mode_popup_open == true)
	{
		mode_popup_open = false;
		
		// 소자 모드 선택 후 적용
	
		if (select_mode == "자동")
		{
			webMI.trigger.fire("Apply_Popup_Cancel");	// 팝업 닫기
			Click_Prevention("close");
			now_mode = "자동"
			Change_Mode("자동");
			webMI.trigger.fire("Event_Add", "Data Change : Degaussing Mode Change - Auto");			/////Default에 정의되어있음
		}
		else if (select_mode == "수동")
		{
			now_mode = "수동"
			Change_Mode("수동");
			
			if (webMI.gfx.getText("mode_popup_lbl_title") ==  "T{소자 모드 변경}")
			{
				webMI.trigger.fire("Apply_Popup_Cancel", "no");	// 팝업 닫기
				webMI.trigger.fire("Submarine_Info_Data_Read");
				Popup_Open("manual_popup");
			}
			else
			{
				webMI.trigger.fire("Apply_Popup_Cancel");	// 팝업 닫기
			}
			
			webMI.trigger.fire("Event_Add", "Data Change : Degaussing Mode Change - Manual");			/////Default에 정의되어있음
		}
		else if (select_mode == "비활성화")
		{
			webMI.trigger.fire("Apply_Popup_Cancel");	// 팝업 닫기
			Click_Prevention("close");
			now_mode = "비활성화";
			Change_Mode("비활성화");
			
			webMI.trigger.fire("Event_Add", "Data Change : Degaussing Mode Change - Inactive");			/////Default에 정의되어있음
		}
	}
	
	if (datasource_combobox_open == true)
	{
		webMI.trigger.fire("Apply_Popup_Cancel");	// 팝업 닫기
		datasource_combobox_open = false;

		// 데이터 소스 선택 후 적용
	
		webMI.trigger.fire("DataSource_Collapse");			// 콤보 박스 닫힘
		Datasource_Label(window.selectedDataSource);	// 데이터 소스 디폴트 텍스트 변경
		
		if (window.selectedDataSource == 1)
		{
			webMI.data.write(data_source_addr, 1);	// 데이터 쓰기
			datasource = 1;
			
			webMI.trigger.fire("Event_Add", "Data Change : Data Source Change - Type 1");			/////Default에 정의되어있음
		}
		else if (window.selectedDataSource == 2)
		{
			webMI.data.write(data_source_addr, 2);	// 데이터 쓰기
			datasource = 2;
			
			webMI.trigger.fire("Event_Add", "Data Change : Data Source Change - Type 2");			/////Default에 정의되어있음
		}
		else if (window.selectedDataSource == 3)
		{
			webMI.data.write(data_source_addr, 3);	// 데이터 쓰기
			datasource = 3;
			
			webMI.trigger.fire("Event_Add", "Data Change : Data Source Change - Type 3");			/////Default에 정의되어있음
		}
		else if (window.selectedDataSource == 4)
		{
			webMI.data.write(data_source_addr, 4);	// 데이터 쓰기
			datasource = 4;
			
			webMI.trigger.fire("Event_Add", "Data Change : Data Source Change - Type 4");			/////Default에 정의되어있음
		}
	}
	
	if (manual_popup_open == true)
	{
		//webMI.trigger.fire("Submarine_Info_Data_Close");	// 팝업 닫기
		manual_popup_open = false;
		webMI.trigger.fire("Submarine_Info_Data_Close");
		webMI.trigger.fire("Apply_Popup_Cancel");	// 팝업 닫기
		// 함 정보 설정 후 적용
		
		if (submarine_info_change_data)
		{
			if (submarine_info_change_data.lbl_roll)		// 횡경사각
			{
				webMI.data.write("AGENT.OBJECTS.03_ALGOR..Roll_Temp", submarine_info_change_data.lbl_roll);	// 데이터 쓰기
				webMI.trigger.fire("Event_Add", "Data Change : Roll Change - " + submarine_info_change_data.lbl_roll + " deg");			/////Default에 정의되어있음
			}
			if (submarine_info_change_data.lbl_pitch)		// 종경사각
			{
				webMI.data.write("AGENT.OBJECTS.03_ALGOR..Pitch_Temp", submarine_info_change_data.lbl_pitch);	// 데이터 쓰기
				webMI.trigger.fire("Event_Add", "Data Change : Pitch Change - " + submarine_info_change_data.lbl_pitch + " deg");			/////Default에 정의되어있음
			}
			if (submarine_info_change_data.lbl_heading)		// 방위각
			{
				webMI.data.write("AGENT.OBJECTS.03_ALGOR..Heading_Temp", submarine_info_change_data.lbl_heading);	// 데이터 쓰기
				webMI.trigger.fire("Event_Add", "Data Change : Heading Change - " + submarine_info_change_data.lbl_heading + " deg");			/////Default에 정의되어있음
			}
			if (submarine_info_change_data.lbl_depth)		// 심도
			{
				webMI.data.write("AGENT.OBJECTS.03_ALGOR..Depth_Temp", submarine_info_change_data.lbl_depth);	// 데이터 쓰기
				webMI.trigger.fire("Event_Add", "Data Change : Depth Change - " + submarine_info_change_data.lbl_depth + " m");			/////Default에 정의되어있음
			}
			if (submarine_info_change_data.lbl_longitude)		// 경도
			{
				var minus = submarine_info_change_data.lbl_longitude.charAt(0) == "-" ? true : false;				
				var cleaned = submarine_info_change_data.lbl_longitude.replace(/[^\d]+/g, ' ').trim();
				var parts = cleaned.split(/\s+/);  // 공백 기준으로 분할
				var temp_value = DmsToDecimal(Number(parts[0]),Number(parts[1]),Number(parts[2]));
				temp_value = minus ? (-1) * temp_value : temp_value;

				webMI.data.write("AGENT.OBJECTS.03_ALGOR..Longitude_Temp", temp_value);	// 데이터 쓰기
				webMI.trigger.fire("Event_Add", "Data Change : Longitude Change - " + temp_value);			/////Default에 정의되어있음
			}
			if (submarine_info_change_data.lbl_latitude)		// 위도
			{
				var minus = submarine_info_change_data.lbl_latitude.charAt(0) == "-" ? true : false;				
				var cleaned = submarine_info_change_data.lbl_latitude.replace(/[^\d]+/g, ' ').trim();
				var parts = cleaned.split(/\s+/);  // 공백 기준으로 분할
				var temp_value = DmsToDecimal(Number(parts[0]),Number(parts[1]),Number(parts[2]));
				temp_value = minus ? (-1) * temp_value : temp_value;
				
				webMI.data.write("AGENT.OBJECTS.03_ALGOR..Latitude_Temp", temp_value);	// 데이터 쓰기
				webMI.trigger.fire("Event_Add", "Data Change : Latitude Change - " + temp_value);			/////Default에 정의되어있음
			}
			
			webMI.data.write(ship_data_change_addr, 1);
		}
		
		submarine_info_change_data = {};
	}
});

///////////////////////////*  선택된 데이터 소스 값 저장  *///////////////////////////

function handleClickDataSource(value)
{
    window.selectedDataSource = value; // 최근 클릭된 값을 저장
}


///////////////////////////*  적용 확인 팝업 취소 버튼  *///////////////////////////

webMI.trigger.connect("Apply_Popup_Cancel", function(e)
{
	submarine_info_change_data = {};

	if (e.value != "no" && manual_popup_open != true)
	{
		Click_Prevention("close");
	}

	
	let mode_popup = document.getElementById("mode_popup");  

	mode_popup.setAttribute("x", "0");
	mode_popup.setAttribute("y", "1000");	// 화면 밖으로
	
	if (select_datasource != datasource)
	{
		select_datasource = datasource;
	}
});

///////////////////////////*  함 정보 설정 팝업 닫기 버튼  *///////////////////////////

webMI.trigger.connect("Submarine_Info_Data_Close", function(e)
{
	let manual_popup = document.getElementById("manual_popup");  
	manual_popup_open = false;
	manual_popup.setAttribute("x", "650");
	manual_popup.setAttribute("y", "1000");	// 화면 밖으로
	
	Click_Prevention("close");
	
});


///////////////////////////*  함 정보 설정 팝업 적용 버튼 -> 적용 확인 팝업  *///////////////////////////

webMI.trigger.connect("Submarine_Info_Data_Apply", function(e)
{
	var temp_prevention_level =2;
	Popup_Text("submarine_info_data");
	Popup_Open("mode_popup", temp_prevention_level);
	
	if (typeof e == "object")
	{
		submarine_info_change_data = e.value;		// 수동 설정한 함 정보 저장
	}
});


///// 팝업 오픈 시 뒤에 클릭안되게 하는 화면 열기/닫기
function Click_Prevention(popup, paramter)
{
	if (popup == "open")
	{
		let shadow = document.getElementById("shadow");  
		
		if (paramter == undefined)
		{
			webMI.trigger.fire("Prevention_Open");	
		}
		else
		{
			webMI.trigger.fire("Prevention_Open",paramter);	
		}
		
		shadow.setAttribute("x", "0");
		shadow.setAttribute("y", "0");

	}
	else if (popup == "close")
	{
		let shadow = document.getElementById("shadow");  
		webMI.trigger.fire("Prevention_Close");
		
		shadow.setAttribute("x", "0");
		shadow.setAttribute("y", "-1000");	// 화면 밖으로
	}
}

//////현재 페이지 이외에서 팝업 요청 시 Shadow Visible, Invisible/////////////
webMI.trigger.connect("Prevention_req",function(e)
{
	let parameter = e.value.parameter;
	parameter = parameter == null ? undefined : parameter; 
	Click_Prevention(e.value.req, parameter);
});

///////////////////////////*  데이터 소스 라벨 텍스트 변경  *///////////////////////////

function Datasource_Label(datasource)
{
	webMI.gfx.setVisible("bento_datasource1",false);
	webMI.gfx.setVisible("bento_datasource2",false);
	webMI.gfx.setVisible("bento_datasource3",false);	
	webMI.gfx.setVisible("bento_datasource4",false);    
    
    if (datasource >= 1 && datasource <=4)
    {
		webMI.gfx.setVisible("bento_datasource" + datasource,true);    
    }
	
    if (datasource == 1)
    {
        webMI.gfx.setText("lbl_datasource_master", "T{3축 자기센서 프로브}");	// 디폴트
        webMI.gfx.setText("lbl_datasource_slave", "T{지구 자기장 맵}");
    }
    else if (datasource == 2)
    {
        webMI.gfx.setText("lbl_datasource_master", "T{지구 자기장 맵}");	// 디폴트
        webMI.gfx.setText("lbl_datasource_slave", "T{3축 자기센서 프로브}");
    }
    else if (datasource == 3)
    {
        webMI.gfx.setText("lbl_datasource_master", "T{3축 자기센서 프로브}");	// 디폴트
        webMI.gfx.setText("lbl_datasource_slave", "\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0-");
    }
    else if (datasource == 4)
    {
        webMI.gfx.setText("lbl_datasource_master", "T{지구 자기장 맵}");	// 디폴트
        webMI.gfx.setText("lbl_datasource_slave", "\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0-");
    }
    else if (datasource == 0)
    {
        webMI.gfx.setText("lbl_datasource_master", "");	// 디폴트
        webMI.gfx.setText("lbl_datasource_slave", "");
    }
    
    webMI.gfx.setVisible("lbl_master",true);
	webMI.gfx.setVisible("lbl_slave",true);
	webMI.gfx.setVisible("lbl_datasource_master",true);	
	webMI.gfx.setVisible("lbl_datasource_slave",true);    
}


///////////////////////////*  데이터 소스 디폴트 라벨 텍스트 변경  *///////////////////////////

function Datsaource_Default_Label(auto)
{
	if (auto == "자동")
	{
		webMI.gfx.setFill("lbl_master", color.Font_Combobox_Select[color_mode]);
		webMI.gfx.setFill("lbl_datasource_master", color.Font_Combobox_Select[color_mode]);
		webMI.gfx.setFill("lbl_slave", color.Font_Combobox_Select[color_mode]);
		webMI.gfx.setFill("lbl_datasource_slave", color.Font_Combobox_Select[color_mode]);
	}
	else
	{
		webMI.gfx.setFill("lbl_master", color.Font_Disable[color_mode]);
		webMI.gfx.setFill("lbl_datasource_master", color.Font_Disable[color_mode]);
		webMI.gfx.setFill("lbl_slave", color.Font_Disable[color_mode]);
		webMI.gfx.setFill("lbl_datasource_slave", color.Font_Disable[color_mode]);
	}
}


///////////////////////////*  데이터 소스 콤보박스 확장  *///////////////////////////

webMI.addEvent("btn_click_datasource", "click", function(e)
{
	if (now_mode == "자동")
	{
		if (datasource_combobox_open == false)
		{
			Datasource_Label(datasource);
			
			//Click_Prevention("open");
		
			let datasource_expand = document.getElementById("datasource_expand"); 
			datasource_expand.setAttribute("transform", "matrix(1,0,0,1,-688,0)");
			
			datasource_combobox_open = true;
		}
	}
});


///////////////////////////*  데이터 소스 콤보박스 축소  *///////////////////////////

webMI.addEvent("btn_click_collapse", "click", function(e)
{
	if (datasource_combobox_open == true)
	{
		webMI.trigger.fire("DataSource_Collapse");
	}
});


webMI.trigger.connect("DataSource_Collapse", function(e)
{
	//Click_Prevention("close");
	
	let datasource_expand = document.getElementById("datasource_expand");
	datasource_expand.setAttribute("transform", "matrix(1,0,0,1,0,0)");
	
	datasource_combobox_open = false;
});


///////////////////////////*  데이터 소스 콤보박스 첫번째 버튼 클릭 이벤트  *///////////////////////////

webMI.addEvent("click_datasource1", "click", function(e)
{
	var temp_prevention_level =2;
	Prevention_Check(temp_prevention_level, () => {
		
		Popup_Text("datasource", "1")
		handleClickDataSource(1);
		
		if (datasource != 1)
		{
			Popup_Open("mode_popup", temp_prevention_level)
		}
	
	});
});


///////////////////////////*  데이터 소스 콤보박스 두번째 버튼 클릭 이벤트  *///////////////////////////

webMI.addEvent("click_datasource2", "click", function(e)
{
	var temp_prevention_level =2;
	Prevention_Check(temp_prevention_level, () => {
		
		Popup_Text("datasource", "2")
		handleClickDataSource(2);
		
		if (datasource != 2)
		{
			Popup_Open("mode_popup",temp_prevention_level)
		}
	});
});


///////////////////////////*  데이터 소스 콤보박스 세번째 버튼 클릭 이벤트  *///////////////////////////

webMI.addEvent("click_datasource3", "click", function(e)
{
	var temp_prevention_level =2;
	Prevention_Check(temp_prevention_level, () => {

		Popup_Text("datasource", "3")
		handleClickDataSource(3);
		
		if (datasource != 3)
		{
			Popup_Open("mode_popup",temp_prevention_level)
		}
	});
});


///////////////////////////*  데이터 소스 콤보박스 네번째 버튼 클릭 이벤트  *///////////////////////////

webMI.addEvent("click_datasource4", "click", function(e)
{
	var temp_prevention_level =2;
	Prevention_Check(temp_prevention_level, () => {
		
		Popup_Text("datasource", "4")
		handleClickDataSource(4);
		
		if (datasource != 4)
		{
			Popup_Open("mode_popup",temp_prevention_level)
		}
	});
});


///////////////////////////*  적용 확인 팝업 텍스트 변경 함수  *///////////////////////////

function Popup_Text(option1, option2)
{
	if (option1 == "datasource")	// 데이터 소스 변경
	{
		webMI.gfx.setText("mode_popup_lbl_title", "T{데이터 소스 변경}");
		
		webMI.gfx.setVisible("mode_popup_lbl_content", false);
		webMI.gfx.setVisible("mode_popup_lbl_content_line1", true);
		webMI.gfx.setVisible("mode_popup_lbl_content_line2", true);
		
		if (option2 == "1")
		{
			webMI.gfx.setText("mode_popup_lbl_content_line1", "T{주요} : T{3축 자기센서 프로브} / T{비교} : T{지구 자기장 맵}")		////////////////////////// 영문 확인
			webMI.gfx.setText("mode_popup_lbl_content_line2", "T{변경하시겠습니까?}")
		}
		else if (option2 == "2")
		{
			webMI.gfx.setText("mode_popup_lbl_content_line1", "T{주요} : T{지구 자기장 맵} / T{비교} : T{3축 자기센서 프로브}")
			webMI.gfx.setText("mode_popup_lbl_content_line2", "T{변경하시겠습니까?}")
		}
		else if (option2 == "3")
		{
			webMI.gfx.setText("mode_popup_lbl_content_line1", "T{주요} : T{3축 자기센서 프로브} / T{비교} : - ")
			webMI.gfx.setText("mode_popup_lbl_content_line2", "T{변경하시겠습니까?}")
		}
		else if (option2 == "4")
		{
			webMI.gfx.setText("mode_popup_lbl_content_line1", "T{주요} : T{지구 자기장 맵} / T{비교} : - ")
			webMI.gfx.setText("mode_popup_lbl_content_line2", "T{변경하시겠습니까?}")
		}
	}
	else if (option1 == "mode")	// 소자 모드 변경
	{
		webMI.gfx.setText("mode_popup_lbl_title", "T{소자 모드 변경}");
		
		webMI.gfx.setVisible("mode_popup_lbl_content", true);
		webMI.gfx.setVisible("mode_popup_lbl_content_line1", false);
		webMI.gfx.setVisible("mode_popup_lbl_content_line2", false);
		
		if (select_mode == "비활성화")
		{
			webMI.gfx.setText("mode_popup_lbl_content", "T{비활성화로 변경하시겠습니까?}");
		}
		else if (select_mode == "자동")
		{
			webMI.gfx.setText("mode_popup_lbl_content", "T{자동 모드로 변경하시겠습니까?}");
		}
		else if (select_mode == "수동")
		{
			webMI.gfx.setText("mode_popup_lbl_content", "T{수동 모드로 변경하시겠습니까?}");
		}
	}
	else if (option1 == "submarine_info_data")	// 함 정보 설정 변경
	{
		webMI.gfx.setText("mode_popup_lbl_title", "T{함 정보 설정 변경}");
		
		webMI.gfx.setVisible("mode_popup_lbl_content", true);
		webMI.gfx.setVisible("mode_popup_lbl_content_line1", false);
		webMI.gfx.setVisible("mode_popup_lbl_content_line2", false);
		
		webMI.gfx.setText("mode_popup_lbl_content", "T{함 정보 설정을 변경하시겠습니까?}");
	}
}

////////// 경도/위도 값 반환 //////////////
function DmsToDecimal(degrees, minutes, seconds) {
  return degrees + minutes / 60 + seconds / 3600;
}

///////////////////////////*  유저 매뉴얼 버튼 클릭 이벤트 *///////////////////////////

webMI.trigger.connect("UserManual_Open", function(e)
{
	
	Click_Prevention("open");
	let popup = document.getElementById("user_manual_popup");  

	popup.setAttribute("x", "603");		//960 -357 
	popup.setAttribute("y", "20");
	webMI.trigger.fire("UserManual_Move");
});

webMI.trigger.connect("UserManual_Close", function(e)
{
	Click_Prevention("close")
	let popup = document.getElementById("user_manual_popup");  
	popup.setAttribute("x", "0");
	popup.setAttribute("y", "1000");	// 화면 밖으로
	
});

//////////////////////////키패드 오픈//////////////////////////////////
webMI.trigger.connect("Keyboard_Open", function(e)
{
	var type = e.value.type;
	
	var options = {};	
	var max_len = 0;
	var password_on = false;
	
	if (e.value.type == "ID")
	{
		max_len =15;
		password_on =false;
	}
	else if(e.value.type == "PW")
	{
		max_len = 21;
		password_on = true;
	}	
	
	options["parameter"] = type;
	options["max_len"] = max_len;
	options["password_on"] = password_on;
	
	webMI.trigger.fire("keyboard_init", options);
	
	let popup = document.getElementById("popup_keyboard");  
	popup.setAttribute("x", "310");
	popup.setAttribute("y", "285");	
});
	
////////////////키보드 종료///////////////////////////
webMI.trigger.connect("Keyboard_Close", function(e)
{
	let popup = document.getElementById("popup_keyboard");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

//////////////////////////로그인 팝업창 오픈//////////////////////////////////
webMI.trigger.connect("Login_Open", function(e)
{
	Click_Prevention("open");
	webMI.trigger.fire("Login_Popup_init");
	
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("x", "602");
	popup.setAttribute("y", "213");	
});
	
////////////////로그인 팝업창 종료///////////////////////////
webMI.trigger.connect("Login_Close", function(e)
{
	Click_Prevention("close");
	
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

////////////////로그인 팝업창 올리기///////////////////////////
webMI.trigger.connect("Login_Popup_Up", function(e)
{
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("y", "20");	
});

////////////////로그인 팝업창 내리기///////////////////////////
webMI.trigger.connect("Login_Popup_Down", function(e)
{
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("y", "213");	
});

//////////////////////////정보 팝업창 오픈//////////////////////////////////
webMI.trigger.connect("Info_Popup_Open", function(e)
{
	Click_Prevention("open");
	webMI.trigger.fire("Info_Init",e.value);	
	
	let popup = document.getElementById("info_popup");  
	popup.setAttribute("x", "602");
	popup.setAttribute("y", "213");	
});
	
////////////////정보 팝업창 종료///////////////////////////
webMI.trigger.connect("Info_Popup_Close", function(e)
{
	Click_Prevention("close");
	
	let popup = document.getElementById("info_popup");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
	
	let popup2 = document.getElementById("manual_popup");  
	popup2.setAttribute("x", "2000");
	popup2.setAttribute("y", "2000");	
});


