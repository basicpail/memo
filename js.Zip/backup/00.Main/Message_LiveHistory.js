var color = webMI.query["color"];

///////////////////////////*  로드 후 visible *///////////////////////////
/*
 webMI.gfx.setVisible("Live_List", false);
 
webMI.addOnload(function() {
    webMI.gfx.setVisible("Live_List",true);
});
*/
var color_list = webMI.query["color_list"];
var startTime;
var endTime;
var serching = false;
var timerId = null;

var iframe= webMI.rootWindow.document.querySelector("#page_main_myframe").contentWindow.document.body;

iframe.addEventListener("click", () => {
  localStorage.setItem("NoTouchCount",0);
});   

///////////////////////////*  주/야간 색상 변경  *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	webMI.gfx.setFill("background_display", color.Main_Background[color_mode]);
	
	webMI.gfx.setFill("bento_1", color.Bento[color_mode]);
	webMI.gfx.setFill("bento_2", color.Bento[color_mode]);
	
	webMI.gfx.setStroke("table_header", color.MSG_Table_Border[color_mode]);
	webMI.gfx.setFill("table_header", color.Table_Title[color_mode]);
		
	webMI.gfx.setStroke("btn_All_Alarm_background", "none");
	webMI.gfx.setFill("btn_All_Alarm_background", "none");
	webMI.gfx.setFill("btn_All_Alarm_text", color.Font_Default[color_mode]);
	
	webMI.gfx.setStroke("btn_Live_Alarm_background", color.Selected[color_mode]);
	webMI.gfx.setFill("btn_Live_Alarm_background", color.Tab_Selected_Title_Background[color_mode]);
	webMI.gfx.setFill("btn_Live_Alarm_text", color.Font_Selected_Title[color_mode]);
	
	webMI.gfx.setStroke("btn_Event_background", "none");
	webMI.gfx.setFill("btn_Event_background", "none");
	webMI.gfx.setFill("btn_Event_text", color.Font_Default[color_mode]);
	
	webMI.gfx.setFill("lbl_StartTime", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl_Start_Date", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl_EndTime", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl_End_Date", color.Font_Default[color_mode]);
	webMI.gfx.setFill("lbl_wave", color.Font_Default[color_mode]);
	
	webMI.gfx.setStroke("line_1", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_2", color.Under_Line[color_mode]);
	
	let control1 = document.getElementById("img_export");
	control1.href.baseVal = '../../Icon/Export_' + color_mode + '.png';
}

/////////////히스토리 apply/////////////////////////////////

webMI.addEvent("btn_Search", "click", function(e) {
var id = "btn_Search";
var value = true;

webMI.trigger.fire("History_Search",[startTime,endTime],"History_List");

serching = true;
});

///////////히스토리 날짜 범위 초기 세팅/////////////////////
webMI.addOnload(function(){

var dt_start = new Date();
	dt_start.setHours(0);
	dt_start.setMinutes(0);
	dt_start.setSeconds(0);
	dt_start.setMilliseconds(0);
	var dt_end = new Date();
	
	startTime = dt_start.getTime();
	endTime = dt_end.getTime();
	
	webMI.gfx.setText("lbl_Start_Date",Timstamp_to_DateString(startTime));
	webMI.gfx.setText("lbl_End_Date",Timstamp_to_DateString(endTime));



});


///////////////////////////*  탭 전환 *///////////////////////////

// 전체 경보 탭
webMI.addEvent("btn_All_Alarm", "click", function(e) {
	webMI.display.openDisplay("AGENT.DISPLAYS.00.Main.Message_AllHistory");
});

// 이벤트 탭
webMI.addEvent("btn_Event", "click", function(e) {
	webMI.display.openDisplay("AGENT.DISPLAYS.00.Main.Message_EventHistory");
});

////////Time Stamp -> Date String//////////////////
function Timstamp_to_DateString(timestamp)
{
	date = new Date(timestamp);
	var hours = ("0" + date.getHours()).slice(-2);
	var minutes = ("0" + date.getMinutes()).slice(-2);
	var seconds = ("0" + date.getSeconds()).slice(-2);
	var day = ("0" + date.getDate()).slice(-2);
	var month = ("0" + (date.getMonth() + 1)).slice(-2);
	var YEAR = (date.getFullYear()); //.slice(-2);
	
	var timeString = "%Y/%M/%D %H:%m:%s";
	timeString = timeString.replace(/%H/, hours);
	timeString = timeString.replace(/%m/, minutes);
	timeString = timeString.replace(/%s/, seconds);
	timeString = timeString.replace(/%Y/, YEAR);
	timeString = timeString.replace(/%M/, month);
	timeString = timeString.replace(/%D/, day);
	
	return timeString;
}

///////////////Date 값 변경 시 값 Read////////////////////
webMI.trigger.connect("Period_Date_Value",function (e) {
	startTime = e.value.start_date;
	endTime = e.value.end_date;
	
	webMI.gfx.setText("lbl_Start_Date",Timstamp_to_DateString(startTime));
	webMI.gfx.setText("lbl_End_Date",Timstamp_to_DateString(endTime));
});

///////////////////////////*  검색 시간 버튼 클릭 이벤트 *///////////////////////////

webMI.addEvent("btn_1H", "click", function(e)
{
	var dt_start = new Date();
	dt_start.setHours(dt_start.getHours() - 1);	
	
	var dt_end = new Date();
	
	startTime = dt_start.getTime();
	endTime = dt_end.getTime();
	
	webMI.gfx.setText("lbl_Start_Date",Timstamp_to_DateString(startTime));
	webMI.gfx.setText("lbl_End_Date",Timstamp_to_DateString(endTime));
});


webMI.addEvent("btn_3H", "click", function(e)
{
	var dt_start = new Date();
	dt_start.setHours(dt_start.getHours() - 3);	
	
	var dt_end = new Date();
	
	startTime = dt_start.getTime();
	endTime = dt_end.getTime();
	
	webMI.gfx.setText("lbl_Start_Date",Timstamp_to_DateString(startTime));
	webMI.gfx.setText("lbl_End_Date",Timstamp_to_DateString(endTime));
});


webMI.addEvent("btn_6H", "click", function(e)
{
	var dt_start = new Date();
	dt_start.setHours(dt_start.getHours() - 6);	
	
	var dt_end = new Date();
	
	startTime = dt_start.getTime();
	endTime = dt_end.getTime();
	
	webMI.gfx.setText("lbl_Start_Date",Timstamp_to_DateString(startTime));
	webMI.gfx.setText("lbl_End_Date",Timstamp_to_DateString(endTime));
});


webMI.addEvent("btn_12H", "click", function(e)
{
	var dt_start = new Date();
	dt_start.setHours(dt_start.getHours() - 12);	
	
	var dt_end = new Date();
	
	startTime = dt_start.getTime();
	endTime = dt_end.getTime();
	
	webMI.gfx.setText("lbl_Start_Date",Timstamp_to_DateString(startTime));
	webMI.gfx.setText("lbl_End_Date",Timstamp_to_DateString(endTime));
});


webMI.addEvent("btn_1D", "click", function(e)
{
	var dt_start = new Date();
	dt_start.setMonth(dt_start.getMonth() - 1);
	
	var dt_end = new Date();
	
	startTime = dt_start.getTime();
	endTime = dt_end.getTime();
	
	webMI.gfx.setText("lbl_Start_Date",Timstamp_to_DateString(startTime));
	webMI.gfx.setText("lbl_End_Date",Timstamp_to_DateString(endTime));
});


webMI.addEvent("btn_1W", "click", function(e)
{
	var dt_start = new Date();
	dt_start.setDate(dt_start.getDate() - 7);
	
	var dt_end = new Date();
	
	startTime = dt_start.getTime();
	endTime = dt_end.getTime();
	
	webMI.gfx.setText("lbl_Start_Date",Timstamp_to_DateString(startTime));
	webMI.gfx.setText("lbl_End_Date",Timstamp_to_DateString(endTime));
});


webMI.addEvent("btn_1M", "click", function(e)
{
	var dt_start = new Date();
	dt_start.setMonth(dt_start.getMonth() - 1);
	
	var dt_end = new Date();
	
	startTime = dt_start.getTime();
	endTime = dt_end.getTime();
	
	webMI.gfx.setText("lbl_Start_Date",Timstamp_to_DateString(startTime));
	webMI.gfx.setText("lbl_End_Date",Timstamp_to_DateString(endTime));
});

/////////////권한 확인////////////////////////////////////////
function Prevention_Check(prevention_level, callback)
{
	webMI.trigger.fire("Prevention_Check", {level : prevention_level, callback : function(access)	
	{
		if (access == false)
		{
			webMI.trigger.fire("Info_Popup_Open", { title : "T{권한}", info : "T{해당 기능에 대한 권한이 없습니다.}" });
			return;
		}
		else
		{
			callback();
		}
	}});
}

webMI.addEvent("btn_export", "click", function(e) {
	let temp_prevention_level = 3;
	
	Prevention_Check(temp_prevention_level, () => {
		webMI.rootWindow.startLoading(0,0,1920,1080);	// 로딩 오버레이
		setTimeout(() => {webMI.trigger.fire("History_Export");},5);
	});
});

///////////////////////////*  시간 설정 버튼 클릭 이벤트 *///////////////////////////

webMI.addEvent(["lbl_End_Date","lbl_Start_Date"], "click", function(e)
{
	Click_Prevention("open");
	webMI.gfx.setVisible("Live_List", false);
	webMI.trigger.fire("Real_Time_Popup_Settings", { start_date : startTime, end_date : endTime});
	let time_popup = document.getElementById("time_popup");  

	time_popup.setAttribute("x", "357");
	time_popup.setAttribute("y", "92");
});

webMI.trigger.connect("Cloese_Time_Popup", function(e)
{
	Click_Prevention("close")
	webMI.gfx.setVisible("Live_List", true);
	let time_popup = document.getElementById("time_popup");  

	time_popup.setAttribute("x", "0");
	time_popup.setAttribute("y", "1000");	// 화면 밖으로
	
});

///// 팝업 오픈 시 뒤에 클릭안되게 하는 화면 열기/닫기
function Click_Prevention(popup, paramter)
{
	if (popup == "open")
	{
		let shadow = document.getElementById("shadow");  
		if (paramter == undefined)
		{
			webMI.trigger.fire("Prevention_Open");	
		}
		else
		{
			webMI.trigger.fire("Prevention_Open",paramter);	
			webMI.gfx.setVisible("Live_List", false);
		}
		
		shadow.setAttribute("x", "0");
		shadow.setAttribute("y", "0");

	}
	else if (popup == "close")
	{
		let shadow = document.getElementById("shadow");  
		webMI.trigger.fire("Prevention_Close");
		
		shadow.setAttribute("x", "0");
		shadow.setAttribute("y", "-1000");	// 화면 밖으로
		webMI.gfx.setVisible("Live_List", true);
	}
}

//////현재 페이지 이외에서 팝업 요청 시 Shadow Visible, Invisible/////////////
webMI.trigger.connect("Prevention_req",function(e)
{
	let parameter = e.value.parameter;
	parameter = parameter == null ? undefined : parameter; 
	Click_Prevention(e.value.req, parameter);
});


///////////////// Export/////////////////////////////////
webMI.addEvent("btn_export", "click", function(e) {
webMI.trigger.fire("Alarm_Export");
});

///////////////////////////*  유저 매뉴얼 버튼 클릭 이벤트 *///////////////////////////

webMI.trigger.connect("UserManual_Open", function(e)
{
	
	Click_Prevention("open");
	let popup = document.getElementById("user_manual_popup");  
	webMI.gfx.setVisible("Live_List", false);
	
	popup.setAttribute("x", "603");		//960 -357 
	popup.setAttribute("y", "20");
	webMI.trigger.fire("UserManual_Move");
});

webMI.trigger.connect("UserManual_Close", function(e)
{
	Click_Prevention("close")
	let popup = document.getElementById("user_manual_popup");  
	webMI.gfx.setVisible("Live_List", true);
	
	popup.setAttribute("x", "0");
	popup.setAttribute("y", "1000");	// 화면 밖으로
	
});

//////////////////////////키패드 오픈//////////////////////////////////
webMI.trigger.connect("Keyboard_Open", function(e)
{
	var type = e.value.type;
	
	var options = {};	
	var max_len = 0;
	var password_on = false;
	
	if (e.value.type == "ID")
	{
		max_len =15;
		password_on =false;
	}
	else if(e.value.type == "PW")
	{
		max_len = 21;
		password_on = true;
	}	
	
	options["parameter"] = type;
	options["max_len"] = max_len;
	options["password_on"] = password_on;
	
	webMI.trigger.fire("keyboard_init", options);
	
	let popup = document.getElementById("popup_keyboard");  
	popup.setAttribute("x", "310");
	popup.setAttribute("y", "285");	
});
	
////////////////키보드 종료///////////////////////////
webMI.trigger.connect("Keyboard_Close", function(e)
{
	let popup = document.getElementById("popup_keyboard");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

//////////////////////////로그인 팝업창 오픈//////////////////////////////////
webMI.trigger.connect("Login_Open", function(e)
{
	Click_Prevention("open");
	webMI.trigger.fire("Login_Popup_init");
	webMI.gfx.setVisible("Live_List", false);
	
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("x", "602");
	popup.setAttribute("y", "213");	
});
	
////////////////로그인 팝업창 종료///////////////////////////
webMI.trigger.connect("Login_Close", function(e)
{
	Click_Prevention("close");
	webMI.gfx.setVisible("Live_List", true);
	
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

////////////////로그인 팝업창 올리기///////////////////////////
webMI.trigger.connect("Login_Popup_Up", function(e)
{
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("y", "20");	
});

////////////////로그인 팝업창 내리기///////////////////////////
webMI.trigger.connect("Login_Popup_Down", function(e)
{
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("y", "213");	
});

//////////////////////////정보 팝업창 오픈//////////////////////////////////
webMI.trigger.connect("Info_Popup_Open", function(e)
{
	Click_Prevention("open");
	webMI.gfx.setVisible("Live_List", false);
	webMI.trigger.fire("Info_Init",e.value);	
	
	let popup = document.getElementById("info_popup");  
	popup.setAttribute("x", "602");
	popup.setAttribute("y", "213");	
});
	
////////////////정보 팝업창 종료///////////////////////////
webMI.trigger.connect("Info_Popup_Close", function(e)
{
	Click_Prevention("close");
	webMI.gfx.setVisible("Live_List", true);
	
	let popup = document.getElementById("info_popup");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

