var color = webMI.query["color"];

var language_mode;

var btn_ko_lamp = document.getElementById("btn_ko_lamp");
var btn_en_lamp = document.getElementById("btn_en_lamp");

var btn_night_lamp = document.getElementById("btn_night_lamp");
var btn_day_lamp = document.getElementById("btn_day_lamp");

var btn_auto_button_label = document.getElementById("btn_auto_button_label");
var btn_manual_button_label = document.getElementById("btn_manual_button_label");

var time_setting;

var iframe= webMI.rootWindow.document.querySelector("#page_main_myframe").contentWindow.document.body;

iframe.addEventListener("click", () => {
  localStorage.setItem("NoTouchCount",0);
});   

///////////////////////////*  주/야간 모드 읽어오기 *///////////////////////////
var color_mode = localStorage.getItem("Color_Mode");
Color_Day_Night(color_mode);

webMI.trigger.connect("Color_Mode_Change",function(e)
{
	color_mode = e.value;
	Color_Day_Night(color_mode);
});

function Color_Day_Night(color_mode)
{
	if (color_mode == "Day")
	{
		btn_day_lamp.setAttribute("fill", color.BtnLamp_On.Day);
		btn_night_lamp.setAttribute("fill", color.BtnLamp_Off.Day);
	}
	else if (color_mode == "Night")
	{
		btn_day_lamp.setAttribute("fill", color.BtnLamp_Off.Night);
		btn_night_lamp.setAttribute("fill", color.BtnLamp_On.Night);
	}
	
	webMI.gfx.setFill("back_display", color.Main_Background[color_mode]);
	webMI.gfx.setFill("bento_1", color.Bento[color_mode]);
	webMI.gfx.setFill("bento_2", color.Bento[color_mode]);
	webMI.gfx.setFill("bento_3", color.Bento[color_mode]);
	
	webMI.gfx.setFill("lbl_display", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_theme", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_brightness", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_brightness2", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_language_time", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_language", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_time", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_year", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_month", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_day", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_hour", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_min", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_sec", color.Font_Title[color_mode]);
	webMI.gfx.setFill("lbl_sw_vesion", color.Font_Title[color_mode]);
	
	
	webMI.gfx.setFill("time_Year", color.Font_Default[color_mode]);
	webMI.gfx.setFill("time_Month", color.Font_Default[color_mode]);
	webMI.gfx.setFill("time_Date", color.Font_Default[color_mode]);
	webMI.gfx.setFill("time_Hour", color.Font_Default[color_mode]);
	webMI.gfx.setFill("time_Minute", color.Font_Default[color_mode]);
	webMI.gfx.setFill("time_Second", color.Font_Default[color_mode]);

	webMI.gfx.setStroke("line_1", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_2", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_3", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_4", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_5", color.Under_Line[color_mode]);
	webMI.gfx.setStroke("line_6", color.Under_Line[color_mode]);

	language_mode = localStorage.getItem("Language_Mode");
	if (language_mode == "ko")
	{
		btn_en_lamp.setAttribute("fill", color.BtnLamp_Off[color_mode]);
		btn_ko_lamp.setAttribute("fill", color.BtnLamp_On[color_mode]);
	}
	else if (language_mode == "en")
	{
		btn_en_lamp.setAttribute("fill", color.BtnLamp_On[color_mode]);
		btn_ko_lamp.setAttribute("fill", color.BtnLamp_Off[color_mode]);
	}
}

///////////// 시간설정 란의 시간을 실시간으로 업데이트/////////////////////////////////////
Time();

function Time()
{
	let d = new Date();
    
    let year = String(d.getUTCFullYear()).padStart(2, '0');
    let month = String(d.getUTCMonth() + 1).padStart(2, '0');
    let date = String(d.getUTCDate()).padStart(2, '0');
    let hour = String(d.getUTCHours()).padStart(2, '0');
    let min = String(d.getUTCMinutes()).padStart(2, '0');    
    let sec = String(d.getUTCSeconds()).padStart(2, '0');

	webMI.gfx.setText("time_Year", year);
	webMI.gfx.setText("time_month", month);
	webMI.gfx.setText("time_date", date);
	webMI.gfx.setText("time_hour", hour);
	webMI.gfx.setText("time_min", min);
	webMI.gfx.setText("time_sec", sec);

    setTimeout(Time, 1000);
}

///////////////////////////*  국문 버튼 클릭 이벤트 *///////////////////////////

webMI.addEvent("btn_ko", "click", function(e)
{	
	if (language_mode != "ko")
	{
		webMI.rootWindow.startLoading(0,0,1920,1080);	// 로딩 오버레이
		localStorage.setItem("Language_Change", true);	// 로컬 스토리지 데이터 쓰기
		
		setTimeout(() => {
			language_mode = "ko";
			const change_language = webMI.callExtension("SYSTEM.LIBRARY.PROJECT.QUICKDYNAMICS.LanguageChange",
			{
				"globalFontColor" : "#575757",
				"globalFillColor" : "#e5e5e5",
				"globalFillColor2" : "#575757",
				"globalBorderColor" : "#d7d7d7"
			});
			change_language("switchedlanguage",language_mode,["myframe"], undefined, undefined, undefined);
			localStorage.setItem("Language_Mode", language_mode);
			webMI.trigger.fire("Event_Add", "Language Change : Korean");			/////Default에 정의되어있음
			location.reload();
		},1000);
	}
	
});

///////////////////////////*  영문 버튼 클릭 이벤트 *///////////////////////////

webMI.addEvent("btn_en", "click", function(e)
{
	if (language_mode != "en")
	{
		webMI.rootWindow.startLoading(0,0,1920,1080);	// 로딩 오버레이
		localStorage.setItem("Language_Change", true);	// 로컬 스토리지 데이터 쓰기
		
		setTimeout(() => {
			language_mode = "en";
			const change_language = webMI.callExtension("SYSTEM.LIBRARY.PROJECT.QUICKDYNAMICS.LanguageChange",
			{
				"globalFontColor" : "#575757",
				"globalFillColor" : "#e5e5e5",
				"globalFillColor2" : "#575757",
				"globalBorderColor" : "#d7d7d7"
			});
			change_language("switchedlanguage",language_mode,["myframe"], undefined, undefined, undefined);
			localStorage.setItem("Language_Mode", language_mode);
			webMI.trigger.fire("Event_Add", "Language Change : English");			/////Default에 정의되어있음
			location.reload();
		},1000);
	}
});

///////////////////////////*  주간 버튼 클릭 이벤트 *///////////////////////////

webMI.addEvent("btn_day", "click", function(e)
{
	if (color_mode == "Day")
	{
		return;
	}
		
	color_mode = "Day";
	webMI.trigger.fire("Color_Mode_Change", color_mode);
	localStorage.setItem("Color_Mode", color_mode);
	webMI.trigger.fire("Event_Add", "Thema Change : Day");			/////Default에 정의되어있음
});


///////////////////////////*  야간 버튼 클릭 이벤트 *///////////////////////////

webMI.addEvent("btn_night", "click", function(e)
{
	if (color_mode == "Night")
	{
		return;
	}
	
	color_mode = "Night";
	webMI.trigger.fire("Color_Mode_Change", color_mode);
	localStorage.setItem("Color_Mode", color_mode);
	
	webMI.trigger.fire("Event_Add", "Thema Change : Night");			/////Default에 정의되어있음
});

/////////////권한 확인////////////////////////////////////////
function Prevention_Check(prevention_level, callback)
{
	webMI.trigger.fire("Prevention_Check", {level : prevention_level, callback : function(access)	
	{
		if (access == false)
		{
			webMI.trigger.fire("Info_Popup_Open", { title : "T{권한}", info : "T{해당 기능에 대한 권한이 없습니다.}" });
			return;
		}
		else
		{
			callback();
		}
	}});
}

///////////////////////////*  시간 설정 버튼 클릭 이벤트 *///////////////////////////

webMI.addEvent("btn_time", "click", function(e)
{
	let temp_prevention_level = 3;
	
	Prevention_Check(temp_prevention_level, () => {
		Click_Prevention("open");
	
		webMI.trigger.fire("Real_Time_Popup_Settings");
		
		let time_popup = document.getElementById("time_popup");  
	
		time_popup.setAttribute("x", "140");
		time_popup.setAttribute("y", "170");
	});
});

webMI.trigger.connect("Cloese_Time_Popup", function(e)
{
	Click_Prevention("close")
	
	let time_popup = document.getElementById("time_popup");  

	time_popup.setAttribute("x", "0");
	time_popup.setAttribute("y", "1000");	// 화면 밖으로
});


///// 팝업 오픈 시 뒤에 클릭안되게 하는 화면 열기/닫기
function Click_Prevention(popup, paramter)
{
	if (popup == "open")
	{
		let shadow = document.getElementById("shadow");  
		if (paramter == undefined)
		{
			webMI.trigger.fire("Prevention_Open");	
		}
		else
		{
			webMI.trigger.fire("Prevention_Open",paramter);	
		}
		
		shadow.setAttribute("x", "0");
		shadow.setAttribute("y", "0");

	}
	else if (popup == "close")
	{
		let shadow = document.getElementById("shadow");  
		webMI.trigger.fire("Prevention_Close");
		
		shadow.setAttribute("x", "0");
		shadow.setAttribute("y", "-1000");	// 화면 밖으로

	}
}

//////현재 페이지 이외에서 팝업 요청 시 Shadow Visible, Invisible/////////////
webMI.trigger.connect("Prevention_req",function(e)
{
	let parameter = e.value.parameter;
	parameter = parameter == null ? undefined : parameter; 
	Click_Prevention(e.value.req, parameter);
});

function increaseTime(ltDate)
{
    //setInterval(function()
    //{
        ltDate.setSeconds(ltDate.getSeconds() + 1);

        let formattedLtDate = formatDate(ltDate);

        webMI.gfx.setText("UTC_Year", formatDate.year);
		webMI.gfx.setText("UTC_Month", formatDate.month);
		webMI.gfx.setText("UTC_Date", formatDate.date);
		webMI.gfx.setText("UTC_Hour", formatDate.hours);
		webMI.gfx.setText("UTC_Minute", formatDate.seconds);
    //}, 1000); // 1초마다 실행
}

function formatDate(date)
{
    let year = date.getFullYear();
    let month = String(date.getMonth() + 1).padStart(2, '0');
    let day = String(date.getDate()).padStart(2, '0');
    let hours = String(date.getHours()).padStart(2, '0');
    let minutes = String(date.getMinutes()).padStart(2, '0');
    let seconds = String(date.getSeconds()).padStart(2, '0');
    
    return {
        year: year,
        month: month,
        date: date,
        hours: hours,
        minutes: minutes,
        seconds: seconds
    };
}


///////////////////////////*  밝기 조정 버튼 클릭 이벤트  *///////////////////////////

var now_brightness = localStorage.getItem("Brightness");
Brightness_Btn_Setting();

webMI.addEvent("btn_brightness_UP", "click", function(e)
{
	if (now_brightness >= 95)
	{
		now_brightness = 100;
		webMI.trigger.fire("Brightness_UP", now_brightness);
	}
	else
	{
		now_brightness = Number(now_brightness) + 5;
		
		webMI.trigger.fire("Brightness_UP", now_brightness);
	}
		
	webMI.gfx.setText("lbl_brightness", now_brightness)	// 텍스트 업데이트
});


webMI.addEvent("btn_brightness_DOWN", "click", function(e)
{
	if (now_brightness <= 5)
	{
		now_brightness = 5;
		webMI.gfx.setText("lbl_brightness", 0)	// 텍스트 업데이트
	}
	else
	{
		now_brightness = Number(now_brightness) - 5;
		
		webMI.gfx.setText("lbl_brightness", now_brightness)	// 텍스트 업데이트		
		webMI.trigger.fire("Brightness_DOWN",now_brightness);
	}
});

webMI.trigger.connect("Brightness_Value_Change", function(e)
{
	Brightness_Btn_Setting();
});

function Brightness_Btn_Setting()
{
	now_brightness = localStorage.getItem("Brightness");
	var real_bright = webMI.rootWindow.getBrightness();
	webMI.gfx.setText("lbl_brightness", now_brightness);
	
	if(isNaN(now_brightness))
	{
		localStorage.setItem("Brightness", real_bright);
		webMI.trigger.fire("Brightness_Value_Change");
	}
	
	if (real_bright >= 95)
	{
		webMI.trigger.fire("btn_inactive", "brightness_up");
		webMI.trigger.fire("btn_active", "brightness_down");
	}
	else if (real_bright <= 5)
	{
		webMI.trigger.fire("btn_active", "brightness_up");
		webMI.trigger.fire("btn_inactive", "brightness_down");
	}
	else
	{
		webMI.trigger.fire("btn_active", "brightness_up");
		webMI.trigger.fire("btn_active", "brightness_down");
	}

}

///////////////////////////*  유저 매뉴얼 버튼 클릭 이벤트 *///////////////////////////

webMI.trigger.connect("UserManual_Open", function(e)
{
	
	Click_Prevention("open");
	let time_popup = document.getElementById("user_manual_popup");  

	time_popup.setAttribute("x", "603");		//960 -357 
	time_popup.setAttribute("y", "20");
	webMI.trigger.fire("UserManual_Move");
});

webMI.trigger.connect("UserManual_Close", function(e)
{
	Click_Prevention("close")
	let time_popup = document.getElementById("user_manual_popup");  
	time_popup.setAttribute("x", "0");
	time_popup.setAttribute("y", "1000");	// 화면 밖으로
	
});

//////////////////////////키패드 오픈//////////////////////////////////
webMI.trigger.connect("Keyboard_Open", function(e)
{
	var type = e.value.type;
	
	var options = {};	
	var max_len = 0;
	var password_on = false;
	
	if (e.value.type == "ID")
	{
		max_len =15;
		password_on =false;
	}
	else if(e.value.type == "PW")
	{
		max_len = 21;
		password_on = true;
	}	
	
	options["parameter"] = type;
	options["max_len"] = max_len;
	options["password_on"] = password_on;
	
	webMI.trigger.fire("keyboard_init", options);
	
	let popup = document.getElementById("popup_keyboard");  
	popup.setAttribute("x", "310");
	popup.setAttribute("y", "285");	
});
	
////////////////키보드 종료///////////////////////////
webMI.trigger.connect("Keyboard_Close", function(e)
{
	let popup = document.getElementById("popup_keyboard");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

//////////////////////////로그인 팝업창 오픈//////////////////////////////////
webMI.trigger.connect("Login_Open", function(e)
{
	Click_Prevention("open");
	webMI.trigger.fire("Login_Popup_init");
	
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("x", "602");
	popup.setAttribute("y", "213");	
});
	
////////////////로그인 팝업창 종료///////////////////////////
webMI.trigger.connect("Login_Close", function(e)
{
	Click_Prevention("close");
	
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

////////////////로그인 팝업창 올리기///////////////////////////
webMI.trigger.connect("Login_Popup_Up", function(e)
{
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("y", "20");	
});

////////////////로그인 팝업창 내리기///////////////////////////
webMI.trigger.connect("Login_Popup_Down", function(e)
{
	let popup = document.getElementById("login_popup");  
	popup.setAttribute("y", "213");	
});

//////////////////////////정보 팝업창 오픈//////////////////////////////////
webMI.trigger.connect("Info_Popup_Open", function(e)
{
	Click_Prevention("open");
	webMI.trigger.fire("Info_Init",e.value);	
	
	let popup = document.getElementById("info_popup");  
	popup.setAttribute("x", "602");
	popup.setAttribute("y", "213");	
});
	
////////////////정보 팝업창 종료///////////////////////////
webMI.trigger.connect("Info_Popup_Close", function(e)
{
	Click_Prevention("close");
	
	let popup = document.getElementById("info_popup");  
	popup.setAttribute("x", "2000");
	popup.setAttribute("y", "2000");	
});

/////////////시간 업데이트///////////////////////
webMI.trigger.connect("Time_Update",function(e)
{
    let d = new Date();    
    
    let year = d.getFullYear();
    let month = d.getMonth() + 1;
    let date = d.getDate();    
    let hour = d.getHours();
    let min = d.getMinutes();    
    let sec = d.getSeconds();
    
    month = String(month).padStart(2, '0'); // 두 자리 수로 맞추기
    date = String(date).padStart(2, '0');
    hour = String(hour).padStart(2, '0');
    min = String(min).padStart(2, '0');
    sec = String(sec).padStart(2, '0');
    
	webMI.gfx.setText("time_Year",year);
	webMI.gfx.setText("time_Month",month);
	webMI.gfx.setText("time_Date",date);
	webMI.gfx.setText("time_Hour",hour);
	webMI.gfx.setText("time_Minute",min);
	webMI.gfx.setText("time_Second",sec);    
});