webMI.addOnload(function () {
  var APP = (webMI.rootWindow || window).APP;
  function init() {
    webMI.gfx.setText("txt", "Hello 👋");
    webMI.addEvent("btn", "click", APP.actions.toggleDemo);
    APP.bus.on("demo:on", on => webMI.gfx.setFill("rect", on ? "#9AE6B4" : "#FCA5A5"));
    // 초기 상태 반영
    webMI.gfx.setFill("rect", APP.state.demoOn ? "#9AE6B4" : "#FCA5A5");
  }
  (APP && APP.__ready) ? init() : webMI.trigger.connect("APP:ready", init);
});
