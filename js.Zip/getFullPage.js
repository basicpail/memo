(async () => {
  const MAX_PAGES = 100;            // 최대 스캔 페이지 수
  const SLEEP_MS = 150;             // 요청 간 간격
  const isSameOrigin = (u) => {
    try { return new URL(u, location.href).origin === location.origin; }
    catch { return false; }
  };
  const normalize = (u) => new URL(u, location.href).href.split('#')[0];
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  function extractFromDoc(doc) {
    const pageName =
      doc.querySelector('meta[property="og:title"]')?.content?.trim()
      || doc.title?.trim()
      || (new URL(doc.URL)).pathname.split('/').filter(Boolean).pop()
      || 'index';

    const ids = {};
    doc.querySelectorAll('[id]').forEach(el => {
      const id = el.id;
      const entry = {
        tag: el.tagName.toLowerCase(),
        selector: `#${(window.CSS?.escape ? CSS.escape(id) : id)}`,
        snippet: el.outerHTML.slice(0, 120).replace(/\s+/g, ' ').trim() + '…'
      };
      (ids[id] ??= []).push(entry); // 중복 id도 배열로 모두 담기
    });

    return { pageName, ids };
  }

  const results = {};               // { url: { pageName, ids: {id: [{tag, selector, snippet}]}}}
  const seen = new Set();
  const queue = [location.href];

  while (queue.length && seen.size < MAX_PAGES) {
    const url = normalize(queue.shift());
    if (seen.has(url)) continue;
    seen.add(url);

    try {
      const res = await fetch(url, { credentials: 'include' });
      const ct = res.headers.get('content-type') || '';
      if (!ct.includes('text/html')) continue;

      const html = await res.text();
      const doc = new DOMParser().parseFromString(html, 'text/html');

      // 수집
      const { pageName, ids } = extractFromDoc(doc);
      results[url] = { pageName, ids };

      // 내부 링크 확장
      const links = [...doc.querySelectorAll('a[href]')]
        .map(a => a.getAttribute('href'))
        .filter(h => h && !h.startsWith('mailto:') && !h.startsWith('tel:'))
        .map(normalize)
        .filter(isSameOrigin)
        .filter(href => !/\.(pdf|png|jpe?g|gif|svg|zip|mp4|mp3|webm|webp)(\?|$)/i.test(href));

      for (const link of links) if (!seen.has(link)) queue.push(link);

      await sleep(SLEEP_MS);
    } catch (e) {
      console.warn('Failed on', url, e);
    }
  }

  // 요약 테이블
  console.table(
    Object.entries(results).map(([url, v]) => ({
      url,
      pageName: v.pageName,
      idCount: Object.keys(v.ids).length
    }))
  );

  // 전체 결과 객체
  console.log('results', results);

  // 특정 id가 어느 페이지에 있는지 찾기
  window.findId = (id) =>
    Object.entries(results)
      .filter(([, v]) => v.ids[id])
      .map(([url, v]) => ({ url, pageName: v.pageName, elements: v.ids[id] }));
})();
