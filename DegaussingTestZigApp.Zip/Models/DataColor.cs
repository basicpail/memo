﻿using System.Windows.Media;

namespace DegaussingTestZigApp.Models
{
    public struct DataColor
    {
        public Brush Color { get; set; }
    }
}
