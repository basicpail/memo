namespace DegaussingTestZigApp.Resources
{
    public partial class Translations
    {
    }
}
