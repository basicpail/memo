﻿using DegaussingTestZigApp.Models;
using DegaussingTestZigApp.Services;
using System.Net;

namespace DegaussingTestZigApp.ViewModels.Pages
{
    public partial class DashboardViewModel : ObservableObject
    {
        private readonly ModbusUDPService _modbusService = new();

        [ObservableProperty]
        private string address = "127.0.0.1";

        [ObservableProperty]
        private int port = 502;

        [ObservableProperty]
        private string statusMessage;

        [RelayCommand]
        private async Task Connect()
        {
            var settings = new ModbusUDPSettings
            {
                Address = Address,
                Port = Port
            };

            bool result = await _modbusService.ConnectAsync(settings);
            StatusMessage = result ? "연결 성공" : "연결 실패";
        }

        [RelayCommand]
        private async Task Disconnect()
        {
            bool result = await _modbusService.DisconnectAsync();
            StatusMessage = result ? "연결 종료됨" : "종료 실패";
        }
    }
}
